# Code layout

The mod targets Forge 1.8.9 and keeps the event-driven client integration separate from pure text parsing and world rendering.

- `SpiderDropAlert` is the Forge entry point. It registers listeners and commands, owns persistent feature state, processes client events, and draws the HUD panels.
- `DropMessageParser` contains side-effect-free parsing for rare-drop lines, stack quantities, boss messages, and fishing announcements. Parser tests do not need a running Minecraft client.
- `SlayerType` and `LegendaryCreature` hold the canonical categories and recognized message markers used by the parser and tracker.
- `M7OverlayRenderer` owns M7 scoreboard detection, dragon-to-statue mapping, world-unload cleanup, and world-space outlines. Feature switches and settings persistence stay in `SpiderDropAlert`.
- `TrackerConfigScreen` is the settings UI; the small command classes keep command syntax out of the event handlers.

## Validation

Use Java 8 and run `bash gradlew clean test build`. The unit tests cover parsing, timers, settings persistence, M7 floor recognition, dragon mapping, and the pure rendering geometry helpers. They do not replace an in-game Hypixel runtime check.
