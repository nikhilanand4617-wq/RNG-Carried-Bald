package dev.arena.spiderdropalert;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.boss.EntityDragon;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.scoreboard.Score;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

/** Owns the M7-specific entity tracking, floor detection, and world-space outlines. */
public final class M7OverlayRenderer {
    private final SpiderDropAlert mod;
    private final Map<Integer, M7DragonStatue> dragonTypesByEntityId =
            new HashMap<Integer, M7DragonStatue>();
    private boolean dragonPhaseSeen;

    M7OverlayRenderer(SpiderDropAlert mod) {
        this.mod = mod;
    }

    @SubscribeEvent
    public void onEntityJoinWorld(EntityJoinWorldEvent event) {
        if (event == null || event.world == null || !event.world.isRemote
                || !(event.entity instanceof EntityDragon)) {
            return;
        }

        Entity dragon = event.entity;
        M7DragonStatue statue = dragonStatueForName(getEntityName(dragon));
        if (statue == null) {
            statue = nearestM7DragonStatue(dragon.posX, dragon.posZ);
        }
        if (statue != null) {
            dragonTypesByEntityId.put(dragon.getEntityId(), statue);
        }
    }

    @SubscribeEvent
    public void onRenderWorldLast(RenderWorldLastEvent event) {
        if (event == null || !mod.shouldRenderWorldOverlay()) {
            return;
        }

        Minecraft minecraft = Minecraft.getMinecraft();
        if (minecraft == null || minecraft.theWorld == null || minecraft.thePlayer == null
                || !isMasterModeFloorSeven(minecraft)) {
            resetWorldState();
            return;
        }

        Entity camera = minecraft.getRenderViewEntity();
        if (camera == null) {
            return;
        }

        double cameraX = interpolate(camera.lastTickPosX, camera.posX, event.partialTicks);
        double cameraY = interpolate(camera.lastTickPosY, camera.posY, event.partialTicks);
        double cameraZ = interpolate(camera.lastTickPosZ, camera.posZ, event.partialTicks);

        for (Entity entity : minecraft.theWorld.loadedEntityList) {
            renderEntityHitbox(entity, event.partialTicks, cameraX, cameraY, cameraZ);
        }

        if (dragonPhaseSeen && mod.isM7StatueZonesEnabled()) {
            for (M7DragonStatue statue : M7DragonStatue.values()) {
                drawOutlinedBox(statue.killZone.offset(-cameraX, -cameraY, -cameraZ), statue.color);
            }
        }
    }

    @SubscribeEvent
    public void onWorldUnload(WorldEvent.Unload event) {
        if (event != null && event.world != null && event.world.isRemote) {
            resetWorldState();
        }
    }

    private void renderEntityHitbox(Entity entity, float partialTicks,
                                    double cameraX, double cameraY, double cameraZ) {
        if (entity == null || entity.isDead || entity instanceof EntityArmorStand) {
            return;
        }

        String name = getEntityName(entity);
        String normalizedName = name.toUpperCase(Locale.ROOT);
        boolean dragonEntity = entity instanceof EntityDragon;
        if (dragonEntity || normalizedName.contains("WITHER KING")
                || normalizedName.contains("KAEMAN")) {
            dragonPhaseSeen = true;
        }

        M7HitboxTarget target = classifyM7HitboxTarget(name, dragonEntity);
        if (target == null) {
            return;
        }

        int color = target.color;
        if (target == M7HitboxTarget.DRAGON) {
            M7DragonStatue statue = dragonStatueForName(name);
            if (statue == null) {
                statue = dragonTypesByEntityId.get(entity.getEntityId());
            }
            if (statue == null) {
                statue = nearestM7DragonStatue(entity.posX, entity.posZ);
            }
            if (statue == null || !mod.isM7DragonHitboxEnabled(statue)) {
                return;
            }
            color = statue.color;
        } else if (!mod.isM7BossHitboxEnabled(target)) {
            return;
        }

        AxisAlignedBB entityBox = entity.getEntityBoundingBox();
        if (entityBox == null) {
            return;
        }

        double entityX = interpolate(entity.lastTickPosX, entity.posX, partialTicks);
        double entityY = interpolate(entity.lastTickPosY, entity.posY, partialTicks);
        double entityZ = interpolate(entity.lastTickPosZ, entity.posZ, partialTicks);
        AxisAlignedBB renderBox = entityBox.offset(entityX - entity.posX - cameraX,
                entityY - entity.posY - cameraY, entityZ - entity.posZ - cameraZ);
        drawOutlinedBox(renderBox, color);
    }

    private void resetWorldState() {
        dragonTypesByEntityId.clear();
        dragonPhaseSeen = false;
    }

    private static double interpolate(double previous, double current, float partialTicks) {
        return previous + (current - previous) * partialTicks;
    }

    static boolean isM7ScoreboardText(String text) {
        if (text == null) {
            return false;
        }
        String normalized = SpiderDropAlert.stripFormattingCodes(text).toUpperCase(Locale.ROOT);
        boolean explicitM7 = normalized.matches("(?s).*\\bM\\s*7\\b.*")
                || normalized.matches("(?s).*\\bM\\s*VII\\b.*")
                || normalized.matches("(?s).*\\bMM\\s*7\\b.*");
        boolean floorSeven = normalized.contains("FLOOR VII") || normalized.contains("FLOOR 7")
                || normalized.matches("(?s).*\\bF\\s*7\\b.*")
                || normalized.matches("(?s).*\\bF\\s*VII\\b.*");
        boolean masterMode = normalized.contains("MASTER MODE")
                || normalized.matches("(?s).*\\bMM\\b.*");
        return explicitM7 || (masterMode && floorSeven);
    }

    private boolean isMasterModeFloorSeven(Minecraft minecraft) {
        if (minecraft == null || minecraft.theWorld == null) {
            return false;
        }
        Scoreboard scoreboard = minecraft.theWorld.getScoreboard();
        if (scoreboard == null) {
            return false;
        }
        ScoreObjective sidebar = scoreboard.getObjectiveInDisplaySlot(1);
        if (sidebar == null) {
            return false;
        }

        StringBuilder text = new StringBuilder(sidebar.getDisplayName());
        for (Score score : scoreboard.getSortedScores(sidebar)) {
            String playerName = score.getPlayerName();
            if (playerName == null || playerName.startsWith("#")) {
                continue;
            }
            ScorePlayerTeam team = scoreboard.getPlayersTeam(playerName);
            text.append(' ').append(ScorePlayerTeam.formatPlayerName(team, playerName));
        }
        return isM7ScoreboardText(text.toString());
    }

    static M7HitboxTarget classifyM7HitboxTarget(String displayName, boolean dragonEntity) {
        String normalized = SpiderDropAlert.stripFormattingCodes(displayName == null ? "" : displayName)
                .toUpperCase(Locale.ROOT);
        if (normalized.contains("MAXOR")) {
            return M7HitboxTarget.MAXOR;
        }
        if (normalized.contains("STORM")) {
            return M7HitboxTarget.STORM;
        }
        if (normalized.contains("GOLDOR")) {
            return M7HitboxTarget.GOLDOR;
        }
        if (normalized.contains("NECRON")) {
            return M7HitboxTarget.NECRON;
        }
        if (dragonEntity || normalized.contains("APEX DRAGON")
                || normalized.contains("FLAME DRAGON") || normalized.contains("ICE DRAGON")
                || normalized.contains("POWER DRAGON") || normalized.contains("SOUL DRAGON")) {
            return M7HitboxTarget.DRAGON;
        }
        return null;
    }

    static M7DragonStatue dragonStatueForName(String displayName) {
        String normalized = SpiderDropAlert.stripFormattingCodes(displayName == null ? "" : displayName)
                .toUpperCase(Locale.ROOT);
        for (M7DragonStatue statue : M7DragonStatue.values()) {
            if (normalized.contains(statue.dragonName.toUpperCase(Locale.ROOT))) {
                return statue;
            }
        }
        return null;
    }

    static M7DragonStatue nearestM7DragonStatue(double x, double z) {
        M7DragonStatue nearest = null;
        double nearestDistanceSq = Double.MAX_VALUE;
        for (M7DragonStatue statue : M7DragonStatue.values()) {
            double dx = x - statue.anchor.getX();
            double dz = z - statue.anchor.getZ();
            double distanceSq = dx * dx + dz * dz;
            if (distanceSq < nearestDistanceSq) {
                nearestDistanceSq = distanceSq;
                nearest = statue;
            }
        }
        return nearest;
    }

    private static String getEntityName(Entity entity) {
        if (entity == null) {
            return "";
        }
        StringBuilder name = new StringBuilder();
        if (entity.getDisplayName() != null) {
            name.append(entity.getDisplayName().getUnformattedText());
        }
        String customName = entity.getCustomNameTag();
        if (customName != null && customName.length() > 0) {
            name.append(' ').append(customName);
        }
        return name.toString();
    }

    private static void drawOutlinedBox(AxisAlignedBB box, int color) {
        float red = ((color >> 16) & 0xFF) / 255.0F;
        float green = ((color >> 8) & 0xFF) / 255.0F;
        float blue = (color & 0xFF) / 255.0F;
        GlStateManager.pushMatrix();
        GlStateManager.disableTexture2D();
        GlStateManager.disableLighting();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.disableCull();
        GlStateManager.disableDepth();
        GlStateManager.depthMask(false);
        GL11.glLineWidth(2.0F);
        GL11.glColor4f(red, green, blue, 0.95F);
        GL11.glBegin(GL11.GL_LINES);
        drawBoxEdge(box.minX, box.minY, box.minZ, box.maxX, box.minY, box.minZ);
        drawBoxEdge(box.maxX, box.minY, box.minZ, box.maxX, box.minY, box.maxZ);
        drawBoxEdge(box.maxX, box.minY, box.maxZ, box.minX, box.minY, box.maxZ);
        drawBoxEdge(box.minX, box.minY, box.maxZ, box.minX, box.minY, box.minZ);
        drawBoxEdge(box.minX, box.maxY, box.minZ, box.maxX, box.maxY, box.minZ);
        drawBoxEdge(box.maxX, box.maxY, box.minZ, box.maxX, box.maxY, box.maxZ);
        drawBoxEdge(box.maxX, box.maxY, box.maxZ, box.minX, box.maxY, box.maxZ);
        drawBoxEdge(box.minX, box.maxY, box.maxZ, box.minX, box.maxY, box.minZ);
        drawBoxEdge(box.minX, box.minY, box.minZ, box.minX, box.maxY, box.minZ);
        drawBoxEdge(box.maxX, box.minY, box.minZ, box.maxX, box.maxY, box.minZ);
        drawBoxEdge(box.maxX, box.minY, box.maxZ, box.maxX, box.maxY, box.maxZ);
        drawBoxEdge(box.minX, box.minY, box.maxZ, box.minX, box.maxY, box.maxZ);
        GL11.glEnd();
        GL11.glLineWidth(1.0F);
        GlStateManager.depthMask(true);
        GlStateManager.enableDepth();
        GlStateManager.enableCull();
        GlStateManager.disableBlend();
        GlStateManager.enableLighting();
        GlStateManager.enableTexture2D();
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
        GlStateManager.popMatrix();
    }

    private static void drawBoxEdge(double x1, double y1, double z1,
                                    double x2, double y2, double z2) {
        GL11.glVertex3d(x1, y1, z1);
        GL11.glVertex3d(x2, y2, z2);
    }

    enum M7HitboxTarget {
        MAXOR(0xFFFF4545),
        STORM(0xFF9E62FF),
        GOLDOR(0xFFFFD34D),
        NECRON(0xFFDD59E8),
        DRAGON(0xFFF4F4F4);

        final int color;

        M7HitboxTarget(int color) {
            this.color = color;
        }
    }

    enum M7DragonStatue {
        POWER("Power Dragon", new BlockPos(27, 14, 59), 0xFFFF4545),
        APEX("Apex Dragon", new BlockPos(27, 14, 94), 0xFF78EB4F),
        SOUL("Soul Dragon", new BlockPos(56, 14, 125), 0xFFB35CFF),
        ICE("Ice Dragon", new BlockPos(84, 14, 94), 0xFF45C9FF),
        FLAME("Flame Dragon", new BlockPos(85, 14, 56), 0xFFFF9138);

        final String dragonName;
        final BlockPos anchor;
        final int color;
        final AxisAlignedBB killZone;

        M7DragonStatue(String dragonName, BlockPos anchor, int color) {
            this.dragonName = dragonName;
            this.anchor = anchor;
            this.color = color;
            double horizontalHalfSize = 13.5D;
            this.killZone = new AxisAlignedBB(anchor.getX() - horizontalHalfSize,
                    anchor.getY() - 8.0D, anchor.getZ() - horizontalHalfSize,
                    anchor.getX() + horizontalHalfSize, anchor.getY() + horizontalHalfSize + 2.0D,
                    anchor.getZ() + horizontalHalfSize);
        }
    }
}
