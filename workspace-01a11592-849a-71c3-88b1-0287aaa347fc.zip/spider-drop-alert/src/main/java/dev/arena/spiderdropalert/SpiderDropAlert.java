package dev.arena.spiderdropalert;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.projectile.EntityFishHook;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.sound.PlaySoundEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

/** Client-side SkyBlock tracker with Slayer/Fishing HUDs and M7 world overlays. */
@Mod(
        modid = SpiderDropAlert.MOD_ID,
        name = SpiderDropAlert.MOD_NAME,
        version = SpiderDropAlert.VERSION,
        acceptedMinecraftVersions = "[1.8.9]",
        clientSideOnly = true
)
public final class SpiderDropAlert {
    public static final String MOD_ID = "spiderdropalert";
    public static final String MOD_NAME = "Spider Drop Alert";
    public static final String VERSION = "1.0.63";

    static final int PANEL_WIDTH = 240;
    private static final int HEADER_HEIGHT = 18;
    private static final int ITEM_ONLY_ENTRY_HEIGHT = 12;
    private static final int MAX_TRACKED_DROPS = 4;
    private static final long DUPLICATE_DROP_WINDOW_MS = 750L;
    private static final String PRICE_PROPERTY_PREFIX = "price.";
    private static final String LEGENDARY_COUNT_PROPERTY_PREFIX = "fishing.creature.";
    private static final String LEGACY_LAST_PRICE_ITEM_PROPERTY = "price.lastItem";
    private static final String BITE_ALERT_SYMBOL = "!!!";
    private static final int BITE_ALERT_DURATION_TICKS = 28;
    private static final long BITE_ALERT_ARM_DELAY_MS = 1200L;
    private static final long BITE_ALERT_SAMPLE_WINDOW_MS = 350L;
    private static final double BITE_ALERT_PULL_DOWN_THRESHOLD = -0.12D;
    private static final double BITE_ALERT_DISPLACEMENT_EPSILON = 0.000001D;
    private static final double FISHING_SPLASH_SOUND_RANGE_BLOCKS = 3.5D;
    private static final long DEPLOYABLE_SCAN_INTERVAL_MS = 1000L;
    private static final int TOTEM_CORRUPTION_DURATION_SECONDS = 120;
    private static final long SOS_FLARE_DURATION_MS = 180000L;
    private static final long PLASMAFLUX_DURATION_MS = 60000L;
    private static final long JAWBUS_ALERT_DEDUPE_WINDOW_MS = 3000L;
    private static final int DEPLOYABLE_PANEL_WIDTH = 270;
    private static final int NEARBY_CREATURE_HP_PANEL_WIDTH = 340;
    private static final int MAX_NEARBY_CREATURE_HP_ROWS = 8;
    private static final double NEARBY_CREATURE_HP_RANGE_BLOCKS = 64.0D;
    private static final long NEARBY_CREATURE_HP_SCAN_INTERVAL_MS = 250L;
    private static final String NEARBY_CREATURE_HP_PROPERTY_PREFIX = "nearbyCreatureHp.";
    private static final String[] TRACKED_NEARBY_SEA_CREATURES = {
            "The Loch Emperor", "Sea Emperor", "The Sea Emperor", "Loch Emperor",
            "Water Hydra", "Alligator", "Abyssal Miner",
            "Blue Ringed Octopus", "Fiery Scuttler", "Great White Shark", "Phantom Fisher",
            "Puddle Jumper", "Silkbreeze", "Thunder", "Yeti", "Lord Jawbus",
            "Nessie", "Grim Reaper", "Reindrake", "Ragnarok", "Plhlegblast",
            "Wiki Tiki", "Giant Isopod", "Titanoboa", "Frog Prince"
    };

    private static final Pattern DEPLOYABLE_REMAINING_TIME = Pattern.compile(
            "(?i)(?:(\\d+)\\s*m\\s*)?(\\d+)\\s*s");
    private static final Pattern NEARBY_CREATURE_LEVEL = Pattern.compile(
            "(?i)\\[\\s*LVL?\\s*(\\d+)\\s*\\]");
    private static final Pattern NEARBY_CREATURE_HEALTH = Pattern.compile(
            "(?i)([0-9][0-9,]*(?:\\.[0-9]+)?\\s*[KMBT]?)\\s*/\\s*"
                    + "([0-9][0-9,]*(?:\\.[0-9]+)?\\s*[KMBT]?)\\s*[\\u2764\\u2665]?");

    private final Map<SlayerType, List<DropEntry>> dropHistory =
            new EnumMap<SlayerType, List<DropEntry>>(SlayerType.class);
    private final Map<String, Long> manualPrices = new HashMap<String, Long>();
    private final Map<LegendaryCreature, Long> legendaryCreatureCounts =
            new EnumMap<LegendaryCreature, Long>(LegendaryCreature.class);
    private final List<NearbyCreatureHpEntry> nearbyCreatureHpEntries =
            new ArrayList<NearbyCreatureHpEntry>();
    private SlayerType activeSlayer = SlayerType.SPIDER;
    private String lastProcessedDropKey = "";
    private long lastProcessedDropAt;
    private String lastProcessedFishingCreature = "";
    private long lastProcessedFishingAt;

    private boolean fishingBobberWasActive;
    private boolean fishingTimerActive;
    private boolean fishingTimerHasValue;
    private long fishingTimerStartedAt;
    private long lastFishingDurationMillis;

    private boolean splashToPullTimerActive;
    private boolean splashToPullTimerHasValue;
    private long splashToPullTimerStartedAt;
    private long lastSplashToPullDurationMillis;
    private int splashToPullBobberEntityId = -1;
    private double previousSplashToPullBobberY;
    private double splashToPullSampleWindowStartY;
    private long splashToPullSampleWindowStartedAt;
    private long splashToPullBobberObservedAt;

    private boolean slayerBossTimerActive;
    private boolean slayerBossTimerHasValue;
    private SlayerType slayerBossTimerType;
    private long slayerBossTimerStartedAt;
    private long lastSlayerBossDurationMillis;

    private boolean biteAlertEnabled = true;
    private int biteAlertX;
    private int biteAlertY;
    private boolean biteAlertPositionConfigured;
    private int biteAlertSizePercent = 100;
    private int biteAlertBobberEntityId = -1;
    private double previousFishingBobberY;
    private double biteAlertSampleWindowStartY;
    private long biteAlertSampleWindowStartedAt;
    private boolean biteAlertTriggeredForBobber;
    private long fishingBobberObservedAt;
    private int biteAlertTicksRemaining;

    private boolean jawbusAlertEnabled = true;
    private long lastJawbusAlertAt;

    private boolean deployablesTimerPanelEnabled = true;
    private boolean totemTimerEnabled = true;
    private boolean sosFlareTimerEnabled = true;
    private boolean plasmafluxTimerEnabled = true;
    private boolean nearbyCreatureHpEnabled = true;
    private boolean m7OverlayEnabled = true;
    private boolean m7MaxorEnabled = true;
    private boolean m7StormEnabled = true;
    private boolean m7GoldorEnabled = true;
    private boolean m7NecronEnabled = true;
    private boolean m7PowerDragonEnabled = true;
    private boolean m7ApexDragonEnabled = true;
    private boolean m7SoulDragonEnabled = true;
    private boolean m7IceDragonEnabled = true;
    private boolean m7FlameDragonEnabled = true;
    private boolean m7StatueZonesEnabled = true;
    private final M7OverlayRenderer m7OverlayRenderer = new M7OverlayRenderer(this);
    private int nearbyCreatureHpX = 10;
    private int nearbyCreatureHpY = 145;
    private boolean nearbyCreatureHpPositionConfigured;
    private int nearbyCreatureHpSizePercent = 100;
    private long nextNearbyCreatureHpScanAt;
    private World lastNearbyCreatureHpWorld;
    private int deployablesTimerPanelX = 10;
    private int deployablesTimerPanelY = 200;
    private boolean deployablesTimerPanelPositionConfigured;
    private int deployablesTimerPanelSizePercent = 100;
    private int totemRemainingSeconds = -1;
    private long totemTimerObservedAt;
    private long lastTotemInteractionAt;
    private long sosFlareExpiresAt;
    private long plasmafluxExpiresAt;
    private long lastPlasmafluxInteractionAt;
    private long nextDeployableScanAt;
    private long lastSosInteractionAt;
    private World lastDeployablesWorld;

    private boolean trackerEnabled = true;
    private boolean fishingMobCounterEnabled;
    private int trackerX = 10;
    private int trackerY = 60;
    private int fishingX = 270;
    private int fishingY = 60;
    private boolean fishingPositionConfigured;
    private int trackerSizePercent = 100;
    private boolean trackerGuiPending;
    private File settingsFile;

    public SpiderDropAlert() {
    }

    SpiderDropAlert(File settingsFile) {
        this.settingsFile = settingsFile;
        loadSettings();
    }

    @Mod.EventHandler
    public void onInit(FMLInitializationEvent event) {
        loadSettings();
        MinecraftForge.EVENT_BUS.register(this);
        MinecraftForge.EVENT_BUS.register(m7OverlayRenderer);
        FMLCommonHandler.instance().bus().register(this);
        ClientCommandHandler.instance.registerCommand(new PriceSetCommand(this));
        ClientCommandHandler.instance.registerCommand(new PriceSetCommand(this, "setprice"));
        ClientCommandHandler.instance.registerCommand(new SpiderTrackerCommand(this));
        ClientCommandHandler.instance.registerCommand(new TrackerGuiCommand(this));
    }

    /** Opens the settings screen after the chat screen has finished closing. */
    void requestTrackerGui() {
        trackerGuiPending = true;
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        updateFishingTimerFromClient();
        updateFishingBiteAlertFromClient();
        long now = System.currentTimeMillis();
        updateDeployableTimersFromClient(now);
        updateNearbyCreatureHpFromClient(now);
        if (!trackerGuiPending) {
            return;
        }
        trackerGuiPending = false;
        Minecraft minecraft = Minecraft.getMinecraft();
        if (minecraft != null) {
            minecraft.displayGuiScreen(new TrackerConfigScreen(this));
        }
    }

    /** Starts a Slayer timer when a supported boss entity enters the client world. */
    @SubscribeEvent
    public void onEntityJoinWorld(EntityJoinWorldEvent event) {
        if (event == null || event.world == null || !event.world.isRemote || event.entity == null) {
            return;
        }
        if (!trackerEnabled || !(event.entity instanceof EntityLivingBase)) {
            return;
        }
        String displayName = event.entity.getDisplayName().getUnformattedText();
        SlayerType boss = DropMessageParser.detectSlayerBossName(displayName);
        if (boss != null) {
            startSlayerBossTimer(boss, System.currentTimeMillis());
        }
    }

    /** Tracks the player's own Totem, Plasmaflux, and SOS Flare use without automating gameplay. */
    @SubscribeEvent
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event == null || event.world == null || !event.world.isRemote
                || (event.action != PlayerInteractEvent.Action.RIGHT_CLICK_AIR
                && event.action != PlayerInteractEvent.Action.RIGHT_CLICK_BLOCK)) {
            return;
        }
        Minecraft minecraft = Minecraft.getMinecraft();
        if (minecraft == null || minecraft.thePlayer == null
                || event.entityPlayer != minecraft.thePlayer) {
            return;
        }
        ItemStack heldItem = event.entityPlayer.getHeldItem();
        if (heldItem == null) {
            return;
        }
        String heldName = stripFormattingCodes(heldItem.getDisplayName() == null
                ? "" : heldItem.getDisplayName()).trim();
        long now = System.currentTimeMillis();
        if (totemTimerEnabled && isTotemOfCorruptionItemName(heldName)) {
            if (now - lastTotemInteractionAt >= 0L && now - lastTotemInteractionAt < 500L) {
                return;
            }
            lastTotemInteractionAt = now;
            startTotemFallbackTimer(now);
            return;
        }
        if (plasmafluxTimerEnabled && isPlasmafluxPowerOrbItemName(heldName)) {
            if (now - lastPlasmafluxInteractionAt >= 0L
                    && now - lastPlasmafluxInteractionAt < 500L) {
                return;
            }
            lastPlasmafluxInteractionAt = now;
            startPlasmafluxTimer(now);
            return;
        }
        if (!sosFlareTimerEnabled || !isSosFlareItemName(heldName)) {
            return;
        }

        if (now - lastSosInteractionAt >= 0L && now - lastSosInteractionAt < 500L) {
            return;
        }
        lastSosInteractionAt = now;
        // The SOS Flare is activated by the local right-click; waiting for a particular
        // projectile type can miss Hypixel's server-side spawn, so start on the use event.
        startSosFlareTimer(now);
    }

    /** Watches incoming chat only; it never sends messages or automates gameplay. */
    @SubscribeEvent
    public void onChat(ClientChatReceivedEvent event) {
        if (event.message == null) {
            return;
        }

        String message = event.message.getUnformattedText();
        if (message == null) {
            return;
        }
        message = message.replace('\n', ' ').trim();

        long now = System.currentTimeMillis();
        if (jawbusAlertEnabled && isLordJawbusAlertMessage(message)
                && (lastJawbusAlertAt == 0L || now - lastJawbusAlertAt >= JAWBUS_ALERT_DEDUPE_WINDOW_MS)) {
            showLordJawbusTitle();
            lastJawbusAlertAt = now;
        }
        if (isSosFlareRemovedMessage(message)) {
            resetSosFlareTimer();
        }
        if (trackerEnabled) {
            SlayerType spawnedBoss = DropMessageParser.detectSlayerBossSpawnMessage(message);
            if (spawnedBoss != null) {
                startSlayerBossTimer(spawnedBoss, now);
            }
            if (DropMessageParser.isSlayerQuestCompleteMessage(message)) {
                completeSlayerBossTimer(now);
            }
        }

        if (fishingMobCounterEnabled) {
            LegendaryCreature detectedCreature = DropMessageParser.detectLegendaryCreature(message);
            if (detectedCreature != null) {
                String creatureKey = detectedCreature.name();
                long elapsed = now - lastProcessedFishingAt;
                if (!creatureKey.equals(lastProcessedFishingCreature) || elapsed < 0L
                        || elapsed > DUPLICATE_DROP_WINDOW_MS) {
                    recordLegendaryCreature(detectedCreature);
                    lastProcessedFishingCreature = creatureKey;
                    lastProcessedFishingAt = now;
                    saveSettings();
                }
            }
        }

        if (!trackerEnabled) {
            return;
        }

        SlayerType detectedSlayer = DropMessageParser.detectSlayer(message);
        if (detectedSlayer == null) {
            return;
        }

        String item = DropMessageParser.extractDropItem(message);
        if (item.length() == 0) {
            item = "Unknown item";
        }
        long quantity = DropMessageParser.extractDropQuantity(message);
        String dropKey = detectedSlayer.name() + "|" + DropMessageParser.normalizeItemName(item) + "|" + quantity;
        long elapsed = now - lastProcessedDropAt;
        if (dropKey.equals(lastProcessedDropKey) && elapsed >= 0L
                && elapsed <= DUPLICATE_DROP_WINDOW_MS) {
            return;
        }
        lastProcessedDropKey = dropKey;
        lastProcessedDropAt = now;

        recordDrop(detectedSlayer, item, quantity);
    }

    void recordDrop(SlayerType slayer, String item, long quantity) {
        if (slayer == null) {
            return;
        }
        activeSlayer = slayer;
        addOrStackDrop(slayer, item, quantity);
    }

    private void addOrStackDrop(SlayerType slayer, String item, long quantity) {
        List<DropEntry> history = getDropHistory(slayer);
        String key = DropMessageParser.normalizeItemName(item);
        for (int i = 0; i < history.size(); i++) {
            DropEntry existing = history.get(i);
            if (DropMessageParser.normalizeItemName(existing.item).equals(key)) {
                long combinedQuantity = addDropQuantities(existing.quantity, quantity);
                history.remove(i);
                history.add(0, new DropEntry(item, combinedQuantity));
                return;
            }
        }

        history.add(0, new DropEntry(item, quantity));
        while (history.size() > MAX_TRACKED_DROPS) {
            history.remove(history.size() - 1);
        }
    }

    private List<DropEntry> getDropHistory(SlayerType slayer) {
        List<DropEntry> history = dropHistory.get(slayer);
        if (history == null) {
            history = new ArrayList<DropEntry>();
            dropHistory.put(slayer, history);
        }
        return history;
    }

    int getDropHistorySize(SlayerType slayer) {
        List<DropEntry> history = dropHistory.get(slayer);
        return history == null ? 0 : history.size();
    }

    void recordLegendaryCreature(LegendaryCreature creature) {
        if (creature == null) {
            return;
        }
        legendaryCreatureCounts.put(creature,
                addDropQuantities(getLegendaryCreatureCount(creature), 1L));
    }

    long getLegendaryCreatureCount(LegendaryCreature creature) {
        Long count = legendaryCreatureCounts.get(creature);
        return count == null ? 0L : count;
    }

    long getTotalLegendaryCreatureCount() {
        long total = 0L;
        for (Long count : legendaryCreatureCounts.values()) {
            total = addDropQuantities(total, count == null ? 0L : count);
        }
        return total;
    }

    int getCaughtLegendaryCreatureCount() {
        int caught = 0;
        for (LegendaryCreature creature : LegendaryCreature.values()) {
            if (getLegendaryCreatureCount(creature) > 0L) {
                caught++;
            }
        }
        return caught;
    }

    boolean isFishingSectionVisible() {
        return fishingMobCounterEnabled;
    }

    boolean hasFishingTimer() {
        return fishingTimerHasValue;
    }

    boolean isFishingTimerActive() {
        return fishingTimerActive;
    }

    long getFishingTimerElapsedMillis(long now) {
        if (!fishingTimerHasValue) {
            return 0L;
        }
        return fishingTimerActive
                ? Math.max(0L, now - fishingTimerStartedAt) : lastFishingDurationMillis;
    }

    void updateFishingTimerState(boolean bobberActive, long now) {
        if (bobberActive && !fishingBobberWasActive) {
            fishingTimerStartedAt = now;
            fishingTimerActive = true;
            fishingTimerHasValue = true;
        } else if (!bobberActive && fishingBobberWasActive && fishingTimerActive) {
            lastFishingDurationMillis = Math.max(0L, now - fishingTimerStartedAt);
            fishingTimerActive = false;
        }
        fishingBobberWasActive = bobberActive;
    }

    private void updateFishingTimerFromClient() {
        Minecraft minecraft = Minecraft.getMinecraft();
        boolean bobberActive = fishingMobCounterEnabled
                && minecraft != null && minecraft.thePlayer != null
                && minecraft.thePlayer.fishEntity != null;
        updateFishingTimerState(bobberActive, System.currentTimeMillis());
    }

    private void updateFishingBiteAlertFromClient() {
        Minecraft minecraft = Minecraft.getMinecraft();
        EntityFishHook hook = minecraft == null || minecraft.thePlayer == null
                ? null : minecraft.thePlayer.fishEntity;
        long now = System.currentTimeMillis();
        updateSplashToPullTimerState(hook != null,
                hook == null ? -1 : hook.getEntityId(),
                hook == null ? 0.0D : hook.posY, now);
        updateBiteAlertState(biteAlertEnabled, hook != null,
                hook == null ? -1 : hook.getEntityId(),
                hook == null ? 0.0D : hook.posY, now);
    }

    @SubscribeEvent
    public void onFishingSplashSound(PlaySoundEvent event) {
        if (!fishingMobCounterEnabled || event == null || event.sound == null
                || !isFishingSplashSound(event.name)) {
            return;
        }
        Minecraft minecraft = Minecraft.getMinecraft();
        EntityFishHook hook = minecraft == null || minecraft.thePlayer == null
                ? null : minecraft.thePlayer.fishEntity;
        if (hook == null || hook.getEntityId() != splashToPullBobberEntityId) {
            return;
        }
        if (!isFishingSplashNearBobber(event.name,
                event.sound.getXPosF(), event.sound.getYPosF(), event.sound.getZPosF(),
                hook.posX, hook.posY, hook.posZ)) {
            return;
        }
        startSplashToPullTimer(hook.getEntityId(), System.currentTimeMillis());
    }

    void updateSplashToPullTimerState(boolean bobberActive, int entityId,
                                      double bobberY, long now) {
        if (!bobberActive) {
            splashToPullBobberEntityId = -1;
            previousSplashToPullBobberY = 0.0D;
            splashToPullSampleWindowStartY = 0.0D;
            splashToPullSampleWindowStartedAt = 0L;
            splashToPullBobberObservedAt = 0L;
            if (splashToPullTimerActive) {
                splashToPullTimerActive = false;
                splashToPullTimerHasValue = false;
                splashToPullTimerStartedAt = 0L;
                lastSplashToPullDurationMillis = 0L;
            }
            return;
        }

        if (splashToPullBobberEntityId != entityId) {
            splashToPullBobberEntityId = entityId;
            previousSplashToPullBobberY = bobberY;
            splashToPullSampleWindowStartY = bobberY;
            splashToPullSampleWindowStartedAt = now;
            splashToPullBobberObservedAt = now;
            splashToPullTimerActive = false;
            splashToPullTimerHasValue = false;
            splashToPullTimerStartedAt = 0L;
            lastSplashToPullDurationMillis = 0L;
            return;
        }

        double verticalChange = bobberY - previousSplashToPullBobberY;
        long elapsedSinceCast = Math.max(0L, now - splashToPullBobberObservedAt);
        long sampleWindowElapsed = now - splashToPullSampleWindowStartedAt;
        double windowVerticalChange = bobberY - splashToPullSampleWindowStartY;
        if (sampleWindowElapsed < 0L || sampleWindowElapsed > BITE_ALERT_SAMPLE_WINDOW_MS) {
            splashToPullSampleWindowStartY = previousSplashToPullBobberY;
            splashToPullSampleWindowStartedAt = now;
            windowVerticalChange = verticalChange;
        }
        previousSplashToPullBobberY = bobberY;

        boolean pulled = isFishingBitePullDown(verticalChange, elapsedSinceCast)
                || isFishingBitePullDown(windowVerticalChange, elapsedSinceCast);
        if (pulled && splashToPullTimerActive) {
            lastSplashToPullDurationMillis = Math.max(0L, now - splashToPullTimerStartedAt);
            splashToPullTimerActive = false;
            splashToPullTimerHasValue = true;
        }
    }

    boolean startSplashToPullTimer(int entityId, long now) {
        if (entityId < 0 || entityId != splashToPullBobberEntityId
                || now - splashToPullBobberObservedAt < BITE_ALERT_ARM_DELAY_MS
                || splashToPullTimerActive || splashToPullTimerHasValue) {
            return false;
        }
        splashToPullTimerStartedAt = now;
        lastSplashToPullDurationMillis = 0L;
        splashToPullTimerActive = true;
        splashToPullTimerHasValue = true;
        return true;
    }

    boolean hasSplashToPullTimer() {
        return splashToPullTimerHasValue;
    }

    boolean isSplashToPullTimerActive() {
        return splashToPullTimerActive;
    }

    long getSplashToPullTimerElapsedMillis(long now) {
        if (!splashToPullTimerHasValue) {
            return 0L;
        }
        return splashToPullTimerActive
                ? Math.max(0L, now - splashToPullTimerStartedAt)
                : lastSplashToPullDurationMillis;
    }

    void updateBiteAlertState(boolean enabled, boolean bobberActive, int entityId,
                              double bobberY, long now) {
        if (!enabled || !bobberActive) {
            resetBiteAlertDetection();
            return;
        }

        if (biteAlertBobberEntityId != entityId) {
            biteAlertBobberEntityId = entityId;
            previousFishingBobberY = bobberY;
            biteAlertSampleWindowStartY = bobberY;
            biteAlertSampleWindowStartedAt = now;
            fishingBobberObservedAt = now;
            biteAlertTriggeredForBobber = false;
            biteAlertTicksRemaining = 0;
            return;
        }

        double verticalChange = bobberY - previousFishingBobberY;
        long elapsedSinceCast = Math.max(0L, now - fishingBobberObservedAt);
        long sampleWindowElapsed = now - biteAlertSampleWindowStartedAt;
        double windowVerticalChange = bobberY - biteAlertSampleWindowStartY;
        if (sampleWindowElapsed < 0L || sampleWindowElapsed > BITE_ALERT_SAMPLE_WINDOW_MS) {
            biteAlertSampleWindowStartY = previousFishingBobberY;
            biteAlertSampleWindowStartedAt = now;
            windowVerticalChange = verticalChange;
        }
        previousFishingBobberY = bobberY;

        boolean detectedBite = isFishingBitePullDown(verticalChange, elapsedSinceCast)
                || isFishingBitePullDown(windowVerticalChange, elapsedSinceCast);
        if (detectedBite && !biteAlertTriggeredForBobber) {
            biteAlertTicksRemaining = BITE_ALERT_DURATION_TICKS;
            biteAlertTriggeredForBobber = true;
        } else if (biteAlertTicksRemaining > 0) {
            biteAlertTicksRemaining--;
        }
    }

    private void updateDeployableTimersFromClient(long now) {
        Minecraft minecraft = Minecraft.getMinecraft();
        if (minecraft == null || minecraft.thePlayer == null || minecraft.theWorld == null) {
            resetDeployableTrackingState();
            lastDeployablesWorld = null;
            return;
        }

        if (lastDeployablesWorld != minecraft.theWorld) {
            resetDeployableTrackingState();
            lastDeployablesWorld = minecraft.theWorld;
            nextDeployableScanAt = 0L;
        }
        if (!sosFlareTimerEnabled) {
            resetSosFlareTimer();
        }

        if (now < nextDeployableScanAt) {
            return;
        }
        nextDeployableScanAt = now + DEPLOYABLE_SCAN_INTERVAL_MS;
        if (totemTimerEnabled) {
            updateTotemRemainingTime(minecraft, now);
        } else {
            resetTotemRemainingTime();
        }
        if (sosFlareTimerEnabled && sosFlareExpiresAt > 0L && now >= sosFlareExpiresAt) {
            resetSosFlareTimer();
        }
        if (plasmafluxTimerEnabled && plasmafluxExpiresAt > 0L && now >= plasmafluxExpiresAt) {
            resetPlasmafluxTimer();
        } else if (!plasmafluxTimerEnabled) {
            resetPlasmafluxTimer();
        }
    }

    private void updateNearbyCreatureHpFromClient(long now) {
        if (!nearbyCreatureHpEnabled) {
            nearbyCreatureHpEntries.clear();
            nextNearbyCreatureHpScanAt = 0L;
            lastNearbyCreatureHpWorld = null;
            return;
        }
        Minecraft minecraft = Minecraft.getMinecraft();
        if (minecraft == null || minecraft.theWorld == null || minecraft.thePlayer == null) {
            nearbyCreatureHpEntries.clear();
            nextNearbyCreatureHpScanAt = 0L;
            lastNearbyCreatureHpWorld = null;
            return;
        }
        if (lastNearbyCreatureHpWorld != minecraft.theWorld) {
            nearbyCreatureHpEntries.clear();
            lastNearbyCreatureHpWorld = minecraft.theWorld;
            nextNearbyCreatureHpScanAt = 0L;
        }
        if (now < nextNearbyCreatureHpScanAt) {
            return;
        }
        nextNearbyCreatureHpScanAt = now + NEARBY_CREATURE_HP_SCAN_INTERVAL_MS;

        List<NearbyCreatureHpEntry> detected = new ArrayList<NearbyCreatureHpEntry>();
        double maxDistanceSq = NEARBY_CREATURE_HP_RANGE_BLOCKS * NEARBY_CREATURE_HP_RANGE_BLOCKS;
        for (Object loadedEntity : minecraft.theWorld.loadedEntityList) {
            if (!(loadedEntity instanceof EntityLivingBase)) {
                continue;
            }
            EntityLivingBase living = (EntityLivingBase) loadedEntity;
            if (living == minecraft.thePlayer || living.isDead) {
                continue;
            }
            double distanceSq = living.getDistanceSqToEntity(minecraft.thePlayer);
            if (distanceSq > maxDistanceSq) {
                continue;
            }
            String displayName = living.getDisplayName() == null ? ""
                    : living.getDisplayName().getUnformattedText();
            NearbyCreatureHpEntry parsed = parseNearbyCreatureHpLabel(
                    displayName, living.getEntityId(), distanceSq);
            String customName = living.getCustomNameTag();
            if (customName != null && customName.length() > 0
                    && (parsed == null || parsed.currentHealth.length() == 0
                    || parsed.maxHealth.length() == 0)) {
                NearbyCreatureHpEntry customParsed = parseNearbyCreatureHpLabel(
                        customName, living.getEntityId(), distanceSq);
                if (customParsed != null) {
                    parsed = customParsed;
                }
            }
            if (parsed == null) {
                continue;
            }
            if (parsed.currentHealth.length() == 0 || parsed.maxHealth.length() == 0) {
                if (living instanceof EntityArmorStand) {
                    continue;
                }
                float health = living.getHealth();
                float maxHealth = living.getMaxHealth();
                if (Float.isNaN(health) || Float.isInfinite(health)
                        || Float.isNaN(maxHealth) || Float.isInfinite(maxHealth) || maxHealth <= 0.0F) {
                    continue;
                }
                parsed = new NearbyCreatureHpEntry(parsed.creatureName, parsed.level,
                        formatNearbyCreatureHpValue(health), formatNearbyCreatureHpValue(maxHealth),
                        living.getEntityId(), distanceSq);
            }
            detected.add(parsed);
        }
        Collections.sort(detected, new Comparator<NearbyCreatureHpEntry>() {
            @Override
            public int compare(NearbyCreatureHpEntry first, NearbyCreatureHpEntry second) {
                return Double.compare(first.distanceSq, second.distanceSq);
            }
        });
        if (detected.size() > MAX_NEARBY_CREATURE_HP_ROWS) {
            detected = new ArrayList<NearbyCreatureHpEntry>(
                    detected.subList(0, MAX_NEARBY_CREATURE_HP_ROWS));
        }
        nearbyCreatureHpEntries.clear();
        nearbyCreatureHpEntries.addAll(detected);
    }

    private void updateTotemRemainingTime(Minecraft minecraft, long now) {
        EntityArmorStand ownerStand = null;
        String playerName = minecraft.thePlayer.getName();
        for (Object loadedEntity : minecraft.theWorld.loadedEntityList) {
            if (!(loadedEntity instanceof EntityArmorStand)) {
                continue;
            }
            EntityArmorStand armorStand = (EntityArmorStand) loadedEntity;
            String name = stripFormattingCodes(armorStand.getCustomNameTag());
            if (name.contains("Owner:") && name.toLowerCase(Locale.ROOT)
                    .contains(playerName.toLowerCase(Locale.ROOT))) {
                ownerStand = armorStand;
                break;
            }
        }
        if (ownerStand == null) {
            preserveTotemFallbackUntilExpiry(now);
            return;
        }

        Entity possibleTotem = minecraft.theWorld.getEntityByID(ownerStand.getEntityId() - 2);
        Entity possibleRemaining = minecraft.theWorld.getEntityByID(ownerStand.getEntityId() - 1);
        if (!(possibleTotem instanceof EntityArmorStand)
                || !(possibleRemaining instanceof EntityArmorStand)) {
            preserveTotemFallbackUntilExpiry(now);
            return;
        }
        String totemName = stripFormattingCodes(
                ((EntityArmorStand) possibleTotem).getCustomNameTag()).trim();
        String remainingName = stripFormattingCodes(
                ((EntityArmorStand) possibleRemaining).getCustomNameTag()).trim();
        if (!"Totem of Corruption".equalsIgnoreCase(totemName)
                || !remainingName.toLowerCase(Locale.ROOT).contains("remaining:")) {
            preserveTotemFallbackUntilExpiry(now);
            return;
        }

        updateTotemTimerState(remainingName, now);
    }

    private void preserveTotemFallbackUntilExpiry(long now) {
        if (getTotemRemainingSeconds(now) <= 0) {
            resetTotemRemainingTime();
        }
    }

    void startTotemFallbackTimer(long now) {
        totemRemainingSeconds = TOTEM_CORRUPTION_DURATION_SECONDS;
        totemTimerObservedAt = now;
    }

    void updateTotemTimerState(String remainingName, long now) {
        int seconds = parseDeployableTimerSeconds(remainingName);
        if (seconds <= 0) {
            resetTotemRemainingTime();
            return;
        }
        totemRemainingSeconds = seconds;
        totemTimerObservedAt = now;
    }

    private void resetTotemRemainingTime() {
        totemRemainingSeconds = -1;
        totemTimerObservedAt = 0L;
    }

    private void resetSosFlareTimer() {
        sosFlareExpiresAt = 0L;
    }

    private void resetPlasmafluxTimer() {
        plasmafluxExpiresAt = 0L;
    }

    private void resetDeployableTrackingState() {
        resetTotemRemainingTime();
        resetSosFlareTimer();
        resetPlasmafluxTimer();
    }

    private void showLordJawbusTitle() {
        Minecraft minecraft = Minecraft.getMinecraft();
        if (minecraft != null && minecraft.ingameGUI != null) {
            minecraft.ingameGUI.displayTitle("\u00A7c\u00A7lLORD JAWBUS", "", 1, 45, 1);
        }
    }

    static boolean isLordJawbusAlertMessage(String message) {
        if (message == null) {
            return false;
        }
        String plain = stripFormattingCodes(message).replace('\n', ' ').trim()
                .replaceAll("\\s+", " ");
        return plain.toUpperCase(Locale.ROOT).startsWith(
                "YOU HAVE ANGERED A LEGENDARY CREATURE... LORD JAWBUS HAS ARRIVED");
    }

    static boolean isSosFlareRemovedMessage(String message) {
        if (message == null) {
            return false;
        }
        String upper = stripFormattingCodes(message).trim().toUpperCase(Locale.ROOT);
        return upper.contains("YOUR FLARE DISAPPEARED BECAUSE YOU WERE TOO FAR AWAY")
                || upper.contains("YOUR PREVIOUS SOS FLARE WAS REMOVED");
    }

    static boolean isTotemOfCorruptionItemName(String itemName) {
        return itemName != null
                && stripFormattingCodes(itemName).toUpperCase(Locale.ROOT)
                        .contains("TOTEM OF CORRUPTION");
    }

    static boolean isSosFlareItemName(String itemName) {
        return itemName != null && stripFormattingCodes(itemName).toUpperCase(Locale.ROOT)
                .contains("SOS FLARE");
    }

    static boolean isPlasmafluxPowerOrbItemName(String itemName) {
        if (itemName == null) {
            return false;
        }
        String normalized = stripFormattingCodes(itemName).toUpperCase(Locale.ROOT);
        return normalized.contains("PLASMAFLUX") && normalized.contains("POWER ORB");
    }

    static int parseDeployableTimerSeconds(String displayName) {
        if (displayName == null) {
            return -1;
        }
        Matcher matcher = DEPLOYABLE_REMAINING_TIME.matcher(stripFormattingCodes(displayName));
        if (!matcher.find()) {
            return -1;
        }
        try {
            long minutes = matcher.group(1) == null ? 0L : Long.parseLong(matcher.group(1));
            long seconds = Long.parseLong(matcher.group(2));
            long total = minutes * 60L + seconds;
            return total > Integer.MAX_VALUE ? Integer.MAX_VALUE : (int) total;
        } catch (NumberFormatException ignored) {
            return -1;
        }
    }

    static String formatDeployableTimer(int totalSeconds) {
        int seconds = Math.max(0, totalSeconds);
        if (seconds >= 60) {
            return (seconds / 60) + "m " + String.format(Locale.ROOT, "%02d", seconds % 60) + "s";
        }
        return String.format(Locale.ROOT, "%02d", seconds) + "s";
    }

    void startSosFlareTimer(long now) {
        sosFlareExpiresAt = now + SOS_FLARE_DURATION_MS;
    }

    int getSosFlareRemainingSeconds(long now) {
        if (!sosFlareTimerEnabled || sosFlareExpiresAt <= now) {
            return 0;
        }
        return (int) Math.min(Integer.MAX_VALUE,
                (sosFlareExpiresAt - now + 999L) / 1000L);
    }

    void startPlasmafluxTimer(long now) {
        plasmafluxExpiresAt = now + PLASMAFLUX_DURATION_MS;
    }

    int getPlasmafluxRemainingSeconds(long now) {
        if (!plasmafluxTimerEnabled || plasmafluxExpiresAt <= now) {
            return 0;
        }
        return (int) Math.min(Integer.MAX_VALUE,
                (plasmafluxExpiresAt - now + 999L) / 1000L);
    }

    int getTotemRemainingSeconds(long now) {
        if (!totemTimerEnabled || totemRemainingSeconds <= 0 || now < totemTimerObservedAt) {
            return 0;
        }
        long elapsedSeconds = (now - totemTimerObservedAt) / 1000L;
        return (int) Math.max(0L, totemRemainingSeconds - elapsedSeconds);
    }

    boolean isDeployablesTimerPanelVisible() {
        return isDeployablesTimerPanelVisible(System.currentTimeMillis());
    }

    boolean isDeployablesTimerPanelVisible(long now) {
        return deployablesTimerPanelEnabled
                && (getTotemRemainingSeconds(now) > 0 || getSosFlareRemainingSeconds(now) > 0
                || getPlasmafluxRemainingSeconds(now) > 0);
    }

    boolean isDeployablesTimerPanelEnabled() {
        return deployablesTimerPanelEnabled;
    }

    boolean isTotemTimerEnabled() {
        return totemTimerEnabled;
    }

    boolean isSosFlareTimerEnabled() {
        return sosFlareTimerEnabled;
    }

    boolean isPlasmafluxTimerEnabled() {
        return plasmafluxTimerEnabled;
    }

    void toggleTotemTimer() {
        totemTimerEnabled = !totemTimerEnabled;
        if (!totemTimerEnabled) {
            resetTotemRemainingTime();
        }
        saveSettings();
    }

    void toggleSosFlareTimer() {
        sosFlareTimerEnabled = !sosFlareTimerEnabled;
        if (!sosFlareTimerEnabled) {
            resetSosFlareTimer();
        }
        saveSettings();
    }

    void togglePlasmafluxTimer() {
        plasmafluxTimerEnabled = !plasmafluxTimerEnabled;
        if (!plasmafluxTimerEnabled) {
            resetPlasmafluxTimer();
        }
        saveSettings();
    }

    boolean isM7OverlayEnabled() {
        return m7OverlayEnabled;
    }

    boolean shouldRenderWorldOverlay() {
        return m7OverlayEnabled && shouldRenderCustomHudPanels(isPlayerListKeyDown());
    }

    void toggleM7Overlay() {
        m7OverlayEnabled = !m7OverlayEnabled;
        saveSettings();
    }

    boolean isM7BossHitboxEnabled(M7OverlayRenderer.M7HitboxTarget target) {
        if (target == null) {
            return false;
        }
        switch (target) {
            case MAXOR:
                return m7MaxorEnabled;
            case STORM:
                return m7StormEnabled;
            case GOLDOR:
                return m7GoldorEnabled;
            case NECRON:
                return m7NecronEnabled;
            default:
                return false;
        }
    }

    void toggleM7BossHitbox(M7OverlayRenderer.M7HitboxTarget target) {
        if (target == null) {
            return;
        }
        switch (target) {
            case MAXOR:
                m7MaxorEnabled = !m7MaxorEnabled;
                break;
            case STORM:
                m7StormEnabled = !m7StormEnabled;
                break;
            case GOLDOR:
                m7GoldorEnabled = !m7GoldorEnabled;
                break;
            case NECRON:
                m7NecronEnabled = !m7NecronEnabled;
                break;
            default:
                return;
        }
        saveSettings();
    }

    boolean isM7DragonHitboxEnabled(M7OverlayRenderer.M7DragonStatue statue) {
        if (statue == null) {
            return false;
        }
        switch (statue) {
            case POWER:
                return m7PowerDragonEnabled;
            case APEX:
                return m7ApexDragonEnabled;
            case SOUL:
                return m7SoulDragonEnabled;
            case ICE:
                return m7IceDragonEnabled;
            case FLAME:
                return m7FlameDragonEnabled;
            default:
                return false;
        }
    }

    void toggleM7DragonHitbox(M7OverlayRenderer.M7DragonStatue statue) {
        if (statue == null) {
            return;
        }
        switch (statue) {
            case POWER:
                m7PowerDragonEnabled = !m7PowerDragonEnabled;
                break;
            case APEX:
                m7ApexDragonEnabled = !m7ApexDragonEnabled;
                break;
            case SOUL:
                m7SoulDragonEnabled = !m7SoulDragonEnabled;
                break;
            case ICE:
                m7IceDragonEnabled = !m7IceDragonEnabled;
                break;
            case FLAME:
                m7FlameDragonEnabled = !m7FlameDragonEnabled;
                break;
            default:
                return;
        }
        saveSettings();
    }

    boolean isM7StatueZonesEnabled() {
        return m7StatueZonesEnabled;
    }

    void toggleM7StatueZones() {
        m7StatueZonesEnabled = !m7StatueZonesEnabled;
        saveSettings();
    }

    boolean isJawbusAlertEnabled() {
        return jawbusAlertEnabled;
    }

    void toggleJawbusAlert() {
        jawbusAlertEnabled = !jawbusAlertEnabled;
        saveSettings();
    }

    void toggleDeployablesTimerPanel() {
        deployablesTimerPanelEnabled = !deployablesTimerPanelEnabled;
        saveSettings();
    }

    int getDeployablesTimerPanelX() {
        return deployablesTimerPanelX;
    }

    int getDeployablesTimerPanelY() {
        return deployablesTimerPanelY;
    }

    int getDeployablesTimerPanelSizePercent() {
        return deployablesTimerPanelSizePercent;
    }

    float getDeployablesTimerPanelScale() {
        return deployablesTimerPanelSizePercent / 100.0F;
    }

    int getRenderedDeployablesTimerPanelWidth(int screenWidth) {
        return Math.round(Math.min(DEPLOYABLE_PANEL_WIDTH, Math.max(80, screenWidth - 20))
                * getDeployablesTimerPanelScale());
    }

    int getRenderedDeployablesTimerPanelHeight() {
        return Math.round((HEADER_HEIGHT + 6 + 3 * ITEM_ONLY_ENTRY_HEIGHT + 7)
                * getDeployablesTimerPanelScale());
    }

    void moveDeployablesTimerPanelTo(int x, int y, int screenWidth, int screenHeight) {
        int renderedWidth = getRenderedDeployablesTimerPanelWidth(screenWidth);
        int renderedHeight = getRenderedDeployablesTimerPanelHeight();
        deployablesTimerPanelX = clamp(x, 0, Math.max(0, screenWidth - renderedWidth));
        deployablesTimerPanelY = clamp(y, 0, Math.max(0, screenHeight - renderedHeight));
        deployablesTimerPanelPositionConfigured = true;
    }

    void clampDeployablesTimerPanelPosition(int screenWidth, int screenHeight) {
        boolean wasConfigured = deployablesTimerPanelPositionConfigured;
        int oldX = deployablesTimerPanelX;
        int oldY = deployablesTimerPanelY;
        if (!deployablesTimerPanelPositionConfigured) {
            deployablesTimerPanelX = 10;
            deployablesTimerPanelY = Math.max(0, screenHeight / 2 - 20);
            deployablesTimerPanelPositionConfigured = true;
        }
        moveDeployablesTimerPanelTo(deployablesTimerPanelX, deployablesTimerPanelY,
                screenWidth, screenHeight);
        if (!wasConfigured || oldX != deployablesTimerPanelX || oldY != deployablesTimerPanelY) {
            saveSettings();
        }
    }

    void resetDeployablesTimerPanelPosition(int screenWidth, int screenHeight) {
        deployablesTimerPanelPositionConfigured = false;
        clampDeployablesTimerPanelPosition(screenWidth, screenHeight);
        saveSettings();
    }

    void adjustDeployablesTimerPanelSize(int delta, int screenWidth, int screenHeight) {
        deployablesTimerPanelSizePercent = clamp(deployablesTimerPanelSizePercent + delta, 70, 150);
        clampDeployablesTimerPanelPosition(screenWidth, screenHeight);
        saveSettings();
    }

    void resetDeployablesTimerPanelSize(int screenWidth, int screenHeight) {
        deployablesTimerPanelSizePercent = 100;
        clampDeployablesTimerPanelPosition(screenWidth, screenHeight);
        saveSettings();
    }

    boolean isNearbyCreatureHpEnabled() {
        return nearbyCreatureHpEnabled;
    }

    boolean isNearbyCreatureHpVisible() {
        return nearbyCreatureHpEnabled && !nearbyCreatureHpEntries.isEmpty();
    }

    void toggleNearbyCreatureHp() {
        nearbyCreatureHpEnabled = !nearbyCreatureHpEnabled;
        nextNearbyCreatureHpScanAt = 0L;
        if (!nearbyCreatureHpEnabled) {
            nearbyCreatureHpEntries.clear();
        }
        saveSettings();
    }

    int getNearbyCreatureHpX() {
        return nearbyCreatureHpX;
    }

    int getNearbyCreatureHpY() {
        return nearbyCreatureHpY;
    }

    int getNearbyCreatureHpSizePercent() {
        return nearbyCreatureHpSizePercent;
    }

    float getNearbyCreatureHpScale() {
        return nearbyCreatureHpSizePercent / 100.0F;
    }

    int getRenderedNearbyCreatureHpPanelWidth(int screenWidth) {
        return Math.round(getNearbyCreatureHpPanelWidth(screenWidth) * getNearbyCreatureHpScale());
    }

    int getRenderedNearbyCreatureHpPanelHeight() {
        return Math.round(getNearbyCreatureHpPanelHeight() * getNearbyCreatureHpScale());
    }

    private int getNearbyCreatureHpPanelWidth(int screenWidth) {
        int availableWidth = (int) (Math.max(100, screenWidth - 8) / getNearbyCreatureHpScale());
        return Math.min(NEARBY_CREATURE_HP_PANEL_WIDTH, Math.max(100, availableWidth));
    }

    private int getNearbyCreatureHpPanelHeight() {
        int rows = nearbyCreatureHpEntries.isEmpty() ? 3
                : Math.min(MAX_NEARBY_CREATURE_HP_ROWS, nearbyCreatureHpEntries.size());
        return HEADER_HEIGHT + 6 + rows * ITEM_ONLY_ENTRY_HEIGHT + 4;
    }

    void moveNearbyCreatureHpPanelTo(int x, int y, int screenWidth, int screenHeight) {
        int renderedWidth = getRenderedNearbyCreatureHpPanelWidth(screenWidth);
        int renderedHeight = getRenderedNearbyCreatureHpPanelHeight();
        nearbyCreatureHpX = clamp(x, 0, Math.max(0, screenWidth - renderedWidth));
        nearbyCreatureHpY = clamp(y, 0, Math.max(0, screenHeight - renderedHeight));
        nearbyCreatureHpPositionConfigured = true;
    }

    void clampNearbyCreatureHpPosition(int screenWidth, int screenHeight) {
        boolean wasConfigured = nearbyCreatureHpPositionConfigured;
        int oldX = nearbyCreatureHpX;
        int oldY = nearbyCreatureHpY;
        if (!nearbyCreatureHpPositionConfigured) {
            nearbyCreatureHpX = 10;
            nearbyCreatureHpY = Math.min(145, Math.max(0, screenHeight / 3));
            nearbyCreatureHpPositionConfigured = true;
        }
        moveNearbyCreatureHpPanelTo(nearbyCreatureHpX, nearbyCreatureHpY,
                screenWidth, screenHeight);
        if (!wasConfigured || oldX != nearbyCreatureHpX || oldY != nearbyCreatureHpY) {
            saveSettings();
        }
    }

    void resetNearbyCreatureHpPosition(int screenWidth, int screenHeight) {
        nearbyCreatureHpPositionConfigured = false;
        clampNearbyCreatureHpPosition(screenWidth, screenHeight);
        saveSettings();
    }

    void adjustNearbyCreatureHpSize(int delta, int screenWidth, int screenHeight) {
        nearbyCreatureHpSizePercent = clamp(nearbyCreatureHpSizePercent + delta, 70, 150);
        clampNearbyCreatureHpPosition(screenWidth, screenHeight);
        saveSettings();
    }

    void resetNearbyCreatureHpSize(int screenWidth, int screenHeight) {
        nearbyCreatureHpSizePercent = 100;
        clampNearbyCreatureHpPosition(screenWidth, screenHeight);
        saveSettings();
    }

    private void resetBiteAlertDetection() {
        biteAlertBobberEntityId = -1;
        previousFishingBobberY = 0.0D;
        biteAlertSampleWindowStartY = 0.0D;
        biteAlertSampleWindowStartedAt = 0L;
        biteAlertTriggeredForBobber = false;
        fishingBobberObservedAt = 0L;
        biteAlertTicksRemaining = 0;
    }

    static boolean isFishingSplashSound(String soundName) {
        return soundName != null && soundName.toLowerCase(Locale.US).contains("splash");
    }

    static boolean isFishingSplashNearBobber(String soundName,
                                             double soundX, double soundY, double soundZ,
                                             double bobberX, double bobberY, double bobberZ) {
        if (!isFishingSplashSound(soundName)) {
            return false;
        }
        double dx = soundX - bobberX;
        double dy = soundY - bobberY;
        double dz = soundZ - bobberZ;
        double maxDistanceSq = FISHING_SPLASH_SOUND_RANGE_BLOCKS
                * FISHING_SPLASH_SOUND_RANGE_BLOCKS;
        return dx * dx + dy * dy + dz * dz <= maxDistanceSq;
    }

    static String formatSplashToPullDuration(long elapsedMillis) {
        return String.format(Locale.US, "%.2fs", Math.max(0L, elapsedMillis) / 1000.0D);
    }

    static boolean isFishingBitePullDown(double verticalChange, long elapsedSinceCastMillis) {
        return elapsedSinceCastMillis >= BITE_ALERT_ARM_DELAY_MS
                && verticalChange <= BITE_ALERT_PULL_DOWN_THRESHOLD
                        + BITE_ALERT_DISPLACEMENT_EPSILON;
    }

    void startSlayerBossTimer(SlayerType slayer, long now) {
        if (slayer == null) {
            return;
        }
        if (slayerBossTimerActive && slayerBossTimerType == slayer) {
            return;
        }
        slayerBossTimerType = slayer;
        slayerBossTimerStartedAt = now;
        slayerBossTimerActive = true;
        slayerBossTimerHasValue = true;
    }

    void completeSlayerBossTimer(long now) {
        if (!slayerBossTimerActive) {
            return;
        }
        lastSlayerBossDurationMillis = Math.max(0L, now - slayerBossTimerStartedAt);
        slayerBossTimerActive = false;
    }

    boolean hasSlayerBossTimer() {
        return slayerBossTimerHasValue;
    }

    boolean isSlayerBossTimerActive() {
        return slayerBossTimerActive;
    }

    long getSlayerBossTimerElapsedMillis(long now) {
        if (!slayerBossTimerHasValue) {
            return 0L;
        }
        return slayerBossTimerActive
                ? Math.max(0L, now - slayerBossTimerStartedAt) : lastSlayerBossDurationMillis;
    }

    private void resetFishingTimer() {
        fishingBobberWasActive = false;
        fishingTimerActive = false;
        fishingTimerHasValue = false;
        fishingTimerStartedAt = 0L;
        lastFishingDurationMillis = 0L;
        resetSplashToPullTimer();
    }

    private void resetSplashToPullTimer() {
        splashToPullTimerActive = false;
        splashToPullTimerHasValue = false;
        splashToPullTimerStartedAt = 0L;
        lastSplashToPullDurationMillis = 0L;
        splashToPullBobberEntityId = -1;
        previousSplashToPullBobberY = 0.0D;
        splashToPullSampleWindowStartY = 0.0D;
        splashToPullSampleWindowStartedAt = 0L;
        splashToPullBobberObservedAt = 0L;
    }

    private void resetSlayerBossTimer() {
        slayerBossTimerActive = false;
        slayerBossTimerHasValue = false;
        slayerBossTimerType = null;
        slayerBossTimerStartedAt = 0L;
        lastSlayerBossDurationMillis = 0L;
    }

    static String formatTimerDuration(long elapsedMillis) {
        long totalSeconds = Math.max(0L, elapsedMillis) / 1000L;
        long seconds = totalSeconds % 60L;
        long minutes = (totalSeconds / 60L) % 60L;
        long hours = totalSeconds / 3600L;
        return hours > 0L
                ? String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
                : String.format(Locale.US, "%02d:%02d", totalSeconds / 60L, seconds);
    }

    static String formatLegendaryCreatureLabel(LegendaryCreature creature, long count) {
        return creature.displayName + "-" + formatPrice(Math.max(0L, count));
    }

    static NearbyCreatureHpEntry parseNearbyCreatureHpLabel(String displayName) {
        return parseNearbyCreatureHpLabel(displayName, -1, Double.MAX_VALUE);
    }

    private static NearbyCreatureHpEntry parseNearbyCreatureHpLabel(String displayName,
                                                                     int entityId,
                                                                     double distanceSq) {
        if (displayName == null || displayName.length() == 0) {
            return null;
        }
        String plain = stripFormattingCodes(displayName).replace('\r', ' ')
                .replace('\n', ' ').replace('\u00A0', ' ')
                .replaceAll("(?i)SEA\\s+CREATURES\\s+HP", " ")
                .replaceAll("\\s+", " ").trim();
        if (plain.length() == 0) {
            return null;
        }

        String currentHealth = "";
        String maxHealth = "";
        String creaturePart = plain;
        Matcher health = NEARBY_CREATURE_HEALTH.matcher(plain);
        if (health.find()) {
            currentHealth = health.group(1).replaceAll("\\s+", "");
            maxHealth = health.group(2).replaceAll("\\s+", "");
            creaturePart = plain.substring(0, health.start()).trim();
        }

        int level = -1;
        Matcher levelMatcher = NEARBY_CREATURE_LEVEL.matcher(creaturePart);
        if (levelMatcher.find()) {
            try {
                level = Integer.parseInt(levelMatcher.group(1));
            } catch (NumberFormatException ignored) {
                level = -1;
            }
            creaturePart = creaturePart.substring(0, levelMatcher.start()) + " "
                    + creaturePart.substring(levelMatcher.end());
        }
        creaturePart = creaturePart.replaceAll("(?i)SEA\\s+CREATURES\\s+HP", " ")
                .replaceAll("[>\\u00BB\\u203A\\u27A4\\u2192]+", " ").trim();
        String creatureName = canonicalNearbySeaCreatureName(creaturePart);
        if (creatureName == null) {
            return null;
        }
        return new NearbyCreatureHpEntry(creatureName, level, currentHealth, maxHealth,
                entityId, distanceSq);
    }

    private static String canonicalNearbySeaCreatureName(String name) {
        if (name == null) {
            return null;
        }
        String normalized = normalizeNearbyCreatureName(name);
        for (String trackedName : TRACKED_NEARBY_SEA_CREATURES) {
            if (normalized.equals(normalizeNearbyCreatureName(trackedName))) {
                return trackedName;
            }
        }
        for (String trackedName : TRACKED_NEARBY_SEA_CREATURES) {
            String candidate = normalizeNearbyCreatureName(trackedName);
            if (normalized.startsWith(candidate + " ") || normalized.endsWith(" " + candidate)
                    || normalized.contains(" " + candidate + " ")) {
                return trackedName;
            }
        }
        return null;
    }

    private static String normalizeNearbyCreatureName(String name) {
        return stripFormattingCodes(name).replaceAll("[^A-Za-z0-9]+", " ")
                .trim().replaceAll("\\s+", " ").toUpperCase(Locale.ROOT);
    }

    static String formatNearbyCreatureHpValue(double value) {
        double safeValue = Double.isNaN(value) || Double.isInfinite(value) ? 0.0D : Math.max(0.0D, value);
        if (safeValue >= 1000000000.0D) {
            return formatNearbyCreatureHpSuffix(safeValue, 1000000000.0D, "B");
        }
        if (safeValue >= 1000000.0D) {
            return formatNearbyCreatureHpSuffix(safeValue, 1000000.0D, "M");
        }
        if (safeValue >= 1000.0D) {
            return NumberFormat.getIntegerInstance(Locale.US).format(Math.round(safeValue));
        }
        return NumberFormat.getIntegerInstance(Locale.US).format(Math.round(safeValue));
    }

    private static String formatNearbyCreatureHpSuffix(double value, double divisor, String suffix) {
        String amount = BigDecimal.valueOf(value).divide(BigDecimal.valueOf(divisor),
                1, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString();
        return amount + suffix;
    }

    static long addDropQuantities(long existing, long added) {
        long safeExisting = Math.max(0L, existing);
        long safeAdded = Math.max(0L, added);
        return safeExisting > Long.MAX_VALUE - safeAdded
                ? Long.MAX_VALUE : safeExisting + safeAdded;
    }

    static long addPricedDropValue(long runningTotal, Long unitPrice, long quantity) {
        long safeTotal = Math.max(0L, runningTotal);
        if (unitPrice == null) {
            return safeTotal;
        }
        return addDropQuantities(safeTotal, calculateTotalPrice(unitPrice, quantity));
    }

    /** Renders the persistent tracker panel instead of a transient drop popup. */
    @SubscribeEvent
    public void onOverlay(RenderGameOverlayEvent.Post event) {
        if (event.type != RenderGameOverlayEvent.ElementType.ALL || event.resolution == null) {
            return;
        }
        if (!shouldRenderCustomHudPanels(isPlayerListKeyDown())) {
            return;
        }
        int screenWidth = event.resolution.getScaledWidth();
        int screenHeight = event.resolution.getScaledHeight();
        if (trackerEnabled) {
            drawTrackerPanel(screenWidth, screenHeight, false);
        }
        if (isFishingSectionVisible()) {
            clampFishingTrackerPosition(screenWidth, screenHeight);
            drawFishingTrackerPanel(screenWidth, screenHeight);
        }
        if (isBiteAlertShowing()) {
            clampBiteAlertPosition(screenWidth, screenHeight);
            drawBiteAlertMarker(screenWidth, screenHeight);
        }
        if (isDeployablesTimerPanelVisible()) {
            clampDeployablesTimerPanelPosition(screenWidth, screenHeight);
            drawDeployablesTimerPanel(screenWidth, screenHeight);
        }
        if (isNearbyCreatureHpVisible()) {
            clampNearbyCreatureHpPosition(screenWidth, screenHeight);
            drawNearbyCreatureHpPanel(screenWidth, screenHeight);
        }
    }

    static boolean shouldRenderCustomHudPanels(boolean playerListKeyDown) {
        return !playerListKeyDown;
    }

    private boolean isPlayerListKeyDown() {
        Minecraft minecraft = Minecraft.getMinecraft();
        if (minecraft == null || minecraft.gameSettings == null
                || minecraft.gameSettings.keyBindPlayerList == null) {
            return false;
        }
        int keyCode = minecraft.gameSettings.keyBindPlayerList.getKeyCode();
        return keyCode > 0 && Keyboard.isKeyDown(keyCode);
    }

    void drawTrackerPanel(int screenWidth, int screenHeight, boolean preview) {
        Minecraft minecraft = Minecraft.getMinecraft();
        if (minecraft == null || minecraft.fontRendererObj == null) {
            return;
        }

        FontRenderer font = minecraft.fontRendererObj;
        float scale = getTrackerScale();
        int panelWidth = getPanelWidth(screenWidth);
        int panelHeight = getPanelHeight();
        int renderedWidth = Math.round(panelWidth * scale);
        int renderedHeight = Math.round(panelHeight * scale);
        int x = clamp(trackerX, 0, Math.max(0, screenWidth - renderedWidth));
        int y = clamp(trackerY, 0, Math.max(0, screenHeight - renderedHeight));
        GlStateManager.pushMatrix();
        GlStateManager.translate((float) x, (float) y, 0.0F);
        GlStateManager.scale(scale, scale, 1.0F);

        List<DropEntry> activeDrops = getDropHistory(activeSlayer);
        font.drawStringWithShadow(font.trimStringToWidth("RNG carried bald", panelWidth - 12),
                6, 5, 0xFFFFFF);

        int rowY = HEADER_HEIGHT + 2;
        if (activeDrops.isEmpty()) {
            String waiting = "Waiting for drops...";
            font.drawStringWithShadow(font.trimStringToWidth(waiting, panelWidth - 12),
                    6, HEADER_HEIGHT + 5, 0xBBBBBB);
            rowY = HEADER_HEIGHT + 17;
        } else {
            for (int i = 0; i < activeDrops.size(); i++) {
                DropEntry entry = activeDrops.get(i);
                Long unitPrice = getItemPrice(entry.item);
                String totalValue = getDropValue(entry.quantity, unitPrice);
                String quantityPrefix = NumberFormat.getIntegerInstance(Locale.US).format(entry.quantity) + "x ";
                String valueSuffix = "(" + totalValue + ")";
                int nameWidth = Math.max(0, panelWidth - 12
                        - font.getStringWidth(quantityPrefix) - font.getStringWidth(valueSuffix));
                String itemLine = quantityPrefix
                        + font.trimStringToWidth(entry.item, nameWidth) + valueSuffix;

                font.drawStringWithShadow(font.trimStringToWidth(itemLine, panelWidth - 12),
                        6, rowY, 0xFFFFFF);
                rowY += ITEM_ONLY_ENTRY_HEIGHT;
            }
        }

        rowY += 3;
        Gui.drawRect(6, rowY, panelWidth - 6, rowY + 1, 0x88FFFF99);
        rowY += 5;
        String profitLine = "Total profit = " + formatCompactPrice(getVisibleTotalProfit());
        font.drawStringWithShadow(font.trimStringToWidth(profitLine, panelWidth - 12),
                6, rowY, 0xFFFF99);
        if (slayerBossTimerHasValue) {
            String timerLine = "Boss timer - " + formatTimerDuration(
                    getSlayerBossTimerElapsedMillis(System.currentTimeMillis()));
            font.drawStringWithShadow(font.trimStringToWidth(timerLine, panelWidth - 12),
                    6, rowY + ITEM_ONLY_ENTRY_HEIGHT, 0xE8E6EB);
        }

        GlStateManager.popMatrix();
    }

    void drawFishingTrackerPanel(int screenWidth, int screenHeight) {
        if (!isFishingSectionVisible()) {
            return;
        }
        Minecraft minecraft = Minecraft.getMinecraft();
        if (minecraft == null || minecraft.fontRendererObj == null) {
            return;
        }

        FontRenderer font = minecraft.fontRendererObj;
        float scale = getTrackerScale();
        int panelWidth = getPanelWidth(screenWidth);
        int panelHeight = getFishingPanelHeight();
        int renderedWidth = Math.round(panelWidth * scale);
        int renderedHeight = Math.round(panelHeight * scale);
        int x = clamp(fishingX, 0, Math.max(0, screenWidth - renderedWidth));
        int y = clamp(fishingY, 0, Math.max(0, screenHeight - renderedHeight));
        GlStateManager.pushMatrix();
        GlStateManager.translate((float) x, (float) y, 0.0F);
        GlStateManager.scale(scale, scale, 1.0F);

        font.drawStringWithShadow("Fishing", 6, 5, 0xFFFFFF);
        int rowY = HEADER_HEIGHT + 2;
        if (fishingTimerHasValue) {
            String timerLine = "Fishing timer - " + formatTimerDuration(
                    getFishingTimerElapsedMillis(System.currentTimeMillis()));
            font.drawStringWithShadow(font.trimStringToWidth(timerLine, panelWidth - 12),
                    6, rowY, 0xE8E6EB);
            rowY += ITEM_ONLY_ENTRY_HEIGHT;
        }
        if (splashToPullTimerHasValue) {
            String splashToPullLine = "Splash -> pull - "
                    + formatSplashToPullDuration(
                    getSplashToPullTimerElapsedMillis(System.currentTimeMillis()));
            font.drawStringWithShadow(font.trimStringToWidth(splashToPullLine, panelWidth - 12),
                    6, rowY, 0xE8E6EB);
            rowY += ITEM_ONLY_ENTRY_HEIGHT;
        }
        for (LegendaryCreature creature : LegendaryCreature.values()) {
            long count = getLegendaryCreatureCount(creature);
            if (count <= 0L) {
                continue;
            }
            String creatureLine = formatLegendaryCreatureLabel(creature, count);
            font.drawStringWithShadow(font.trimStringToWidth(creatureLine, panelWidth - 12),
                    6, rowY, 0xE8E6EB);
            rowY += ITEM_ONLY_ENTRY_HEIGHT;
        }
        if (getTotalLegendaryCreatureCount() == 0L && !fishingTimerHasValue) {
            font.drawStringWithShadow("Waiting for catches...", 6, rowY, 0xBBBBBB);
        }

        if (getTotalLegendaryCreatureCount() > 0L) {
            rowY += 3;
            Gui.drawRect(6, rowY, panelWidth - 6, rowY + 1, 0x88FFFF99);
            rowY += 5;
            String totalCreatureLine = "Total creature - "
                    + formatPrice(getTotalLegendaryCreatureCount());
            font.drawStringWithShadow(font.trimStringToWidth(totalCreatureLine, panelWidth - 12),
                    6, rowY, 0xFFFF99);
        }
        GlStateManager.popMatrix();
    }

    void drawDeployablesTimerPanel(int screenWidth, int screenHeight) {
        long now = System.currentTimeMillis();
        int totemSeconds = getTotemRemainingSeconds(now);
        int sosSeconds = getSosFlareRemainingSeconds(now);
        int plasmafluxSeconds = getPlasmafluxRemainingSeconds(now);
        if (!deployablesTimerPanelEnabled
                || (totemSeconds <= 0 && sosSeconds <= 0 && plasmafluxSeconds <= 0)) {
            return;
        }
        Minecraft minecraft = Minecraft.getMinecraft();
        if (minecraft == null || minecraft.fontRendererObj == null) {
            return;
        }

        FontRenderer font = minecraft.fontRendererObj;
        float scale = getDeployablesTimerPanelScale();
        int panelWidth = Math.min(DEPLOYABLE_PANEL_WIDTH, Math.max(80, screenWidth - 20));
        int rowCount = (totemSeconds > 0 ? 1 : 0) + (sosSeconds > 0 ? 1 : 0)
                + (plasmafluxSeconds > 0 ? 1 : 0);
        int panelHeight = HEADER_HEIGHT + 6 + rowCount * ITEM_ONLY_ENTRY_HEIGHT + 7;
        int renderedWidth = Math.round(panelWidth * scale);
        int renderedHeight = Math.round(panelHeight * scale);
        int x = clamp(deployablesTimerPanelX, 0, Math.max(0, screenWidth - renderedWidth));
        int y = clamp(deployablesTimerPanelY, 0, Math.max(0, screenHeight - renderedHeight));
        GlStateManager.pushMatrix();
        GlStateManager.translate((float) x, (float) y, 0.0F);
        GlStateManager.scale(scale, scale, 1.0F);

        font.drawStringWithShadow("Deployables", 6, 5, 0xFFFFFF);
        int rowY = HEADER_HEIGHT + 2;
        if (totemSeconds > 0) {
            int color = totemSeconds <= 10 ? 0xFF5555 : 0xE8E6EB;
            String line = "Totem of Corruption: " + formatDeployableTimer(totemSeconds);
            font.drawStringWithShadow(font.trimStringToWidth(line, panelWidth - 12), 6, rowY, color);
            rowY += ITEM_ONLY_ENTRY_HEIGHT;
        }
        if (sosSeconds > 0) {
            int color = sosSeconds <= 10 ? 0xFF5555 : 0xE8E6EB;
            String line = "SOS Flare: " + formatDeployableTimer(sosSeconds);
            font.drawStringWithShadow(font.trimStringToWidth(line, panelWidth - 12), 6, rowY, color);
            rowY += ITEM_ONLY_ENTRY_HEIGHT;
        }
        if (plasmafluxSeconds > 0) {
            int color = plasmafluxSeconds <= 10 ? 0xFF5555 : 0xE8E6EB;
            String line = "Plasmaflux Power Orb: " + formatDeployableTimer(plasmafluxSeconds);
            font.drawStringWithShadow(font.trimStringToWidth(line, panelWidth - 12), 6, rowY, color);
        }
        GlStateManager.popMatrix();
    }

    void drawNearbyCreatureHpPanel(int screenWidth, int screenHeight) {
        if (!isNearbyCreatureHpVisible() || nearbyCreatureHpEntries.isEmpty()) {
            return;
        }
        Minecraft minecraft = Minecraft.getMinecraft();
        if (minecraft == null || minecraft.fontRendererObj == null) {
            return;
        }

        FontRenderer font = minecraft.fontRendererObj;
        float scale = getNearbyCreatureHpScale();
        int panelWidth = getNearbyCreatureHpPanelWidth(screenWidth);
        int panelHeight = getNearbyCreatureHpPanelHeight();
        int renderedWidth = Math.round(panelWidth * scale);
        int renderedHeight = Math.round(panelHeight * scale);
        int x = clamp(nearbyCreatureHpX, 0, Math.max(0, screenWidth - renderedWidth));
        int y = clamp(nearbyCreatureHpY, 0, Math.max(0, screenHeight - renderedHeight));
        GlStateManager.pushMatrix();
        GlStateManager.translate((float) x, (float) y, 0.0F);
        GlStateManager.scale(scale, scale, 1.0F);

        font.drawStringWithShadow(font.trimStringToWidth("\u00A7e\u00A7lSea Creatures HP",
                panelWidth - 12), 6, 5, 0xFFFFFF);
        int rowY = HEADER_HEIGHT + 2;
        for (NearbyCreatureHpEntry entry : nearbyCreatureHpEntries) {
            font.drawStringWithShadow(font.trimStringToWidth(entry.toHudLabel(), panelWidth - 12),
                    6, rowY, 0xFFFFFF);
            rowY += ITEM_ONLY_ENTRY_HEIGHT;
        }
        GlStateManager.popMatrix();
    }

    void drawBiteAlertMarker(int screenWidth, int screenHeight) {
        if (!isBiteAlertShowing()) {
            return;
        }
        Minecraft minecraft = Minecraft.getMinecraft();
        if (minecraft == null || minecraft.fontRendererObj == null) {
            return;
        }
        clampBiteAlertPosition(screenWidth, screenHeight);
        GlStateManager.pushMatrix();
        GlStateManager.translate((float) biteAlertX, (float) biteAlertY, 0.0F);
        float scale = getBiteAlertRenderScale();
        GlStateManager.scale(scale, scale, 1.0F);
        minecraft.fontRendererObj.drawStringWithShadow(BITE_ALERT_SYMBOL, 0, 0, 0xFF3B3B);
        GlStateManager.popMatrix();
    }

    boolean isTrackerHeaderAt(int mouseX, int mouseY, int screenWidth, int screenHeight) {
        float scale = getTrackerScale();
        int panelWidth = Math.round(getPanelWidth(screenWidth) * scale);
        int panelHeight = Math.round(getPanelHeight() * scale);
        int x = clamp(trackerX, 0, Math.max(0, screenWidth - panelWidth));
        int y = clamp(trackerY, 0, Math.max(0, screenHeight - panelHeight));
        int headerHeight = Math.round(HEADER_HEIGHT * scale);
        return mouseX >= x && mouseX <= x + panelWidth
                && mouseY >= y && mouseY <= y + headerHeight;
    }

    void moveTrackerTo(int x, int y, int screenWidth, int screenHeight) {
        float scale = getTrackerScale();
        int panelWidth = Math.round(getPanelWidth(screenWidth) * scale);
        int panelHeight = Math.round(getPanelHeight() * scale);
        trackerX = clamp(x, 0, Math.max(0, screenWidth - panelWidth));
        trackerY = clamp(y, 0, Math.max(0, screenHeight - panelHeight));
    }

    boolean isFishingHeaderAt(int mouseX, int mouseY, int screenWidth, int screenHeight) {
        float scale = getTrackerScale();
        int panelWidth = Math.round(getPanelWidth(screenWidth) * scale);
        int panelHeight = Math.round(getFishingPanelHeight() * scale);
        int x = clamp(fishingX, 0, Math.max(0, screenWidth - panelWidth));
        int y = clamp(fishingY, 0, Math.max(0, screenHeight - panelHeight));
        int headerHeight = Math.round(HEADER_HEIGHT * scale);
        return mouseX >= x && mouseX <= x + panelWidth
                && mouseY >= y && mouseY <= y + headerHeight;
    }

    void moveFishingTrackerTo(int x, int y, int screenWidth, int screenHeight) {
        float scale = getTrackerScale();
        int panelWidth = Math.round(getPanelWidth(screenWidth) * scale);
        int panelHeight = Math.round(getFishingPanelHeight() * scale);
        fishingX = clamp(x, 0, Math.max(0, screenWidth - panelWidth));
        fishingY = clamp(y, 0, Math.max(0, screenHeight - panelHeight));
        fishingPositionConfigured = true;
    }

    void moveBiteAlertTo(int x, int y, int screenWidth, int screenHeight) {
        biteAlertX = clamp(x, 0, Math.max(0, screenWidth - getRenderedBiteAlertWidth()));
        biteAlertY = clamp(y, 0, Math.max(0, screenHeight - getRenderedBiteAlertHeight()));
        biteAlertPositionConfigured = true;
    }

    void clampBiteAlertPosition(int screenWidth, int screenHeight) {
        boolean wasConfigured = biteAlertPositionConfigured;
        int oldX = biteAlertX;
        int oldY = biteAlertY;
        if (!biteAlertPositionConfigured) {
            biteAlertX = Math.max(0, (screenWidth - getRenderedBiteAlertWidth()) / 2);
            biteAlertY = Math.max(0, (screenHeight - getRenderedBiteAlertHeight()) / 2);
            biteAlertPositionConfigured = true;
        }
        moveBiteAlertTo(biteAlertX, biteAlertY, screenWidth, screenHeight);
        if (!wasConfigured || oldX != biteAlertX || oldY != biteAlertY) {
            saveSettings();
        }
    }

    void resetBiteAlertPosition(int screenWidth, int screenHeight) {
        biteAlertPositionConfigured = false;
        clampBiteAlertPosition(screenWidth, screenHeight);
        saveSettings();
    }

    void nudgeTracker(int dx, int dy, int screenWidth, int screenHeight) {
        moveTrackerTo(trackerX + dx, trackerY + dy, screenWidth, screenHeight);
        saveSettings();
    }

    void resetTrackerPosition() {
        trackerX = 10;
        trackerY = 60;
        saveSettings();
    }

    void resetFishingPosition(int screenWidth, int screenHeight) {
        fishingPositionConfigured = false;
        setDefaultFishingPosition(screenWidth, screenHeight);
        fishingPositionConfigured = true;
        moveFishingTrackerTo(fishingX, fishingY, screenWidth, screenHeight);
        saveSettings();
    }

    int getTrackerSizePercent() {
        return trackerSizePercent;
    }

    int getRenderedTrackerWidth(int screenWidth) {
        return Math.round(getPanelWidth(screenWidth) * getTrackerScale());
    }

    int getRenderedTrackerHeight() {
        return Math.round(getPanelHeight() * getTrackerScale());
    }

    int getFishingX() {
        return fishingX;
    }

    int getFishingY() {
        return fishingY;
    }

    int getBiteAlertX() {
        return biteAlertX;
    }

    int getBiteAlertY() {
        return biteAlertY;
    }

    int getBiteAlertSizePercent() {
        return biteAlertSizePercent;
    }

    boolean isBiteAlertEnabled() {
        return biteAlertEnabled;
    }

    boolean isBiteAlertShowing() {
        return biteAlertEnabled && biteAlertTicksRemaining > 0;
    }

    float getBiteAlertRenderScale() {
        return 3.0F * biteAlertSizePercent / 100.0F;
    }

    int getRenderedBiteAlertWidth() {
        Minecraft minecraft = Minecraft.getMinecraft();
        int baseWidth = minecraft == null || minecraft.fontRendererObj == null
                ? 12 : minecraft.fontRendererObj.getStringWidth(BITE_ALERT_SYMBOL);
        return Math.max(1, (int) Math.ceil(baseWidth * getBiteAlertRenderScale()) + 2);
    }

    int getRenderedBiteAlertHeight() {
        Minecraft minecraft = Minecraft.getMinecraft();
        int baseHeight = minecraft == null || minecraft.fontRendererObj == null
                ? 9 : minecraft.fontRendererObj.FONT_HEIGHT;
        return Math.max(1, (int) Math.ceil(baseHeight * getBiteAlertRenderScale()) + 2);
    }

    int getRenderedFishingTrackerWidth(int screenWidth) {
        return Math.round(getPanelWidth(screenWidth) * getTrackerScale());
    }

    int getRenderedFishingTrackerHeight() {
        return Math.round(getFishingPanelHeight() * getTrackerScale());
    }

    void adjustBiteAlertSize(int delta, int screenWidth, int screenHeight) {
        biteAlertSizePercent = clamp(biteAlertSizePercent + delta, 70, 200);
        clampBiteAlertPosition(screenWidth, screenHeight);
        saveSettings();
    }

    void resetBiteAlertSize(int screenWidth, int screenHeight) {
        biteAlertSizePercent = 100;
        clampBiteAlertPosition(screenWidth, screenHeight);
        saveSettings();
    }

    void clampTrackerPosition(int screenWidth, int screenHeight) {
        int oldX = trackerX;
        int oldY = trackerY;
        moveTrackerTo(trackerX, trackerY, screenWidth, screenHeight);
        if (trackerX != oldX || trackerY != oldY) {
            saveSettings();
        }
    }

    void clampFishingTrackerPosition(int screenWidth, int screenHeight) {
        boolean wasConfigured = fishingPositionConfigured;
        int oldX = fishingX;
        int oldY = fishingY;
        if (!fishingPositionConfigured) {
            setDefaultFishingPosition(screenWidth, screenHeight);
            fishingPositionConfigured = true;
        }
        moveFishingTrackerTo(fishingX, fishingY, screenWidth, screenHeight);
        if (!wasConfigured || fishingX != oldX || fishingY != oldY) {
            saveSettings();
        }
    }

    void adjustTrackerSize(int delta, int screenWidth, int screenHeight) {
        trackerSizePercent = clamp(trackerSizePercent + delta, 70, 150);
        moveTrackerTo(trackerX, trackerY, screenWidth, screenHeight);
        clampFishingTrackerPosition(screenWidth, screenHeight);
        saveSettings();
    }

    void resetTrackerSize(int screenWidth, int screenHeight) {
        trackerSizePercent = 100;
        moveTrackerTo(trackerX, trackerY, screenWidth, screenHeight);
        clampFishingTrackerPosition(screenWidth, screenHeight);
        saveSettings();
    }

    private float getTrackerScale() {
        return trackerSizePercent / 100.0F;
    }

    private int getPanelWidth(int screenWidth) {
        int availableWidth = (int) (Math.max(100, screenWidth - 8) / getTrackerScale());
        return Math.min(PANEL_WIDTH, Math.max(100, availableWidth));
    }

    private int getPanelHeight() {
        int height = HEADER_HEIGHT + 6;
        List<DropEntry> activeDrops = getDropHistory(activeSlayer);
        if (activeDrops.isEmpty()) {
            height += 18;
        } else {
            height += ITEM_ONLY_ENTRY_HEIGHT * activeDrops.size();
        }
        if (slayerBossTimerHasValue) {
            height += ITEM_ONLY_ENTRY_HEIGHT;
        }
        return height + 22;
    }

    private int getFishingPanelHeight() {
        int caughtCount = getCaughtLegendaryCreatureCount();
        int displayedRows = caughtCount + (fishingTimerHasValue ? 1 : 0)
                + (splashToPullTimerHasValue ? 1 : 0);
        if (caughtCount == 0 && !fishingTimerHasValue) {
            displayedRows++;
        }
        int footerHeight = caughtCount > 0 ? 22 : 6;
        return HEADER_HEIGHT + 6 + ITEM_ONLY_ENTRY_HEIGHT * displayedRows + footerHeight;
    }

    private void setDefaultFishingPosition(int screenWidth, int screenHeight) {
        int fishingWidth = getRenderedFishingTrackerWidth(screenWidth);
        int fishingHeight = getRenderedFishingTrackerHeight();
        int mainX = clamp(trackerX, 0,
                Math.max(0, screenWidth - getRenderedTrackerWidth(screenWidth)));
        int mainY = clamp(trackerY, 0,
                Math.max(0, screenHeight - getRenderedTrackerHeight()));
        int mainWidth = getRenderedTrackerWidth(screenWidth);
        int mainHeight = getRenderedTrackerHeight();
        if (mainX + mainWidth + 12 + fishingWidth <= screenWidth) {
            fishingX = mainX + mainWidth + 12;
            fishingY = mainY;
        } else {
            fishingX = clamp(mainX, 0, Math.max(0, screenWidth - fishingWidth));
            int belowMain = mainY + mainHeight + 12;
            fishingY = clamp(belowMain, 0, Math.max(0, screenHeight - fishingHeight));
        }
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(value, max));
    }

    boolean isTrackerEnabled() {
        return trackerEnabled;
    }

    SlayerType getActiveSlayer() {
        return activeSlayer;
    }

    void toggleTracker() {
        trackerEnabled = !trackerEnabled;
        if (!trackerEnabled) {
            completeSlayerBossTimer(System.currentTimeMillis());
        }
        saveSettings();
    }

    boolean isFishingMobCounterEnabled() {
        return fishingMobCounterEnabled;
    }

    void toggleBiteAlert() {
        biteAlertEnabled = !biteAlertEnabled;
        if (!biteAlertEnabled) {
            resetBiteAlertDetection();
        }
        saveSettings();
    }

    void toggleFishingMobCounter() {
        if (fishingMobCounterEnabled) {
            updateFishingTimerState(false, System.currentTimeMillis());
            resetSplashToPullTimer();
        }
        fishingMobCounterEnabled = !fishingMobCounterEnabled;
        saveSettings();
    }

    void clearHistory() {
        for (List<DropEntry> history : dropHistory.values()) {
            history.clear();
        }
        legendaryCreatureCounts.clear();
        lastProcessedDropKey = "";
        lastProcessedDropAt = 0L;
        lastProcessedFishingCreature = "";
        lastProcessedFishingAt = 0L;
        resetFishingTimer();
        resetSlayerBossTimer();
        saveSettings();
    }

    void clearFishingHistory() {
        legendaryCreatureCounts.clear();
        lastProcessedFishingCreature = "";
        lastProcessedFishingAt = 0L;
        resetFishingTimer();
        saveSettings();
    }

    void clearHistory(SlayerType slayer) {
        if (slayer == null) {
            return;
        }
        List<DropEntry> history = dropHistory.get(slayer);
        if (history != null) {
            history.clear();
        }
        if (lastProcessedDropKey.startsWith(slayer.name() + "|")) {
            lastProcessedDropKey = "";
            lastProcessedDropAt = 0L;
        }
        if (slayerBossTimerType == slayer) {
            resetSlayerBossTimer();
        }
    }

    void setItemPrice(String item, long price) {
        String cleanItem = DropMessageParser.extractDropItem(stripFormattingCodes(item).trim());
        String key = DropMessageParser.normalizeItemName(cleanItem);
        if (key.length() == 0 || price < 0L) {
            return;
        }
        manualPrices.put(key, price);
        saveSettings();
    }

    String getHeldItemName() {
        Minecraft minecraft = Minecraft.getMinecraft();
        if (minecraft == null || minecraft.thePlayer == null) {
            return "";
        }
        net.minecraft.item.ItemStack held = minecraft.thePlayer.getHeldItem();
        if (held == null) {
            return "";
        }
        return DropMessageParser.extractDropItem(stripFormattingCodes(held.getDisplayName()).trim());
    }

    Long getItemPrice(String item) {
        return manualPrices.get(DropMessageParser.normalizeItemName(item));
    }

    int getTrackerX() {
        return trackerX;
    }

    int getTrackerY() {
        return trackerY;
    }

    void saveSettings() {
        File file = getSettingsFile();
        File parent = file.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) {
            return;
        }

        Properties properties = new Properties();
        properties.setProperty("tracker.enabled", Boolean.toString(trackerEnabled));
        properties.setProperty("fishing.mobCounter.enabled", Boolean.toString(fishingMobCounterEnabled));
        properties.setProperty("tracker.x", Integer.toString(trackerX));
        properties.setProperty("tracker.y", Integer.toString(trackerY));
        if (fishingPositionConfigured) {
            properties.setProperty("fishing.x", Integer.toString(fishingX));
            properties.setProperty("fishing.y", Integer.toString(fishingY));
        }
        properties.setProperty("tracker.sizePercent", Integer.toString(trackerSizePercent));
        properties.setProperty("fishing.biteAlert.enabled", Boolean.toString(biteAlertEnabled));
        properties.setProperty("fishing.biteAlert.sizePercent", Integer.toString(biteAlertSizePercent));
        properties.setProperty("fishing.jawbusAlert.enabled", Boolean.toString(jawbusAlertEnabled));
        properties.setProperty("deployables.timerPanel.enabled",
                Boolean.toString(deployablesTimerPanelEnabled));
        properties.setProperty("deployables.totem.enabled", Boolean.toString(totemTimerEnabled));
        properties.setProperty("deployables.sosFlare.enabled", Boolean.toString(sosFlareTimerEnabled));
        properties.setProperty("deployables.plasmaflux.enabled", Boolean.toString(plasmafluxTimerEnabled));
        properties.setProperty("dungeon.m7Overlay.enabled", Boolean.toString(m7OverlayEnabled));
        properties.setProperty("dungeon.boss.maxor.enabled", Boolean.toString(m7MaxorEnabled));
        properties.setProperty("dungeon.boss.storm.enabled", Boolean.toString(m7StormEnabled));
        properties.setProperty("dungeon.boss.goldor.enabled", Boolean.toString(m7GoldorEnabled));
        properties.setProperty("dungeon.boss.necron.enabled", Boolean.toString(m7NecronEnabled));
        properties.setProperty("dungeon.dragon.power.enabled", Boolean.toString(m7PowerDragonEnabled));
        properties.setProperty("dungeon.dragon.apex.enabled", Boolean.toString(m7ApexDragonEnabled));
        properties.setProperty("dungeon.dragon.soul.enabled", Boolean.toString(m7SoulDragonEnabled));
        properties.setProperty("dungeon.dragon.ice.enabled", Boolean.toString(m7IceDragonEnabled));
        properties.setProperty("dungeon.dragon.flame.enabled", Boolean.toString(m7FlameDragonEnabled));
        properties.setProperty("dungeon.statueZones.enabled", Boolean.toString(m7StatueZonesEnabled));
        properties.setProperty(NEARBY_CREATURE_HP_PROPERTY_PREFIX + "enabled",
                Boolean.toString(nearbyCreatureHpEnabled));
        properties.setProperty(NEARBY_CREATURE_HP_PROPERTY_PREFIX + "sizePercent",
                Integer.toString(nearbyCreatureHpSizePercent));
        if (nearbyCreatureHpPositionConfigured) {
            properties.setProperty(NEARBY_CREATURE_HP_PROPERTY_PREFIX + "x",
                    Integer.toString(nearbyCreatureHpX));
            properties.setProperty(NEARBY_CREATURE_HP_PROPERTY_PREFIX + "y",
                    Integer.toString(nearbyCreatureHpY));
        }
        properties.setProperty("deployables.timerPanel.sizePercent",
                Integer.toString(deployablesTimerPanelSizePercent));
        if (deployablesTimerPanelPositionConfigured) {
            properties.setProperty("deployables.timerPanel.x", Integer.toString(deployablesTimerPanelX));
            properties.setProperty("deployables.timerPanel.y", Integer.toString(deployablesTimerPanelY));
        }
        if (biteAlertPositionConfigured) {
            properties.setProperty("fishing.biteAlert.x", Integer.toString(biteAlertX));
            properties.setProperty("fishing.biteAlert.y", Integer.toString(biteAlertY));
        }
        for (Map.Entry<String, Long> entry : manualPrices.entrySet()) {
            properties.setProperty(PRICE_PROPERTY_PREFIX + entry.getKey(),
                    Long.toString(entry.getValue()));
        }
        for (Map.Entry<LegendaryCreature, Long> entry : legendaryCreatureCounts.entrySet()) {
            if (entry.getValue() != null && entry.getValue() > 0L) {
                properties.setProperty(LEGENDARY_COUNT_PROPERTY_PREFIX + entry.getKey().name(),
                        Long.toString(entry.getValue()));
            }
        }

        try (FileOutputStream output = new FileOutputStream(file)) {
            properties.store(output, "Spider Drop Alert settings");
        } catch (IOException ignored) {
            // A settings write failure should not interrupt the client.
        }
    }

    private void loadSettings() {
        File file = getSettingsFile();
        if (!file.isFile()) {
            return;
        }

        Properties properties = new Properties();
        try (FileInputStream input = new FileInputStream(file)) {
            properties.load(input);
        } catch (IOException ignored) {
            return;
        }

        trackerEnabled = Boolean.parseBoolean(properties.getProperty("tracker.enabled", "true"));
        fishingMobCounterEnabled = Boolean.parseBoolean(
                properties.getProperty("fishing.mobCounter.enabled", "false"));
        trackerX = parseInt(properties.getProperty("tracker.x"), trackerX);
        trackerY = parseInt(properties.getProperty("tracker.y"), trackerY);
        String fishingXValue = properties.getProperty("fishing.x");
        String fishingYValue = properties.getProperty("fishing.y");
        if (fishingXValue != null && fishingYValue != null) {
            fishingX = parseInt(fishingXValue, fishingX);
            fishingY = parseInt(fishingYValue, fishingY);
            fishingPositionConfigured = true;
        }
        trackerSizePercent = clamp(parseInt(properties.getProperty("tracker.sizePercent"), trackerSizePercent), 70, 150);
        biteAlertEnabled = Boolean.parseBoolean(
                properties.getProperty("fishing.biteAlert.enabled", "true"));
        biteAlertSizePercent = clamp(parseInt(properties.getProperty(
                "fishing.biteAlert.sizePercent"), biteAlertSizePercent), 70, 200);
        jawbusAlertEnabled = Boolean.parseBoolean(
                properties.getProperty("fishing.jawbusAlert.enabled", "true"));
        deployablesTimerPanelEnabled = Boolean.parseBoolean(
                properties.getProperty("deployables.timerPanel.enabled", "true"));
        totemTimerEnabled = Boolean.parseBoolean(
                properties.getProperty("deployables.totem.enabled", "true"));
        sosFlareTimerEnabled = Boolean.parseBoolean(
                properties.getProperty("deployables.sosFlare.enabled", "true"));
        plasmafluxTimerEnabled = Boolean.parseBoolean(
                properties.getProperty("deployables.plasmaflux.enabled", "true"));
        m7OverlayEnabled = Boolean.parseBoolean(
                properties.getProperty("dungeon.m7Overlay.enabled", "true"));
        m7MaxorEnabled = Boolean.parseBoolean(properties.getProperty("dungeon.boss.maxor.enabled", "true"));
        m7StormEnabled = Boolean.parseBoolean(properties.getProperty("dungeon.boss.storm.enabled", "true"));
        m7GoldorEnabled = Boolean.parseBoolean(properties.getProperty("dungeon.boss.goldor.enabled", "true"));
        m7NecronEnabled = Boolean.parseBoolean(properties.getProperty("dungeon.boss.necron.enabled", "true"));
        m7PowerDragonEnabled = Boolean.parseBoolean(
                properties.getProperty("dungeon.dragon.power.enabled", "true"));
        m7ApexDragonEnabled = Boolean.parseBoolean(
                properties.getProperty("dungeon.dragon.apex.enabled", "true"));
        m7SoulDragonEnabled = Boolean.parseBoolean(
                properties.getProperty("dungeon.dragon.soul.enabled", "true"));
        m7IceDragonEnabled = Boolean.parseBoolean(
                properties.getProperty("dungeon.dragon.ice.enabled", "true"));
        m7FlameDragonEnabled = Boolean.parseBoolean(
                properties.getProperty("dungeon.dragon.flame.enabled", "true"));
        m7StatueZonesEnabled = Boolean.parseBoolean(
                properties.getProperty("dungeon.statueZones.enabled", "true"));
        nearbyCreatureHpEnabled = Boolean.parseBoolean(properties.getProperty(
                NEARBY_CREATURE_HP_PROPERTY_PREFIX + "enabled", "true"));
        nearbyCreatureHpSizePercent = clamp(parseInt(properties.getProperty(
                NEARBY_CREATURE_HP_PROPERTY_PREFIX + "sizePercent"), nearbyCreatureHpSizePercent), 70, 150);
        String nearbyCreatureHpXValue = properties.getProperty(NEARBY_CREATURE_HP_PROPERTY_PREFIX + "x");
        String nearbyCreatureHpYValue = properties.getProperty(NEARBY_CREATURE_HP_PROPERTY_PREFIX + "y");
        if (nearbyCreatureHpXValue != null && nearbyCreatureHpYValue != null) {
            nearbyCreatureHpX = parseInt(nearbyCreatureHpXValue, nearbyCreatureHpX);
            nearbyCreatureHpY = parseInt(nearbyCreatureHpYValue, nearbyCreatureHpY);
            nearbyCreatureHpPositionConfigured = true;
        }
        deployablesTimerPanelSizePercent = clamp(parseInt(properties.getProperty(
                "deployables.timerPanel.sizePercent"), deployablesTimerPanelSizePercent), 70, 150);
        String deployablesXValue = properties.getProperty("deployables.timerPanel.x");
        String deployablesYValue = properties.getProperty("deployables.timerPanel.y");
        if (deployablesXValue != null && deployablesYValue != null) {
            deployablesTimerPanelX = parseInt(deployablesXValue, deployablesTimerPanelX);
            deployablesTimerPanelY = parseInt(deployablesYValue, deployablesTimerPanelY);
            deployablesTimerPanelPositionConfigured = true;
        }
        String biteAlertXValue = properties.getProperty("fishing.biteAlert.x");
        String biteAlertYValue = properties.getProperty("fishing.biteAlert.y");
        if (biteAlertXValue != null && biteAlertYValue != null) {
            biteAlertX = parseInt(biteAlertXValue, biteAlertX);
            biteAlertY = parseInt(biteAlertYValue, biteAlertY);
            biteAlertPositionConfigured = true;
        }

        for (String propertyName : properties.stringPropertyNames()) {
            if (propertyName.startsWith(PRICE_PROPERTY_PREFIX)
                    && !LEGACY_LAST_PRICE_ITEM_PROPERTY.equals(propertyName)) {
                String item = DropMessageParser.normalizeItemName(propertyName.substring(PRICE_PROPERTY_PREFIX.length()));
                try {
                    long price = Long.parseLong(properties.getProperty(propertyName));
                    if (item.length() > 0 && price >= 0L) {
                        manualPrices.put(item, price);
                    }
                } catch (NumberFormatException ignored) {
                    // Skip malformed price entries and keep loading other settings.
                }
            } else if (propertyName.startsWith(LEGENDARY_COUNT_PROPERTY_PREFIX)) {
                String creatureName = propertyName.substring(LEGENDARY_COUNT_PROPERTY_PREFIX.length());
                try {
                    LegendaryCreature creature = LegendaryCreature.valueOf(creatureName);
                    long count = Long.parseLong(properties.getProperty(propertyName));
                    if (count > 0L) {
                        legendaryCreatureCounts.put(creature, count);
                    }
                } catch (IllegalArgumentException ignored) {
                    // Skip unknown creature names or malformed counts.
                }
            }
        }
    }

    private File getSettingsFile() {
        if (settingsFile == null) {
            Minecraft minecraft = Minecraft.getMinecraft();
            File gameDir = minecraft == null || minecraft.mcDataDir == null
                    ? new File(".") : minecraft.mcDataDir;
            settingsFile = new File(new File(gameDir, "config"), "spiderdropalert.properties");
        }
        return settingsFile;
    }

    private static int parseInt(String value, int fallback) {
        if (value == null) {
            return fallback;
        }
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }

    static String stripFormattingCodes(String text) {
        if (text == null) {
            return "";
        }
        StringBuilder clean = new StringBuilder(text.length());
        for (int i = 0; i < text.length(); i++) {
            char current = text.charAt(i);
            if (current == '\u00A7' && i + 1 < text.length()) {
                i++;
            } else {
                clean.append(current);
            }
        }
        return clean.toString();
    }

    static String formatPrice(long price) {
        return NumberFormat.getIntegerInstance(Locale.US).format(price);
    }

    static long calculateTotalPrice(long unitPrice, long quantity) {
        if (unitPrice <= 0L || quantity <= 0L) {
            return 0L;
        }
        return unitPrice > Long.MAX_VALUE / quantity ? Long.MAX_VALUE : unitPrice * quantity;
    }

    static String formatDropLabel(String item, long quantity, Long unitPrice) {
        long safeQuantity = Math.max(1L, quantity);
        String quantityPrefix = NumberFormat.getIntegerInstance(Locale.US).format(safeQuantity) + "x ";
        return quantityPrefix + item + "(" + getDropValue(safeQuantity, unitPrice) + ")";
    }

    private static String getDropValue(long quantity, Long unitPrice) {
        return unitPrice == null ? "price not set"
                : formatCompactPrice(calculateTotalPrice(unitPrice, quantity));
    }

    private long getVisibleTotalProfit() {
        long total = 0L;
        for (DropEntry entry : getDropHistory(activeSlayer)) {
            total = addPricedDropValue(total, getItemPrice(entry.item), entry.quantity);
        }
        return total;
    }

    static String formatCompactPrice(long price) {
        if (price < 1000L) {
            return formatPrice(price) + (price == 1L ? " coin" : " coins");
        }
        long divisor;
        String suffix;
        if (price >= 1000000000L) {
            divisor = 1000000000L;
            suffix = "b";
        } else if (price >= 1000000L) {
            divisor = 1000000L;
            suffix = "m";
        } else {
            divisor = 1000L;
            suffix = "k";
        }
        String amount = BigDecimal.valueOf(price)
                .divide(BigDecimal.valueOf(divisor), 2, RoundingMode.HALF_UP)
                .stripTrailingZeros().toPlainString();
        return amount + suffix;
    }

    static final class NearbyCreatureHpEntry {
        final String creatureName;
        final int level;
        final String currentHealth;
        final String maxHealth;
        final int entityId;
        final double distanceSq;

        NearbyCreatureHpEntry(String creatureName, int level, String currentHealth,
                              String maxHealth, int entityId, double distanceSq) {
            this.creatureName = creatureName;
            this.level = level;
            this.currentHealth = currentHealth == null ? "" : currentHealth;
            this.maxHealth = maxHealth == null ? "" : maxHealth;
            this.entityId = entityId;
            this.distanceSq = distanceSq;
        }

        String toHudLabel() {
            String levelText = level >= 0 ? "\u00A77[Lvl " + level + "] " : "";
            String healthText = currentHealth.length() > 0 && maxHealth.length() > 0
                    ? " \u00A7a" + currentHealth + "/" + maxHealth + "\u00A7c\u2764" : "";
            return levelText + "\u00A7c" + creatureName + healthText;
        }
    }

    private static final class DropEntry {
        final String item;
        final long quantity;

        DropEntry(String item, long quantity) {
            this.item = item;
            this.quantity = Math.max(1L, quantity);
        }
    }
}
