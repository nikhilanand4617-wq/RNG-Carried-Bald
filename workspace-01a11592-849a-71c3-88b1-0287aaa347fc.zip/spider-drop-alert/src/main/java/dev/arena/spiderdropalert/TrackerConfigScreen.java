package dev.arena.spiderdropalert;

import java.io.IOException;

import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.renderer.GlStateManager;

/** Category-style settings screen for the tracker HUD. */
public final class TrackerConfigScreen extends GuiScreen {
    private static final int BUTTON_TOGGLE = 0;
    private static final int BUTTON_APPLY_POSITION = 1;
    private static final int BUTTON_RESET_POSITION = 2;
    private static final int BUTTON_CLEAR = 3;
    private static final int BUTTON_SIZE_DOWN = 4;
    private static final int BUTTON_SIZE_UP = 5;
    private static final int BUTTON_SIZE_RESET = 6;
    private static final int BUTTON_DONE = 7;
    private static final int BUTTON_CLEAR_SPIDER = 8;
    private static final int BUTTON_CLEAR_REVENANT = 9;
    private static final int BUTTON_CLEAR_BLAZE = 10;
    private static final int BUTTON_CLEAR_WOLF = 11;
    private static final int BUTTON_CLEAR_ENDERMAN = 12;
    private static final int BUTTON_CLEAR_CANCEL = 13;
    private static final int BUTTON_FISHING_TOGGLE = 14;
    private static final int BUTTON_CLEAR_FISHING = 15;
    private static final int BUTTON_APPLY_FISHING_POSITION = 16;
    private static final int BUTTON_RESET_FISHING_POSITION = 17;
    private static final int BUTTON_BITE_ALERT_TOGGLE = 18;
    private static final int BUTTON_APPLY_BITE_ALERT_POSITION = 19;
    private static final int BUTTON_RESET_BITE_ALERT_POSITION = 20;
    private static final int BUTTON_BITE_ALERT_SIZE_DOWN = 21;
    private static final int BUTTON_BITE_ALERT_SIZE_UP = 22;
    private static final int BUTTON_BITE_ALERT_SIZE_RESET = 23;
    private static final int BUTTON_DEPLOYABLES_TOGGLE = 24;
    private static final int BUTTON_APPLY_DEPLOYABLES_POSITION = 25;
    private static final int BUTTON_RESET_DEPLOYABLES_POSITION = 26;
    private static final int BUTTON_DEPLOYABLES_SIZE_DOWN = 27;
    private static final int BUTTON_DEPLOYABLES_SIZE_UP = 28;
    private static final int BUTTON_DEPLOYABLES_SIZE_RESET = 29;
    private static final int BUTTON_JAWBUS_ALERT_TOGGLE = 30;
    private static final int BUTTON_NEARBY_CREATURE_HP_TOGGLE = 31;
    private static final int BUTTON_APPLY_NEARBY_CREATURE_HP_POSITION = 32;
    private static final int BUTTON_RESET_NEARBY_CREATURE_HP_POSITION = 33;
    private static final int BUTTON_NEARBY_CREATURE_HP_SIZE_DOWN = 34;
    private static final int BUTTON_NEARBY_CREATURE_HP_SIZE_UP = 35;
    private static final int BUTTON_NEARBY_CREATURE_HP_SIZE_RESET = 36;
    private static final int BUTTON_M7_OVERLAY_TOGGLE = 37;
    private static final int BUTTON_TOTEM_TIMER_TOGGLE = 39;
    private static final int BUTTON_SOS_FLARE_TIMER_TOGGLE = 40;
    private static final int BUTTON_PLASMAFLUX_TIMER_TOGGLE = 41;
    private static final int BUTTON_M7_MAXOR_TOGGLE = 42;
    private static final int BUTTON_M7_STORM_TOGGLE = 43;
    private static final int BUTTON_M7_GOLDOR_TOGGLE = 44;
    private static final int BUTTON_M7_NECRON_TOGGLE = 45;
    private static final int BUTTON_M7_APEX_TOGGLE = 46;
    private static final int BUTTON_M7_FLAME_TOGGLE = 47;
    private static final int BUTTON_M7_ICE_TOGGLE = 48;
    private static final int BUTTON_M7_POWER_TOGGLE = 49;
    private static final int BUTTON_M7_SOUL_TOGGLE = 50;
    private static final int BUTTON_M7_STATUE_ZONES_TOGGLE = 51;
    private static final int BUTTON_FISHING_MODE_COUNTER = 52;
    private static final int BUTTON_FISHING_MODE_BITE = 53;
    private static final int BUTTON_FISHING_MODE_CREATURE_HP = 54;

    private static final int CATEGORY_TRACKER = 0;
    private static final int CATEGORY_DUNGEON = 1;
    private static final int CATEGORY_FISHING = 2;
    private static final int CATEGORY_DEPLOYABLES = 3;
    private static final int CATEGORY_APPEARANCE = 4;
    private static final int CATEGORY_ABOUT = 5;

    private static final int FISHING_PANEL_COUNTER = 0;
    private static final int FISHING_PANEL_BITE_ALERT = 1;
    private static final int FISHING_PANEL_CREATURE_HP = 2;

    private static final String[] CATEGORY_NAMES = {
            "Slayer", "Dungeon", "Fishing", "Deployables", "Appearance", "About"
    };

    private final SpiderDropAlert mod;
    private int selectedCategory;
    private int selectedFishingPanel = FISHING_PANEL_COUNTER;
    private boolean clearHistoryDialogOpen;
    private GuiTextField xField;
    private GuiTextField yField;
    private boolean positionError;
    private boolean draggingPreview;
    private int dragOffsetX;
    private int dragOffsetY;
    private int controlsActionY;

    public TrackerConfigScreen(SpiderDropAlert mod) {
        this.mod = mod;
    }

    @Override
    public void initGui() {
        buttonList.clear();
        mod.clampTrackerPosition(width, height);
        mod.clampFishingTrackerPosition(width, height);
        mod.clampBiteAlertPosition(width, height);
        mod.clampDeployablesTimerPanelPosition(width, height);
        mod.clampNearbyCreatureHpPosition(width, height);
        xField = null;
        yField = null;

        int footerY = windowY() + windowHeight() - 29;
        int doneWidth = footerButtonWidth();
        buttonList.add(new GuiButton(BUTTON_CLEAR, contentX() + 12, footerY,
                footerButtonWidth(), 20, "Clear history"));
        buttonList.add(new GuiButton(BUTTON_DONE,
                windowX() + windowWidth() - 12 - doneWidth, footerY, doneWidth, 20, "Done"));

        if (selectedCategory == CATEGORY_TRACKER) {
            addTrackerControls(footerY);
        } else if (selectedCategory == CATEGORY_DUNGEON) {
            addDungeonControls();
        } else if (selectedCategory == CATEGORY_FISHING) {
            addFishingControls(footerY);
        } else if (selectedCategory == CATEGORY_DEPLOYABLES) {
            addDeployablesTimerControls(footerY);
        } else if (selectedCategory == CATEGORY_APPEARANCE) {
            addAppearanceControls();
        }

        if (clearHistoryDialogOpen) {
            buttonList.clear();
            addClearHistoryDialogButtons();
        }
    }

    private void addClearHistoryDialogButtons() {
        int dialogX = clearDialogX();
        int dialogY = clearDialogY();
        int dialogWidth = clearDialogWidth();
        int buttonGap = 6;
        int buttonWidth = (dialogWidth - 30) / 2;
        int firstX = dialogX + 9;
        int secondX = firstX + buttonWidth + buttonGap;
        int firstRowY = dialogY + 56;
        int secondRowY = firstRowY + 25;
        int thirdRowY = secondRowY + 25;

        buttonList.add(new GuiButton(BUTTON_CLEAR_ENDERMAN, firstX, firstRowY,
                buttonWidth, 20, "Enderman"));
        buttonList.add(new GuiButton(BUTTON_CLEAR_WOLF, secondX, firstRowY,
                buttonWidth, 20, "Wolf"));
        buttonList.add(new GuiButton(BUTTON_CLEAR_SPIDER, firstX, secondRowY,
                buttonWidth, 20, "Spider"));
        buttonList.add(new GuiButton(BUTTON_CLEAR_BLAZE, secondX, secondRowY,
                buttonWidth, 20, "Blaze"));
        buttonList.add(new GuiButton(BUTTON_CLEAR_REVENANT, firstX, thirdRowY,
                buttonWidth, 20, "Revenant"));
        buttonList.add(new GuiButton(BUTTON_CLEAR_FISHING, secondX, thirdRowY,
                buttonWidth, 20, "Fishing"));

        int cancelWidth = Math.min(100, dialogWidth - 30);
        buttonList.add(new GuiButton(BUTTON_CLEAR_CANCEL,
                dialogX + (dialogWidth - cancelWidth) / 2,
                dialogY + clearDialogHeight() - 28, cancelWidth, 20, "Cancel"));
    }

    private void addTrackerControls(int footerY) {
        int controlX = controlX();
        int controlWidth = controlWidth();
        int toggleY = trackerToggleY();
        buttonList.add(new GuiButton(BUTTON_TOGGLE, controlX, toggleY,
                controlWidth, 20, trackerButtonLabel()));

        int positionTitleY = toggleY + 31;
        int fieldsY = positionTitleY + 15;
        int actionsY;
        if (controlWidth >= 190) {
            int fieldWidth = Math.min(92, Math.max(58, (controlWidth - 48) / 2));
            int xFieldX = controlX + 16;
            int yLabelX = xFieldX + fieldWidth + 12;
            int yFieldX = yLabelX + 16;
            int yFieldWidth = Math.max(50, controlX + controlWidth - yFieldX);
            createPositionFields(xFieldX, fieldsY, fieldWidth,
                    yFieldX, fieldsY, yFieldWidth, controlX, yLabelX);
            actionsY = fieldsY + 27;
        } else {
            int fieldWidth = Math.max(50, controlWidth - 18);
            int xFieldY = fieldsY;
            int yFieldY = fieldsY + 23;
            createPositionFields(controlX + 16, xFieldY, fieldWidth,
                    controlX + 16, yFieldY, fieldWidth, controlX, controlX);
            actionsY = fieldsY + 47;
        }

        controlsActionY = actionsY;
        int gap = 6;
        int actionWidth = Math.max(54, (controlWidth - gap) / 2);
        buttonList.add(new GuiButton(BUTTON_APPLY_POSITION, controlX, actionsY,
                actionWidth, 20, "Apply"));
        buttonList.add(new GuiButton(BUTTON_RESET_POSITION, controlX + actionWidth + gap,
                actionsY, Math.max(54, controlWidth - actionWidth - gap), 20, "Reset"));

    }

    private void addDungeonControls() {
        int controlX = controlX();
        int controlWidth = controlWidth();
        int top = trackerToggleY();
        buttonList.add(new GuiButton(BUTTON_M7_OVERLAY_TOGGLE, controlX, top,
                controlWidth, 20, dungeonButtonLabel()));

        int gap = 6;
        int columnWidth = Math.max(46, (controlWidth - gap) / 2);
        int rightX = controlX + columnWidth + gap;
        int rowY = top + 24;
        int rowStep = 21;
        addM7Toggle(BUTTON_M7_MAXOR_TOGGLE, controlX, rowY, columnWidth,
                m7BossButtonLabel("Maxor", M7OverlayRenderer.M7HitboxTarget.MAXOR));
        addM7Toggle(BUTTON_M7_STORM_TOGGLE, rightX, rowY, columnWidth,
                m7BossButtonLabel("Storm", M7OverlayRenderer.M7HitboxTarget.STORM));
        addM7Toggle(BUTTON_M7_GOLDOR_TOGGLE, controlX, rowY + rowStep, columnWidth,
                m7BossButtonLabel("Goldor", M7OverlayRenderer.M7HitboxTarget.GOLDOR));
        addM7Toggle(BUTTON_M7_NECRON_TOGGLE, rightX, rowY + rowStep, columnWidth,
                m7BossButtonLabel("Necron", M7OverlayRenderer.M7HitboxTarget.NECRON));
        addM7Toggle(BUTTON_M7_APEX_TOGGLE, controlX, rowY + rowStep * 2, columnWidth,
                m7DragonButtonLabel("Apex", M7OverlayRenderer.M7DragonStatue.APEX));
        addM7Toggle(BUTTON_M7_FLAME_TOGGLE, rightX, rowY + rowStep * 2, columnWidth,
                m7DragonButtonLabel("Flame", M7OverlayRenderer.M7DragonStatue.FLAME));
        addM7Toggle(BUTTON_M7_ICE_TOGGLE, controlX, rowY + rowStep * 3, columnWidth,
                m7DragonButtonLabel("Ice", M7OverlayRenderer.M7DragonStatue.ICE));
        addM7Toggle(BUTTON_M7_POWER_TOGGLE, rightX, rowY + rowStep * 3, columnWidth,
                m7DragonButtonLabel("Power", M7OverlayRenderer.M7DragonStatue.POWER));
        addM7Toggle(BUTTON_M7_SOUL_TOGGLE, controlX, rowY + rowStep * 4, columnWidth,
                m7DragonButtonLabel("Soul", M7OverlayRenderer.M7DragonStatue.SOUL));
        addM7Toggle(BUTTON_M7_STATUE_ZONES_TOGGLE, rightX, rowY + rowStep * 4,
                Math.max(46, controlX + controlWidth - rightX), statueZonesButtonLabel());
    }

    private void addM7Toggle(int id, int x, int y, int buttonWidth, String label) {
        buttonList.add(new GuiButton(id, x, y, buttonWidth, 18, label));
    }

    private int getSelectedPositionX() {
        if (selectedCategory == CATEGORY_FISHING) {
            if (selectedFishingPanel == FISHING_PANEL_BITE_ALERT) {
                return mod.getBiteAlertX();
            }
            if (selectedFishingPanel == FISHING_PANEL_CREATURE_HP) {
                return mod.getNearbyCreatureHpX();
            }
            return mod.getFishingX();
        }
        return selectedCategory == CATEGORY_DEPLOYABLES
                ? mod.getDeployablesTimerPanelX() : mod.getTrackerX();
    }

    private int getSelectedPositionY() {
        if (selectedCategory == CATEGORY_FISHING) {
            if (selectedFishingPanel == FISHING_PANEL_BITE_ALERT) {
                return mod.getBiteAlertY();
            }
            if (selectedFishingPanel == FISHING_PANEL_CREATURE_HP) {
                return mod.getNearbyCreatureHpY();
            }
            return mod.getFishingY();
        }
        return selectedCategory == CATEGORY_DEPLOYABLES
                ? mod.getDeployablesTimerPanelY() : mod.getTrackerY();
    }

    private void createPositionFields(int xX, int xY, int xWidth,
                                      int yX, int yY, int yWidth,
                                      int xLabelX, int yLabelX) {
        xField = new GuiTextField(0, fontRendererObj, xX, xY, xWidth, 18);
        xField.setMaxStringLength(6);
        xField.setText(Integer.toString(getSelectedPositionX()));
        xField.setFocused(false);

        yField = new GuiTextField(1, fontRendererObj, yX, yY, yWidth, 18);
        yField.setMaxStringLength(6);
        yField.setText(Integer.toString(getSelectedPositionY()));
        yField.setFocused(false);

        this.xLabelX = xLabelX;
        this.yLabelX = yLabelX;
        this.xFieldY = xY;
        this.yFieldY = yY;
    }

    private int xLabelX;
    private int yLabelX;
    private int xFieldY;
    private int yFieldY;

    private void addFishingControls(int footerY) {
        int controlX = controlX();
        int controlWidth = controlWidth();
        int tabsY = trackerToggleY();
        int gap = 3;
        int tabsHeight;
        if (controlWidth >= 190) {
            int tabWidth = Math.max(50, (controlWidth - gap * 2) / 3);
            buttonList.add(new GuiButton(BUTTON_FISHING_MODE_COUNTER, controlX, tabsY,
                    tabWidth, 20, fishingPanelTabLabel(FISHING_PANEL_COUNTER)));
            buttonList.add(new GuiButton(BUTTON_FISHING_MODE_BITE, controlX + tabWidth + gap, tabsY,
                    tabWidth, 20, fishingPanelTabLabel(FISHING_PANEL_BITE_ALERT)));
            buttonList.add(new GuiButton(BUTTON_FISHING_MODE_CREATURE_HP,
                    controlX + (tabWidth + gap) * 2, tabsY,
                    Math.max(50, controlX + controlWidth - (controlX + (tabWidth + gap) * 2)),
                    20, fishingPanelTabLabel(FISHING_PANEL_CREATURE_HP)));
            tabsHeight = 20;
        } else {
            buttonList.add(new GuiButton(BUTTON_FISHING_MODE_COUNTER, controlX, tabsY,
                    controlWidth, 18, fishingPanelTabLabel(FISHING_PANEL_COUNTER)));
            buttonList.add(new GuiButton(BUTTON_FISHING_MODE_BITE, controlX, tabsY + 20,
                    controlWidth, 18, fishingPanelTabLabel(FISHING_PANEL_BITE_ALERT)));
            buttonList.add(new GuiButton(BUTTON_FISHING_MODE_CREATURE_HP, controlX, tabsY + 40,
                    controlWidth, 18, fishingPanelTabLabel(FISHING_PANEL_CREATURE_HP)));
            tabsHeight = 58;
        }

        int featureToggleY = tabsY + tabsHeight + 4;
        if (selectedFishingPanel == FISHING_PANEL_BITE_ALERT) {
            buttonList.add(new GuiButton(BUTTON_BITE_ALERT_TOGGLE, controlX, featureToggleY,
                    controlWidth, 20, biteAlertButtonLabel()));
        } else if (selectedFishingPanel == FISHING_PANEL_CREATURE_HP) {
            buttonList.add(new GuiButton(BUTTON_NEARBY_CREATURE_HP_TOGGLE, controlX, featureToggleY,
                    controlWidth, 20, nearbyCreatureHpButtonLabel()));
        } else {
            buttonList.add(new GuiButton(BUTTON_FISHING_TOGGLE, controlX, featureToggleY,
                    controlWidth, 20, fishingButtonLabel()));
        }
        int jawbusY = featureToggleY + 24;
        buttonList.add(new GuiButton(BUTTON_JAWBUS_ALERT_TOGGLE, controlX, jawbusY,
                controlWidth, 20, jawbusAlertButtonLabel()));

        int positionTitleY = jawbusY + 26;
        int fieldsY = positionTitleY + 15;
        int actionsY;
        if (controlWidth >= 190) {
            int fieldWidth = Math.min(92, Math.max(58, (controlWidth - 48) / 2));
            int xFieldX = controlX + 16;
            int yLabelX = xFieldX + fieldWidth + 12;
            int yFieldX = yLabelX + 16;
            int yFieldWidth = Math.max(50, controlX + controlWidth - yFieldX);
            createPositionFields(xFieldX, fieldsY, fieldWidth,
                    yFieldX, fieldsY, yFieldWidth, controlX, yLabelX);
            actionsY = fieldsY + 27;
        } else {
            int fieldWidth = Math.max(50, controlWidth - 18);
            createPositionFields(controlX + 16, fieldsY, fieldWidth,
                    controlX + 16, fieldsY + 23, fieldWidth, controlX, controlX);
            actionsY = fieldsY + 47;
        }

        controlsActionY = actionsY;
        int actionWidth = Math.max(54, (controlWidth - 6) / 2);
        buttonList.add(new GuiButton(BUTTON_APPLY_FISHING_POSITION, controlX, actionsY,
                actionWidth, 20, "Apply"));
        buttonList.add(new GuiButton(BUTTON_RESET_FISHING_POSITION, controlX + actionWidth + 6,
                actionsY, Math.max(54, controlWidth - actionWidth - 6), 20,
                selectedFishingPanel == FISHING_PANEL_COUNTER ? "Reset" : "Center"));

        if (selectedFishingPanel != FISHING_PANEL_COUNTER) {
            int sizeY = actionsY + 39;
            int halfWidth = Math.max(54, (controlWidth - 6) / 2);
            int downId = selectedFishingPanel == FISHING_PANEL_BITE_ALERT
                    ? BUTTON_BITE_ALERT_SIZE_DOWN : BUTTON_NEARBY_CREATURE_HP_SIZE_DOWN;
            int upId = selectedFishingPanel == FISHING_PANEL_BITE_ALERT
                    ? BUTTON_BITE_ALERT_SIZE_UP : BUTTON_NEARBY_CREATURE_HP_SIZE_UP;
            int resetId = selectedFishingPanel == FISHING_PANEL_BITE_ALERT
                    ? BUTTON_BITE_ALERT_SIZE_RESET : BUTTON_NEARBY_CREATURE_HP_SIZE_RESET;
            buttonList.add(new GuiButton(downId, controlX, sizeY, halfWidth, 20, "- 5%"));
            buttonList.add(new GuiButton(upId, controlX + halfWidth + 6, sizeY,
                    Math.max(54, controlWidth - halfWidth - 6), 20, "+ 5%"));
            if (sizeY + 45 <= footerY) {
                buttonList.add(new GuiButton(resetId, controlX, sizeY + 25,
                        controlWidth, 20, "Reset panel size"));
            }
        }
    }

    private String fishingPanelTabLabel(int panel) {
        String label = panel == FISHING_PANEL_COUNTER ? "Mob Counter"
                : (panel == FISHING_PANEL_BITE_ALERT ? "Bite Alert" : "Sea Creature HP");
        return selectedFishingPanel == panel ? "> " + label : label;
    }

    private void addDeployablesTimerControls(int footerY) {
        int controlX = controlX();
        int controlWidth = controlWidth();
        int toggleY = trackerToggleY();
        buttonList.add(new GuiButton(BUTTON_DEPLOYABLES_TOGGLE, controlX, toggleY,
                controlWidth, 20, deployablesButtonLabel()));
        buttonList.add(new GuiButton(BUTTON_TOTEM_TIMER_TOGGLE, controlX, toggleY + 24,
                controlWidth, 20, totemTimerButtonLabel()));
        buttonList.add(new GuiButton(BUTTON_SOS_FLARE_TIMER_TOGGLE, controlX, toggleY + 47,
                controlWidth, 20, sosFlareTimerButtonLabel()));
        buttonList.add(new GuiButton(BUTTON_PLASMAFLUX_TIMER_TOGGLE, controlX, toggleY + 70,
                controlWidth, 20, plasmafluxTimerButtonLabel()));

        int fieldsY = toggleY + 108;
        int actionsY;
        if (controlWidth >= 190) {
            int fieldWidth = Math.min(92, Math.max(58, (controlWidth - 48) / 2));
            int xFieldX = controlX + 16;
            int yLabelX = xFieldX + fieldWidth + 12;
            int yFieldX = yLabelX + 16;
            int yFieldWidth = Math.max(50, controlX + controlWidth - yFieldX);
            createPositionFields(xFieldX, fieldsY, fieldWidth,
                    yFieldX, fieldsY, yFieldWidth, controlX, yLabelX);
            actionsY = fieldsY + 27;
        } else {
            int fieldWidth = Math.max(50, controlWidth - 18);
            createPositionFields(controlX + 16, fieldsY, fieldWidth,
                    controlX + 16, fieldsY + 23, fieldWidth, controlX, controlX);
            actionsY = fieldsY + 47;
        }

        controlsActionY = actionsY;
        int gap = 6;
        int actionWidth = Math.max(54, (controlWidth - gap) / 2);
        buttonList.add(new GuiButton(BUTTON_APPLY_DEPLOYABLES_POSITION, controlX, actionsY,
                actionWidth, 20, "Apply"));
        buttonList.add(new GuiButton(BUTTON_RESET_DEPLOYABLES_POSITION,
                controlX + actionWidth + gap, actionsY,
                Math.max(54, controlWidth - actionWidth - gap), 20, "Center"));

        int sizeY = actionsY + 39;
        int halfWidth = Math.max(54, (controlWidth - gap) / 2);
        buttonList.add(new GuiButton(BUTTON_DEPLOYABLES_SIZE_DOWN, controlX, sizeY,
                halfWidth, 20, "- 5%"));
        buttonList.add(new GuiButton(BUTTON_DEPLOYABLES_SIZE_UP,
                controlX + halfWidth + gap, sizeY,
                Math.max(54, controlWidth - halfWidth - gap), 20, "+ 5%"));
        if (sizeY + 45 <= footerY) {
            buttonList.add(new GuiButton(BUTTON_DEPLOYABLES_SIZE_RESET, controlX, sizeY + 25,
                    controlWidth, 20, "Reset panel size"));
        }
    }

    private void addAppearanceControls() {
        int controlX = controlX();
        int controlWidth = controlWidth();
        int gap = 6;
        int halfWidth = Math.max(54, (controlWidth - gap) / 2);
        int buttonY = windowY() + 111;
        buttonList.add(new GuiButton(BUTTON_SIZE_DOWN, controlX, buttonY,
                halfWidth, 20, "- 5%"));
        buttonList.add(new GuiButton(BUTTON_SIZE_UP, controlX + halfWidth + gap, buttonY,
                Math.max(54, controlWidth - halfWidth - gap), 20, "+ 5%"));
        buttonList.add(new GuiButton(BUTTON_SIZE_RESET, controlX, buttonY + 32,
                controlWidth, 20, "Reset size to 100%"));
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawWindow();
        drawCategories(mouseX, mouseY);
        drawContent();
        drawPositionFields();
        if (hasPreviewForSelectedCategory()) {
            drawPreview();
        }
        if (clearHistoryDialogOpen) {
            drawClearHistoryDialog();
        }
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    private void drawWindow() {
        int left = windowX();
        int top = windowY();
        int right = left + windowWidth();
        int bottom = top + windowHeight();
        Gui.drawRect(0, 0, width, height, 0x68000000);
        Gui.drawRect(left - 2, top - 2, right + 2, bottom + 2, 0xAA000000);
        Gui.drawRect(left, top, right, bottom, 0xE51A1A20);
        Gui.drawRect(left, top, right, top + 35, 0xF026252D);
        Gui.drawRect(left, top + 34, right, top + 36, 0xFF705794);
        Gui.drawRect(left + 1, top + 36, left + sideWidth(), bottom - 9, 0xA5121218);
        Gui.drawRect(contentX(), top + 43, right - 10, bottom - 9, 0x7A24242B);

        fontRendererObj.drawStringWithShadow("RNG carried Bald", left + 14, top + 13, 0xFFFFFF);
        String version = "1.0.63";
        fontRendererObj.drawStringWithShadow(version,
                right - 14 - fontRendererObj.getStringWidth(version), top + 13, 0xB9B4C5);
    }

    private void drawCategories(int mouseX, int mouseY) {
        int left = windowX() + 10;
        int top = windowY() + 48;
        int categoryWidth = sideWidth() - 16;
        fontRendererObj.drawStringWithShadow("CATEGORIES", left + 9, top, 0x9D9AA5);

        for (int i = 0; i < CATEGORY_NAMES.length; i++) {
            int rowY = categoryRowY(i);
            boolean selected = selectedCategory == i;
            boolean hovered = mouseX >= left && mouseX <= left + categoryWidth
                    && mouseY >= rowY && mouseY <= rowY + 25;
            if (selected) {
                Gui.drawRect(left + 2, rowY, left + categoryWidth - 2,
                        rowY + 25, 0xAA69518B);
                Gui.drawRect(left + 2, rowY, left + 5, rowY + 25, 0xFFB99BEA);
            } else if (hovered) {
                Gui.drawRect(left + 2, rowY, left + categoryWidth - 2,
                        rowY + 25, 0x553F3D47);
            }
            int color = selected ? 0xFFFFFF : (hovered ? 0xE5E1EA : 0xC6C3CD);
            fontRendererObj.drawStringWithShadow(selected ? ">" : " ", left + 10, rowY + 8, 0xD7C3FF);
            fontRendererObj.drawStringWithShadow(CATEGORY_NAMES[i], left + 24, rowY + 8, color);
        }
    }

    private void drawContent() {
        int left = contentX() + 12;
        int top = windowY() + 51;
        if (selectedCategory == CATEGORY_TRACKER) {
            drawPageHeading("Slayer Tracker", "Rare drops, profit, and boss spawn-to-kill timer.", left, top);
            fontRendererObj.drawStringWithShadow("Position", controlX(), trackerToggleY() + 31, 0xDEDCE4);
            if (positionError) {
                fontRendererObj.drawStringWithShadow("Enter whole-number coordinates.",
                        controlX(), controlsActionY + 22, 0xFFFF7777);
            }
            if (!hasPreview()) {
                fontRendererObj.drawStringWithShadow("Use X and Y to place the tracker in screen pixels.",
                        controlX(), controlsActionY + 28, 0xAFAEB7);
            }
        } else if (selectedCategory == CATEGORY_DUNGEON) {
            drawPageHeading("Dungeon", "Master Mode Floor VII boss and dragon outlines.", left, top);
            if (windowHeight() > 300) {
                fontRendererObj.drawStringWithShadow("Master switch gates every M7 outline; each target is independent.",
                        controlX(), trackerToggleY() + 136, 0xB7B4C0);
                fontRendererObj.drawStringWithShadow("Dragon statue kill zones have their own switch.",
                        controlX(), trackerToggleY() + 152, 0xB7B4C0);
            }
        } else if (selectedCategory == CATEGORY_FISHING) {
            String subtitle = selectedFishingPanel == FISHING_PANEL_COUNTER
                    ? "Mob counter, bobber timer, and splash-to-pull stopwatch."
                    : (selectedFishingPanel == FISHING_PANEL_BITE_ALERT
                    ? "Red !!! alert when the bobber is pulled down."
                    : "Nearby Legendary and Mythic sea-creature health.");
            drawPageHeading("Fishing", subtitle, left, top);
            String positionLabel = selectedFishingPanel == FISHING_PANEL_COUNTER
                    ? "Mob Counter position"
                    : (selectedFishingPanel == FISHING_PANEL_BITE_ALERT
                    ? "Bite Alert position" : "Sea Creature HP position");
            fontRendererObj.drawStringWithShadow(positionLabel, controlX(),
                    fishingPositionTitleY(), 0xDEDCE4);
            if (positionError) {
                fontRendererObj.drawStringWithShadow("Enter whole-number coordinates.",
                        controlX(), controlsActionY + 22, 0xFFFF7777);
            } else if (selectedFishingPanel == FISHING_PANEL_BITE_ALERT) {
                fontRendererObj.drawStringWithShadow("Icon size: " + mod.getBiteAlertSizePercent()
                        + "% (70%-200%)", controlX(), controlsActionY + 24, 0xB7B4C0);
            } else if (selectedFishingPanel == FISHING_PANEL_CREATURE_HP) {
                fontRendererObj.drawStringWithShadow("Panel size: " + mod.getNearbyCreatureHpSizePercent()
                        + "% (70%-150%)", controlX(), controlsActionY + 24, 0xB7B4C0);
            } else {
                fontRendererObj.drawStringWithShadow("HUD size is controlled in Appearance.",
                        controlX(), controlsActionY + 24, 0xB7B4C0);
            }
            if (!hasPreview() && controlsActionY + 94 < windowY() + windowHeight() - 29) {
                String instruction = selectedFishingPanel == FISHING_PANEL_BITE_ALERT
                        ? "Drag the red marker to move the alert."
                        : (selectedFishingPanel == FISHING_PANEL_CREATURE_HP
                        ? "The panel appears only near a qualifying creature."
                        : "Drag the Fishing preview header to move its box.");
                fontRendererObj.drawStringWithShadow(instruction,
                        controlX(), controlsActionY + 88, 0xAFAEB7);
            }
        } else if (selectedCategory == CATEGORY_DEPLOYABLES) {
            drawPageHeading("Deployables", "Totem, SOS Flare, and Plasmaflux timers.", left, top);
            fontRendererObj.drawStringWithShadow("Timer panel position", controlX(),
                    trackerToggleY() + 91, 0xDEDCE4);
            if (positionError) {
                fontRendererObj.drawStringWithShadow("Enter whole-number coordinates.",
                        controlX(), controlsActionY + 22, 0xFFFF7777);
            } else {
                fontRendererObj.drawStringWithShadow("Panel size: "
                        + mod.getDeployablesTimerPanelSizePercent() + "% (70%-150%)",
                        controlX(), controlsActionY + 24, 0xB7B4C0);
            }
            if (!hasPreview() && controlsActionY + 94 < windowY() + windowHeight() - 29) {
                fontRendererObj.drawStringWithShadow("Panel appears while a timer is active.",
                        controlX(), controlsActionY + 88, 0xAFAEB7);
            }
        } else if (selectedCategory == CATEGORY_APPEARANCE) {
            drawPageHeading("Appearance", "Resize the Slayer and Fishing HUD boxes.", left, top);
            String sizeText = "HUD box size: " + mod.getTrackerSizePercent() + "%";
            fontRendererObj.drawStringWithShadow(sizeText, controlX(), windowY() + 91, 0xE5E2EA);
            fontRendererObj.drawStringWithShadow("Range: 70% to 150%", controlX(), windowY() + 170, 0xB7B4C0);
            fontRendererObj.drawStringWithShadow("Changes are saved automatically.",
                    controlX(), windowY() + 184, 0xAFAEB7);
        } else {
            drawPageHeading("About", "Slayer, Fishing, and deployable timers.", left, top);
            fontRendererObj.drawStringWithShadow("/trackergui  Open these settings", left, windowY() + 104, 0xE1DEE7);
            fontRendererObj.drawStringWithShadow(fontRendererObj.trimStringToWidth(
                    "/priceset <price> or /setprice <price>  Set held-item price", contentWidth() - 24),
                    left, windowY() + 121, 0xE1DEE7);
            fontRendererObj.drawStringWithShadow(fontRendererObj.trimStringToWidth(
                    "/priceset <item name> <price>  Set a named price", contentWidth() - 24),
                    left, windowY() + 138, 0xE1DEE7);
            fontRendererObj.drawStringWithShadow(fontRendererObj.trimStringToWidth(
                    "Price confirmations appear in chat; saved prices affect drop totals.", contentWidth() - 24),
                    left, windowY() + 171, 0xB7B4C0);
        }
    }

    private void drawClearHistoryDialog() {
        int dialogX = clearDialogX();
        int dialogY = clearDialogY();
        int dialogWidth = clearDialogWidth();
        int dialogHeight = clearDialogHeight();
        Gui.drawRect(0, 0, width, height, 0x66000000);
        Gui.drawRect(dialogX - 2, dialogY - 2,
                dialogX + dialogWidth + 2, dialogY + dialogHeight + 2, 0xAA000000);
        Gui.drawRect(dialogX, dialogY, dialogX + dialogWidth,
                dialogY + dialogHeight, 0xF01A1A20);
        Gui.drawRect(dialogX, dialogY, dialogX + dialogWidth,
                dialogY + 3, 0xFF705794);

        String title = "Clear tracker history";
        fontRendererObj.drawStringWithShadow(title,
                dialogX + (dialogWidth - fontRendererObj.getStringWidth(title)) / 2,
                dialogY + 13, 0xFFFFFF);
        String subtitle = "Choose one history to remove.";
        fontRendererObj.drawStringWithShadow(fontRendererObj.trimStringToWidth(subtitle,
                dialogWidth - 18), dialogX + 9, dialogY + 32, 0xB7B4C0);
    }

    private void drawPageHeading(String title, String subtitle, int x, int y) {
        fontRendererObj.drawStringWithShadow(title, x, y, 0xFFFFFF);
        int available = hasPreviewForSelectedCategory()
                ? controlWidth() : contentWidth() - 24;
        fontRendererObj.drawStringWithShadow(fontRendererObj.trimStringToWidth(subtitle,
                Math.max(70, available)), x, y + 17, 0xB7B4C0);
    }

    private void drawPositionFields() {
        if ((selectedCategory != CATEGORY_TRACKER && selectedCategory != CATEGORY_FISHING
                && selectedCategory != CATEGORY_DEPLOYABLES) || xField == null || yField == null) {
            return;
        }
        fontRendererObj.drawStringWithShadow("X", xLabelX, xFieldY + 5, 0xC8C5CE);
        fontRendererObj.drawStringWithShadow("Y", yLabelX, yFieldY + 5, 0xC8C5CE);
        xField.drawTextBox();
        yField.drawTextBox();
    }

    private void drawPreview() {
        int cardX = previewCardX();
        int cardY = previewCardY();
        int cardW = previewCardWidth();
        int cardH = previewCardHeight();
        Gui.drawRect(cardX, cardY, cardX + cardW, cardY + cardH, 0x962D2C35);
        Gui.drawRect(cardX, cardY, cardX + cardW, cardY + 1, 0xFF62547A);
        fontRendererObj.drawStringWithShadow("LIVE PREVIEW", cardX + 9, cardY + 10, 0xE6E0EF);

        int canvasX = previewCanvasX();
        int canvasY = previewCanvasY();
        int canvasW = previewCanvasWidth();
        int canvasH = previewCanvasHeight();
        Gui.drawRect(canvasX - 1, canvasY - 1, canvasX + canvasW + 1,
                canvasY + canvasH + 1, 0xCC77717F);
        Gui.drawRect(canvasX, canvasY, canvasX + canvasW, canvasY + canvasH, 0xFF111720);
        for (int i = 1; i < 4; i++) {
            int lineX = canvasX + canvasW * i / 4;
            int lineY = canvasY + canvasH * i / 4;
            Gui.drawRect(lineX, canvasY, lineX + 1, canvasY + canvasH, 0x223E5067);
            Gui.drawRect(canvasX, lineY, canvasX + canvasW, lineY + 1, 0x223E5067);
        }

        int trackerX = miniTrackerX();
        int trackerY = miniTrackerY();
        int trackerW = miniTrackerWidth();
        int trackerH = miniTrackerHeight();
        int headerH = miniHeaderHeight();
        boolean fishingPreview = selectedCategory == CATEGORY_FISHING
                && selectedFishingPanel == FISHING_PANEL_COUNTER;
        boolean biteAlertPreview = selectedCategory == CATEGORY_FISHING
                && selectedFishingPanel == FISHING_PANEL_BITE_ALERT;
        boolean deployablesPreview = selectedCategory == CATEGORY_DEPLOYABLES;
        boolean nearbyCreatureHpPreview = selectedCategory == CATEGORY_FISHING
                && selectedFishingPanel == FISHING_PANEL_CREATURE_HP;
        boolean previewEnabled = nearbyCreatureHpPreview ? mod.isNearbyCreatureHpEnabled()
                : (biteAlertPreview ? mod.isBiteAlertEnabled()
                : (deployablesPreview ? mod.isDeployablesTimerPanelEnabled()
                : (fishingPreview ? mod.isFishingMobCounterEnabled() : mod.isTrackerEnabled())));
        if (biteAlertPreview) {
            int alertColor = previewEnabled ? 0xFF3B3B : 0xFF777777;
            Gui.drawRect(trackerX - 1, trackerY - 1, trackerX + trackerW + 1,
                    trackerY + trackerH + 1, 0xBB111111);
            GlStateManager.pushMatrix();
            GlStateManager.translate((float) trackerX, (float) trackerY, 0.0F);
            GlStateManager.scale(mod.getBiteAlertRenderScale() * previewScale(),
                    mod.getBiteAlertRenderScale() * previewScale(), 1.0F);
            fontRendererObj.drawStringWithShadow("!!!", 0, 0, alertColor);
            GlStateManager.popMatrix();
        } else if (nearbyCreatureHpPreview) {
            int outlineColor = previewEnabled ? 0x99507090 : 0x885B5B63;
            Gui.drawRect(trackerX, trackerY, trackerX + trackerW, trackerY + 1, outlineColor);
            Gui.drawRect(trackerX, trackerY + trackerH - 1,
                    trackerX + trackerW, trackerY + trackerH, outlineColor);
            Gui.drawRect(trackerX, trackerY, trackerX + 1, trackerY + trackerH, outlineColor);
            Gui.drawRect(trackerX + trackerW - 1, trackerY,
                    trackerX + trackerW, trackerY + trackerH, outlineColor);
            if (trackerW > 52 && trackerH > 11) {
                fontRendererObj.drawStringWithShadow("CREATURE HP", trackerX + 3, trackerY + 1,
                        previewEnabled ? 0xFFFF55 : 0x999999);
            }
            if (trackerH > headerH + 4) {
                Gui.drawRect(trackerX + 4, trackerY + headerH + 3,
                        Math.max(trackerX + 5, trackerX + trackerW - 5),
                        Math.min(trackerY + trackerH - 2, trackerY + headerH + 4), 0xFF77717A);
            }
            if (trackerH > headerH + 9) {
                Gui.drawRect(trackerX + 4, trackerY + headerH + 7,
                        Math.max(trackerX + 5, trackerX + trackerW - 5),
                        Math.min(trackerY + trackerH - 1, trackerY + headerH + 8), 0xFFFFD86A);
            }
        } else if (deployablesPreview) {
            int outlineColor = previewEnabled ? 0x99507090 : 0x885B5B63;
            Gui.drawRect(trackerX, trackerY, trackerX + trackerW, trackerY + 1, outlineColor);
            Gui.drawRect(trackerX, trackerY + trackerH - 1,
                    trackerX + trackerW, trackerY + trackerH, outlineColor);
            Gui.drawRect(trackerX, trackerY, trackerX + 1, trackerY + trackerH, outlineColor);
            Gui.drawRect(trackerX + trackerW - 1, trackerY,
                    trackerX + trackerW, trackerY + trackerH, outlineColor);
            if (trackerW > 62 && trackerH > 11) {
                fontRendererObj.drawStringWithShadow("DEPLOYABLES", trackerX + 3, trackerY + 1,
                        previewEnabled ? 0xFFFFFF : 0x999999);
            }
            if (trackerH > headerH + 4) {
                Gui.drawRect(trackerX + 4, trackerY + headerH + 3,
                        Math.max(trackerX + 5, trackerX + trackerW - 5),
                        Math.min(trackerY + trackerH - 2, trackerY + headerH + 4), 0xFF77717A);
            }
            if (trackerH > headerH + 9) {
                Gui.drawRect(trackerX + 4, trackerY + headerH + 7,
                        Math.max(trackerX + 5, trackerX + trackerW - 5),
                        Math.min(trackerY + trackerH - 1, trackerY + headerH + 8), 0xFFB7B4C0);
            }
        } else {
            int outlineColor = previewEnabled ? 0x99507090 : 0x885B5B63;
            Gui.drawRect(trackerX, trackerY, trackerX + trackerW, trackerY + 1, outlineColor);
            Gui.drawRect(trackerX, trackerY + trackerH - 1,
                    trackerX + trackerW, trackerY + trackerH, outlineColor);
            Gui.drawRect(trackerX, trackerY, trackerX + 1, trackerY + trackerH, outlineColor);
            Gui.drawRect(trackerX + trackerW - 1, trackerY,
                    trackerX + trackerW, trackerY + trackerH, outlineColor);
            if (trackerW > 42 && trackerH > 11) {
                fontRendererObj.drawStringWithShadow(fishingPreview ? "FISHING" : "TRACKER",
                        trackerX + 3, trackerY + 1, previewEnabled ? 0xFFFFFF : 0x999999);
            }
            if (trackerH > headerH + 4) {
                Gui.drawRect(trackerX + 4, trackerY + headerH + 3,
                        Math.max(trackerX + 5, trackerX + trackerW - 5),
                        Math.min(trackerY + trackerH - 2, trackerY + headerH + 4), 0xFF77717A);
            }
            if (trackerH > headerH + 9) {
                Gui.drawRect(trackerX + 4, trackerY + headerH + 7,
                        Math.max(trackerX + 5, trackerX + trackerW - 5),
                        Math.min(trackerY + trackerH - 1, trackerY + headerH + 8), 0xFFFFD86A);
            }
        }

        String position = "X " + getSelectedPositionX() + "   Y " + getSelectedPositionY();
        fontRendererObj.drawStringWithShadow(position, cardX + 9, cardY + cardH - 27, 0xD2CED9);
        String instruction = biteAlertPreview ? "Drag the red marker to move"
                : (deployablesPreview ? "Drag the timer panel to move"
                : (nearbyCreatureHpPreview ? "Drag the HP panel to move" : "Drag the header to move"));
        fontRendererObj.drawStringWithShadow(fontRendererObj.trimStringToWidth(instruction, cardW - 18),
                cardX + 9, cardY + cardH - 15, 0xAAA6B2);
    }

    private int miniTrackerX() {
        return previewCanvasX() + Math.round(getSelectedPositionX() * previewScale());
    }

    private int miniTrackerY() {
        return previewCanvasY() + Math.round(getSelectedPositionY() * previewScale());
    }

    private int miniTrackerWidth() {
        int renderedWidth;
        if (selectedCategory == CATEGORY_FISHING) {
            if (selectedFishingPanel == FISHING_PANEL_BITE_ALERT) {
                renderedWidth = mod.getRenderedBiteAlertWidth();
            } else if (selectedFishingPanel == FISHING_PANEL_CREATURE_HP) {
                renderedWidth = mod.getRenderedNearbyCreatureHpPanelWidth(width);
            } else {
                renderedWidth = mod.getRenderedFishingTrackerWidth(width);
            }
        } else if (selectedCategory == CATEGORY_DEPLOYABLES) {
            renderedWidth = mod.getRenderedDeployablesTimerPanelWidth(width);
        } else {
            renderedWidth = mod.getRenderedTrackerWidth(width);
        }
        return Math.max(4, Math.round(renderedWidth * previewScale()));
    }

    private int miniTrackerHeight() {
        int renderedHeight;
        if (selectedCategory == CATEGORY_FISHING) {
            if (selectedFishingPanel == FISHING_PANEL_BITE_ALERT) {
                renderedHeight = mod.getRenderedBiteAlertHeight();
            } else if (selectedFishingPanel == FISHING_PANEL_CREATURE_HP) {
                renderedHeight = mod.getRenderedNearbyCreatureHpPanelHeight();
            } else {
                renderedHeight = mod.getRenderedFishingTrackerHeight();
            }
        } else if (selectedCategory == CATEGORY_DEPLOYABLES) {
            renderedHeight = mod.getRenderedDeployablesTimerPanelHeight();
        } else {
            renderedHeight = mod.getRenderedTrackerHeight();
        }
        return Math.max(4, Math.round(renderedHeight * previewScale()));
    }

    private int miniHeaderHeight() {
        if ((selectedCategory == CATEGORY_FISHING
                && selectedFishingPanel == FISHING_PANEL_BITE_ALERT)
                || selectedCategory == CATEGORY_DEPLOYABLES) {
            return miniTrackerHeight();
        }
        int sizePercent = selectedCategory == CATEGORY_FISHING
                && selectedFishingPanel == FISHING_PANEL_CREATURE_HP
                ? mod.getNearbyCreatureHpSizePercent() : mod.getTrackerSizePercent();
        int scaledHeader = Math.round(18.0F * sizePercent / 100.0F * previewScale());
        return Math.min(miniTrackerHeight(), Math.max(5, scaledHeader));
    }

    private boolean isPreviewHeaderAt(int mouseX, int mouseY) {
        if (!hasPreviewForSelectedCategory()) {
            return false;
        }
        return mouseX >= miniTrackerX() && mouseX <= miniTrackerX() + miniTrackerWidth()
                && mouseY >= miniTrackerY() && mouseY <= miniTrackerY() + miniHeaderHeight();
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        if (button.id == BUTTON_TOGGLE) {
            mod.toggleTracker();
            button.displayString = trackerButtonLabel();
        } else if (button.id == BUTTON_M7_OVERLAY_TOGGLE) {
            mod.toggleM7Overlay();
            button.displayString = dungeonButtonLabel();
        } else if (button.id == BUTTON_M7_MAXOR_TOGGLE) {
            mod.toggleM7BossHitbox(M7OverlayRenderer.M7HitboxTarget.MAXOR);
            button.displayString = m7BossButtonLabel("Maxor", M7OverlayRenderer.M7HitboxTarget.MAXOR);
        } else if (button.id == BUTTON_M7_STORM_TOGGLE) {
            mod.toggleM7BossHitbox(M7OverlayRenderer.M7HitboxTarget.STORM);
            button.displayString = m7BossButtonLabel("Storm", M7OverlayRenderer.M7HitboxTarget.STORM);
        } else if (button.id == BUTTON_M7_GOLDOR_TOGGLE) {
            mod.toggleM7BossHitbox(M7OverlayRenderer.M7HitboxTarget.GOLDOR);
            button.displayString = m7BossButtonLabel("Goldor", M7OverlayRenderer.M7HitboxTarget.GOLDOR);
        } else if (button.id == BUTTON_M7_NECRON_TOGGLE) {
            mod.toggleM7BossHitbox(M7OverlayRenderer.M7HitboxTarget.NECRON);
            button.displayString = m7BossButtonLabel("Necron", M7OverlayRenderer.M7HitboxTarget.NECRON);
        } else if (button.id == BUTTON_M7_APEX_TOGGLE) {
            mod.toggleM7DragonHitbox(M7OverlayRenderer.M7DragonStatue.APEX);
            button.displayString = m7DragonButtonLabel("Apex", M7OverlayRenderer.M7DragonStatue.APEX);
        } else if (button.id == BUTTON_M7_FLAME_TOGGLE) {
            mod.toggleM7DragonHitbox(M7OverlayRenderer.M7DragonStatue.FLAME);
            button.displayString = m7DragonButtonLabel("Flame", M7OverlayRenderer.M7DragonStatue.FLAME);
        } else if (button.id == BUTTON_M7_ICE_TOGGLE) {
            mod.toggleM7DragonHitbox(M7OverlayRenderer.M7DragonStatue.ICE);
            button.displayString = m7DragonButtonLabel("Ice", M7OverlayRenderer.M7DragonStatue.ICE);
        } else if (button.id == BUTTON_M7_POWER_TOGGLE) {
            mod.toggleM7DragonHitbox(M7OverlayRenderer.M7DragonStatue.POWER);
            button.displayString = m7DragonButtonLabel("Power", M7OverlayRenderer.M7DragonStatue.POWER);
        } else if (button.id == BUTTON_M7_SOUL_TOGGLE) {
            mod.toggleM7DragonHitbox(M7OverlayRenderer.M7DragonStatue.SOUL);
            button.displayString = m7DragonButtonLabel("Soul", M7OverlayRenderer.M7DragonStatue.SOUL);
        } else if (button.id == BUTTON_M7_STATUE_ZONES_TOGGLE) {
            mod.toggleM7StatueZones();
            button.displayString = statueZonesButtonLabel();
        } else if (button.id == BUTTON_TOTEM_TIMER_TOGGLE) {
            mod.toggleTotemTimer();
            button.displayString = totemTimerButtonLabel();
        } else if (button.id == BUTTON_SOS_FLARE_TIMER_TOGGLE) {
            mod.toggleSosFlareTimer();
            button.displayString = sosFlareTimerButtonLabel();
        } else if (button.id == BUTTON_PLASMAFLUX_TIMER_TOGGLE) {
            mod.togglePlasmafluxTimer();
            button.displayString = plasmafluxTimerButtonLabel();
        } else if (button.id == BUTTON_APPLY_POSITION) {
            applyPosition();
        } else if (button.id == BUTTON_RESET_POSITION) {
            mod.resetTrackerPosition();
            mod.clampTrackerPosition(width, height);
            positionError = false;
            updatePositionFields();
        } else if (button.id == BUTTON_CLEAR) {
            clearHistoryDialogOpen = true;
            initGui();
        } else if (button.id == BUTTON_CLEAR_SPIDER) {
            clearSelectedHistory(SlayerType.SPIDER);
        } else if (button.id == BUTTON_CLEAR_REVENANT) {
            clearSelectedHistory(SlayerType.REVENANT);
        } else if (button.id == BUTTON_CLEAR_BLAZE) {
            clearSelectedHistory(SlayerType.BLAZE);
        } else if (button.id == BUTTON_CLEAR_WOLF) {
            clearSelectedHistory(SlayerType.WOLF);
        } else if (button.id == BUTTON_CLEAR_ENDERMAN) {
            clearSelectedHistory(SlayerType.ENDERMAN);
        } else if (button.id == BUTTON_CLEAR_FISHING) {
            mod.clearFishingHistory();
            clearHistoryDialogOpen = false;
            initGui();
        } else if (button.id == BUTTON_FISHING_MODE_COUNTER) {
            selectFishingPanel(FISHING_PANEL_COUNTER);
        } else if (button.id == BUTTON_FISHING_MODE_BITE) {
            selectFishingPanel(FISHING_PANEL_BITE_ALERT);
        } else if (button.id == BUTTON_FISHING_MODE_CREATURE_HP) {
            selectFishingPanel(FISHING_PANEL_CREATURE_HP);
        } else if (button.id == BUTTON_FISHING_TOGGLE) {
            mod.toggleFishingMobCounter();
            button.displayString = fishingButtonLabel();
        } else if (button.id == BUTTON_JAWBUS_ALERT_TOGGLE) {
            mod.toggleJawbusAlert();
            button.displayString = jawbusAlertButtonLabel();
        } else if (button.id == BUTTON_APPLY_FISHING_POSITION) {
            applyPosition();
        } else if (button.id == BUTTON_RESET_FISHING_POSITION) {
            if (selectedFishingPanel == FISHING_PANEL_BITE_ALERT) {
                mod.resetBiteAlertPosition(width, height);
            } else if (selectedFishingPanel == FISHING_PANEL_CREATURE_HP) {
                mod.resetNearbyCreatureHpPosition(width, height);
            } else {
                mod.resetFishingPosition(width, height);
                mod.clampFishingTrackerPosition(width, height);
            }
            positionError = false;
            updatePositionFields();
        } else if (button.id == BUTTON_BITE_ALERT_TOGGLE) {
            mod.toggleBiteAlert();
            button.displayString = biteAlertButtonLabel();
        } else if (button.id == BUTTON_APPLY_BITE_ALERT_POSITION) {
            applyPosition();
        } else if (button.id == BUTTON_RESET_BITE_ALERT_POSITION) {
            mod.resetBiteAlertPosition(width, height);
            positionError = false;
            updatePositionFields();
        } else if (button.id == BUTTON_BITE_ALERT_SIZE_DOWN) {
            mod.adjustBiteAlertSize(-5, width, height);
        } else if (button.id == BUTTON_BITE_ALERT_SIZE_UP) {
            mod.adjustBiteAlertSize(5, width, height);
        } else if (button.id == BUTTON_BITE_ALERT_SIZE_RESET) {
            mod.resetBiteAlertSize(width, height);
        } else if (button.id == BUTTON_DEPLOYABLES_TOGGLE) {
            mod.toggleDeployablesTimerPanel();
            button.displayString = deployablesButtonLabel();
        } else if (button.id == BUTTON_APPLY_DEPLOYABLES_POSITION) {
            applyPosition();
        } else if (button.id == BUTTON_RESET_DEPLOYABLES_POSITION) {
            mod.resetDeployablesTimerPanelPosition(width, height);
            positionError = false;
            updatePositionFields();
        } else if (button.id == BUTTON_DEPLOYABLES_SIZE_DOWN) {
            mod.adjustDeployablesTimerPanelSize(-5, width, height);
        } else if (button.id == BUTTON_DEPLOYABLES_SIZE_UP) {
            mod.adjustDeployablesTimerPanelSize(5, width, height);
        } else if (button.id == BUTTON_DEPLOYABLES_SIZE_RESET) {
            mod.resetDeployablesTimerPanelSize(width, height);
        } else if (button.id == BUTTON_NEARBY_CREATURE_HP_TOGGLE) {
            mod.toggleNearbyCreatureHp();
            button.displayString = nearbyCreatureHpButtonLabel();
        } else if (button.id == BUTTON_APPLY_NEARBY_CREATURE_HP_POSITION) {
            applyPosition();
        } else if (button.id == BUTTON_RESET_NEARBY_CREATURE_HP_POSITION) {
            mod.resetNearbyCreatureHpPosition(width, height);
            positionError = false;
            updatePositionFields();
        } else if (button.id == BUTTON_NEARBY_CREATURE_HP_SIZE_DOWN) {
            mod.adjustNearbyCreatureHpSize(-5, width, height);
        } else if (button.id == BUTTON_NEARBY_CREATURE_HP_SIZE_UP) {
            mod.adjustNearbyCreatureHpSize(5, width, height);
        } else if (button.id == BUTTON_NEARBY_CREATURE_HP_SIZE_RESET) {
            mod.resetNearbyCreatureHpSize(width, height);
        } else if (button.id == BUTTON_CLEAR_CANCEL) {
            clearHistoryDialogOpen = false;
            initGui();
        } else if (button.id == BUTTON_SIZE_DOWN) {
            mod.adjustTrackerSize(-5, width, height);
        } else if (button.id == BUTTON_SIZE_UP) {
            mod.adjustTrackerSize(5, width, height);
        } else if (button.id == BUTTON_SIZE_RESET) {
            mod.resetTrackerSize(width, height);
        } else if (button.id == BUTTON_DONE) {
            mc.displayGuiScreen(null);
        }
    }

    private void clearSelectedHistory(SlayerType slayer) {
        mod.clearHistory(slayer);
        clearHistoryDialogOpen = false;
        initGui();
    }

    private void applyPosition() {
        try {
            int x = Integer.parseInt(xField.getText().trim());
            int y = Integer.parseInt(yField.getText().trim());
            if (selectedCategory == CATEGORY_FISHING) {
                if (selectedFishingPanel == FISHING_PANEL_BITE_ALERT) {
                    mod.moveBiteAlertTo(x, y, width, height);
                } else if (selectedFishingPanel == FISHING_PANEL_CREATURE_HP) {
                    mod.moveNearbyCreatureHpPanelTo(x, y, width, height);
                } else {
                    mod.moveFishingTrackerTo(x, y, width, height);
                }
            } else if (selectedCategory == CATEGORY_DEPLOYABLES) {
                mod.moveDeployablesTimerPanelTo(x, y, width, height);
            } else {
                mod.moveTrackerTo(x, y, width, height);
            }
            mod.saveSettings();
            positionError = false;
            updatePositionFields();
        } catch (NumberFormatException ignored) {
            positionError = true;
        }
    }

    private void selectFishingPanel(int panel) {
        selectedFishingPanel = panel;
        positionError = false;
        initGui();
    }

    private void updatePositionFields() {
        if (xField != null && yField != null) {
            xField.setText(Integer.toString(getSelectedPositionX()));
            yField.setText(Integer.toString(getSelectedPositionY()));
        }
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        if (clearHistoryDialogOpen) {
            super.mouseClicked(mouseX, mouseY, mouseButton);
            return;
        }
        if (mouseButton == 0) {
            for (int i = 0; i < CATEGORY_NAMES.length; i++) {
                if (mouseX >= windowX() + 10 && mouseX <= windowX() + sideWidth() - 6
                        && mouseY >= categoryRowY(i) && mouseY <= categoryRowY(i) + 25) {
                    selectedCategory = i;
                    positionError = false;
                    initGui();
                    return;
                }
            }
            if (isPreviewHeaderAt(mouseX, mouseY)) {
                draggingPreview = true;
                dragOffsetX = mouseX - miniTrackerX();
                dragOffsetY = mouseY - miniTrackerY();
                return;
            }
        }

        if (xField != null) {
            xField.mouseClicked(mouseX, mouseY, mouseButton);
            yField.mouseClicked(mouseX, mouseY, mouseButton);
        }
        super.mouseClicked(mouseX, mouseY, mouseButton);
    }

    @Override
    protected void mouseClickMove(int mouseX, int mouseY, int clickedMouseButton,
                                  long timeSinceLastClick) {
        if (draggingPreview && clickedMouseButton == 0) {
            float scale = previewScale();
            int x = Math.round((mouseX - dragOffsetX - previewCanvasX()) / scale);
            int y = Math.round((mouseY - dragOffsetY - previewCanvasY()) / scale);
            if (selectedCategory == CATEGORY_FISHING) {
                if (selectedFishingPanel == FISHING_PANEL_BITE_ALERT) {
                    mod.moveBiteAlertTo(x, y, width, height);
                } else if (selectedFishingPanel == FISHING_PANEL_CREATURE_HP) {
                    mod.moveNearbyCreatureHpPanelTo(x, y, width, height);
                } else {
                    mod.moveFishingTrackerTo(x, y, width, height);
                }
            } else if (selectedCategory == CATEGORY_DEPLOYABLES) {
                mod.moveDeployablesTimerPanelTo(x, y, width, height);
            } else {
                mod.moveTrackerTo(x, y, width, height);
            }
            updatePositionFields();
        }
        super.mouseClickMove(mouseX, mouseY, clickedMouseButton, timeSinceLastClick);
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        if (draggingPreview) {
            draggingPreview = false;
            mod.saveSettings();
        }
        super.mouseReleased(mouseX, mouseY, state);
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (keyCode == 1) {
            if (clearHistoryDialogOpen) {
                clearHistoryDialogOpen = false;
                initGui();
            } else {
                mc.displayGuiScreen(null);
            }
            return;
        }
        if (xField != null && (xField.textboxKeyTyped(typedChar, keyCode)
                || yField.textboxKeyTyped(typedChar, keyCode))) {
            positionError = false;
            return;
        }
        super.keyTyped(typedChar, keyCode);
    }

    @Override
    public void onGuiClosed() {
        if (draggingPreview) {
            draggingPreview = false;
            mod.saveSettings();
        }
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    private boolean hasPreview() {
        return contentWidth() >= 300 && windowHeight() >= 240;
    }

    private boolean hasPreviewForSelectedCategory() {
        return hasPreview() && selectedCategory != CATEGORY_DUNGEON
                && selectedCategory != CATEGORY_ABOUT;
    }

    private int clearDialogWidth() {
        return Math.min(280, Math.max(180, windowWidth() - 20));
    }

    private int clearDialogHeight() {
        return Math.min(190, Math.max(180, windowHeight() - 20));
    }

    private int clearDialogX() {
        return windowX() + (windowWidth() - clearDialogWidth()) / 2;
    }

    private int clearDialogY() {
        return windowY() + (windowHeight() - clearDialogHeight()) / 2;
    }

    private int trackerToggleY() {
        return windowY() + (windowHeight() < 300 ? 72 : 88);
    }

    private int fishingPositionTitleY() {
        int tabsHeight = controlWidth() >= 190 ? 20 : 58;
        return trackerToggleY() + tabsHeight + 54;
    }

    private int windowX() {
        return (width - windowWidth()) / 2;
    }

    private int windowY() {
        return (height - windowHeight()) / 2;
    }

    private int windowWidth() {
        return Math.min(700, Math.max(200, width - 16));
    }

    private int windowHeight() {
        return Math.min(430, Math.max(200, height - 16));
    }

    private int sideWidth() {
        return Math.min(150, Math.max(94, windowWidth() / 4));
    }

    private int contentX() {
        return windowX() + sideWidth() + 7;
    }

    private int contentWidth() {
        return windowWidth() - sideWidth() - 25;
    }

    private int controlX() {
        return contentX() + 12;
    }

    private int controlWidth() {
        if (hasPreviewForSelectedCategory()) {
            return Math.max(110, contentWidth() - previewCardWidth() - 25);
        }
        return Math.max(100, contentWidth() - 24);
    }

    private int footerButtonWidth() {
        return Math.min(100, Math.max(68, (contentWidth() - 28) / 2));
    }

    private int categoryRowY(int index) {
        return windowY() + 73 + index * 31;
    }

    private int previewCardWidth() {
        return Math.min(232, Math.max(130, contentWidth() / 2 - 8));
    }

    private int previewCardHeight() {
        return Math.max(110, windowHeight() - 102);
    }

    private int previewCardX() {
        return contentX() + contentWidth() - previewCardWidth() - 8;
    }

    private int previewCardY() {
        return windowY() + 51;
    }

    private int previewCanvasAvailableWidth() {
        return Math.max(1, previewCardWidth() - 18);
    }

    private int previewCanvasAvailableHeight() {
        return Math.max(1, previewCardHeight() - 58);
    }

    private float previewScale() {
        float scaleX = previewCanvasAvailableWidth() / (float) Math.max(1, width);
        float scaleY = previewCanvasAvailableHeight() / (float) Math.max(1, height);
        return Math.max(0.001F, Math.min(scaleX, scaleY));
    }

    private int previewCanvasWidth() {
        return Math.max(1, Math.round(width * previewScale()));
    }

    private int previewCanvasHeight() {
        return Math.max(1, Math.round(height * previewScale()));
    }

    private int previewCanvasX() {
        return previewCardX() + (previewCardWidth() - previewCanvasWidth()) / 2;
    }

    private int previewCanvasY() {
        return previewCardY() + 31
                + (previewCanvasAvailableHeight() - previewCanvasHeight()) / 2;
    }

    private String trackerButtonLabel() {
        return mod.isTrackerEnabled() ? "Tracker: ON" : "Tracker: OFF";
    }

    private String fishingButtonLabel() {
        return mod.isFishingMobCounterEnabled() ? "Mob Counter: ON" : "Mob Counter: OFF";
    }

    private String biteAlertButtonLabel() {
        return mod.isBiteAlertEnabled() ? "Bite Alert: ON" : "Bite Alert: OFF";
    }

    private String deployablesButtonLabel() {
        return mod.isDeployablesTimerPanelEnabled() ? "Deployable timers: ON" : "Deployable timers: OFF";
    }

    private String nearbyCreatureHpButtonLabel() {
        return mod.isNearbyCreatureHpEnabled() ? "Nearby creature HP: ON" : "Nearby creature HP: OFF";
    }

    private String jawbusAlertButtonLabel() {
        return mod.isJawbusAlertEnabled() ? "Jawbus title: ON" : "Jawbus title: OFF";
    }

    private String dungeonButtonLabel() {
        return mod.isM7OverlayEnabled() ? "M7 outlines: ON" : "M7 outlines: OFF";
    }

    private String m7BossButtonLabel(String name, M7OverlayRenderer.M7HitboxTarget target) {
        return name + ": " + (mod.isM7BossHitboxEnabled(target) ? "ON" : "OFF");
    }

    private String m7DragonButtonLabel(String name, M7OverlayRenderer.M7DragonStatue statue) {
        return name + ": " + (mod.isM7DragonHitboxEnabled(statue) ? "ON" : "OFF");
    }

    private String statueZonesButtonLabel() {
        return "Kill zones: " + (mod.isM7StatueZonesEnabled() ? "ON" : "OFF");
    }

    private String totemTimerButtonLabel() {
        return mod.isTotemTimerEnabled() ? "Totem timer: ON" : "Totem timer: OFF";
    }

    private String sosFlareTimerButtonLabel() {
        return mod.isSosFlareTimerEnabled() ? "SOS timer: ON" : "SOS timer: OFF";
    }

    private String plasmafluxTimerButtonLabel() {
        return mod.isPlasmafluxTimerEnabled() ? "Plasmaflux: ON" : "Plasmaflux: OFF";
    }
}
