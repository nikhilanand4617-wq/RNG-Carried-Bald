package dev.arena.spiderdropalert;

import java.io.File;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

public class SpiderDropAlertTest {
    @Test
    public void identifiesM7ScoreboardAndRejectsNormalOrOtherMasterFloors() {
        assertTrue(M7OverlayRenderer.isM7ScoreboardText("The Catacombs - Master Mode Floor VII"));
        assertTrue(M7OverlayRenderer.isM7ScoreboardText("Catacombs (M7)"));
        assertTrue(M7OverlayRenderer.isM7ScoreboardText("MM - Floor 7"));
        assertTrue(M7OverlayRenderer.isM7ScoreboardText("Master Mode - F7"));
        assertTrue(M7OverlayRenderer.isM7ScoreboardText("Master Mode - F 7"));
        assertTrue(M7OverlayRenderer.isM7ScoreboardText("Master Mode - Floor VII"));
        assertFalse(M7OverlayRenderer.isM7ScoreboardText("The Catacombs - Floor VII"));
        assertFalse(M7OverlayRenderer.isM7ScoreboardText("The Catacombs - F7"));
        assertFalse(M7OverlayRenderer.isM7ScoreboardText("Master Mode Floor VI"));
        assertFalse(M7OverlayRenderer.isM7ScoreboardText(null));
    }

    @Test
    public void classifiesTheFourM7BossesAndDragonEntityHitboxes() {
        assertEquals(M7OverlayRenderer.M7HitboxTarget.MAXOR,
                M7OverlayRenderer.classifyM7HitboxTarget("\u00A7c[BOSS] Maxor", false));
        assertEquals(M7OverlayRenderer.M7HitboxTarget.STORM,
                M7OverlayRenderer.classifyM7HitboxTarget("Storm", false));
        assertEquals(M7OverlayRenderer.M7HitboxTarget.GOLDOR,
                M7OverlayRenderer.classifyM7HitboxTarget("Goldor", false));
        assertEquals(M7OverlayRenderer.M7HitboxTarget.NECRON,
                M7OverlayRenderer.classifyM7HitboxTarget("Necron", false));
        assertEquals(M7OverlayRenderer.M7HitboxTarget.DRAGON,
                M7OverlayRenderer.classifyM7HitboxTarget("Ender Dragon", true));
        assertEquals(M7OverlayRenderer.M7HitboxTarget.DRAGON,
                M7OverlayRenderer.classifyM7HitboxTarget("Apex Dragon", false));
        assertNull(M7OverlayRenderer.classifyM7HitboxTarget("Wither Skeleton", false));
    }

    @Test
    public void featureSwitchesRemainIndependentAndPersist() throws Exception {
        File settingsFile = File.createTempFile("spider-drop-feature-switches-", ".properties");
        try {
            SpiderDropAlert mod = new SpiderDropAlert(settingsFile);
            mod.startTotemFallbackTimer(100L);
            mod.startSosFlareTimer(100L);
            mod.startPlasmafluxTimer(100L);

            assertTrue(mod.isM7BossHitboxEnabled(M7OverlayRenderer.M7HitboxTarget.MAXOR));
            assertTrue(mod.isM7BossHitboxEnabled(M7OverlayRenderer.M7HitboxTarget.STORM));
            assertTrue(mod.isM7BossHitboxEnabled(M7OverlayRenderer.M7HitboxTarget.GOLDOR));
            assertTrue(mod.isM7BossHitboxEnabled(M7OverlayRenderer.M7HitboxTarget.NECRON));
            assertTrue(mod.isM7DragonHitboxEnabled(M7OverlayRenderer.M7DragonStatue.POWER));
            assertTrue(mod.isM7DragonHitboxEnabled(M7OverlayRenderer.M7DragonStatue.APEX));
            assertTrue(mod.isM7DragonHitboxEnabled(M7OverlayRenderer.M7DragonStatue.SOUL));
            assertTrue(mod.isM7DragonHitboxEnabled(M7OverlayRenderer.M7DragonStatue.ICE));
            assertTrue(mod.isM7DragonHitboxEnabled(M7OverlayRenderer.M7DragonStatue.FLAME));
            assertTrue(mod.isM7StatueZonesEnabled());
            mod.toggleM7BossHitbox(M7OverlayRenderer.M7HitboxTarget.MAXOR);
            mod.toggleM7DragonHitbox(M7OverlayRenderer.M7DragonStatue.ICE);
            mod.toggleM7StatueZones();

            mod.toggleM7Overlay();
            mod.toggleTotemTimer();
            mod.toggleSosFlareTimer();
            mod.togglePlasmafluxTimer();

            assertFalse(mod.isM7OverlayEnabled());
            assertFalse(mod.isM7BossHitboxEnabled(M7OverlayRenderer.M7HitboxTarget.MAXOR));
            assertTrue(mod.isM7BossHitboxEnabled(M7OverlayRenderer.M7HitboxTarget.STORM));
            assertFalse(mod.isM7DragonHitboxEnabled(M7OverlayRenderer.M7DragonStatue.ICE));
            assertTrue(mod.isM7DragonHitboxEnabled(M7OverlayRenderer.M7DragonStatue.POWER));
            assertFalse(mod.isM7StatueZonesEnabled());
            assertFalse(mod.isTotemTimerEnabled());
            assertFalse(mod.isSosFlareTimerEnabled());
            assertFalse(mod.isPlasmafluxTimerEnabled());
            assertTrue(mod.isTrackerEnabled());
            assertTrue(mod.isDeployablesTimerPanelEnabled());
            assertEquals(0, mod.getTotemRemainingSeconds(100L));
            assertEquals(0, mod.getSosFlareRemainingSeconds(100L));
            assertEquals(0, mod.getPlasmafluxRemainingSeconds(100L));
            assertFalse(mod.isDeployablesTimerPanelVisible(100L));

            SpiderDropAlert loaded = new SpiderDropAlert(settingsFile);
            assertFalse(loaded.isM7OverlayEnabled());
            assertFalse(loaded.isM7BossHitboxEnabled(M7OverlayRenderer.M7HitboxTarget.MAXOR));
            assertTrue(loaded.isM7BossHitboxEnabled(M7OverlayRenderer.M7HitboxTarget.STORM));
            assertFalse(loaded.isM7DragonHitboxEnabled(M7OverlayRenderer.M7DragonStatue.ICE));
            assertTrue(loaded.isM7DragonHitboxEnabled(M7OverlayRenderer.M7DragonStatue.POWER));
            assertFalse(loaded.isM7StatueZonesEnabled());
            assertFalse(loaded.isTotemTimerEnabled());
            assertFalse(loaded.isSosFlareTimerEnabled());
            assertFalse(loaded.isPlasmafluxTimerEnabled());
            assertTrue(loaded.isTrackerEnabled());
            assertTrue(loaded.isDeployablesTimerPanelEnabled());
        } finally {
            settingsFile.delete();
        }
    }

    @Test
    public void mapsAllFiveM7DragonsToTheirColoredStatueKillZones() {
        assertEquals(5, M7OverlayRenderer.M7DragonStatue.values().length);
        assertEquals(M7OverlayRenderer.M7DragonStatue.APEX,
                M7OverlayRenderer.dragonStatueForName("Apex Dragon"));
        assertEquals(M7OverlayRenderer.M7DragonStatue.FLAME,
                M7OverlayRenderer.dragonStatueForName("Flame Dragon"));
        assertEquals(M7OverlayRenderer.M7DragonStatue.ICE,
                M7OverlayRenderer.dragonStatueForName("Ice Dragon"));
        assertEquals(M7OverlayRenderer.M7DragonStatue.POWER,
                M7OverlayRenderer.dragonStatueForName("Power Dragon"));
        assertEquals(M7OverlayRenderer.M7DragonStatue.SOUL,
                M7OverlayRenderer.dragonStatueForName("Soul Dragon"));
        assertEquals(M7OverlayRenderer.M7DragonStatue.POWER,
                M7OverlayRenderer.nearestM7DragonStatue(27.0D, 59.0D));
        assertEquals(6.0D, M7OverlayRenderer.M7DragonStatue.POWER.killZone.minY, 0.0D);
        assertEquals(29.5D, M7OverlayRenderer.M7DragonStatue.POWER.killZone.maxY, 0.0D);
        assertEquals(13.5D,
                M7OverlayRenderer.M7DragonStatue.POWER.anchor.getX()
                        - M7OverlayRenderer.M7DragonStatue.POWER.killZone.minX, 0.0D);
        assertEquals(13.5D,
                M7OverlayRenderer.M7DragonStatue.POWER.killZone.maxZ
                        - M7OverlayRenderer.M7DragonStatue.POWER.anchor.getZ(), 0.0D);
    }

    @Test
    public void extractsItemAndRemovesMagicFindSuffix() {
        assertEquals("Tarantula Talisman", DropMessageParser.extractDropItem(
                "VERY RARE DROP! Tarantula Talisman (+25% Magic Find)"));
    }

    @Test
    public void preservesParenthesesThatArePartOfTheItemName() {
        assertEquals("Enchanted Book (Bane of Arthropods VI)", DropMessageParser.extractDropItem(
                "RARE DROP! Enchanted Book (Bane of Arthropods VI) (x1) (+25% Magic Find)"));
    }

    @Test
    public void recognizesSpiderRewardsButNotOtherRareDrops() {
        assertTrue(DropMessageParser.isSpiderSlayerRareDrop("VERY RARE DROP! Tarantula Talisman"));
        assertTrue(DropMessageParser.isSpiderSlayerRareDrop("RARE DROP! Spider Slayer reward: Unknown Gem"));
        assertFalse(DropMessageParser.isSpiderSlayerRareDrop("RARE DROP! Enchanted Ender Armor"));
        assertTrue(DropMessageParser.isSpiderSlayerRareDrop("RARE DROP! Toxic Arrow Poison"));
        assertTrue(DropMessageParser.isSpiderSlayerRareDrop(
                "RARE DROP! (1x Tarantula Silk) (+157% Magic Find!)"));
        assertTrue(DropMessageParser.isSpiderSlayerRareDrop(
                "RARE DROP! Spider Slayer reward: Toxic Arrow Poison"));
        assertFalse(DropMessageParser.isSpiderSlayerRareDrop(
                "[MVP+] Player: RARE DROP! (1x Tarantula Silk) (+157% Magic Find!)"));
    }

    @Test
    public void detectsAllFiveSupportedSlayerTypes() {
        SlayerType[] orderedTypes = SlayerType.values();
        assertEquals(5, orderedTypes.length);
        assertEquals(SlayerType.SPIDER, orderedTypes[0]);
        assertEquals(SlayerType.REVENANT, orderedTypes[1]);
        assertEquals(SlayerType.BLAZE, orderedTypes[2]);
        assertEquals(SlayerType.WOLF, orderedTypes[3]);
        assertEquals(SlayerType.ENDERMAN, orderedTypes[4]);
        assertEquals(SlayerType.SPIDER,
                DropMessageParser.detectSlayer("RARE DROP! (64x Toxic Arrow Poison)"));
        assertEquals(SlayerType.REVENANT,
                DropMessageParser.detectSlayer("RARE DROP! (1x Scythe Blade)"));
        assertEquals(SlayerType.BLAZE,
                DropMessageParser.detectSlayer("RARE DROP! (1x Archfiend Dice)"));
        assertEquals(SlayerType.WOLF,
                DropMessageParser.detectSlayer("RARE DROP! (1x Overflux Capacitor)"));
        assertEquals(SlayerType.ENDERMAN,
                DropMessageParser.detectSlayer("RARE DROP! (1x Judgement Core)"));
        assertNull(DropMessageParser.detectSlayer("RARE DROP! Summoning Eye"));
        assertNull(DropMessageParser.detectSlayer("RARE DROP! Paragon Shard"));
        assertNull(DropMessageParser.detectSlayer(
                "[MVP+] Player: RARE DROP! (1x Judgement Core)"));
        assertNull(DropMessageParser.detectSlayer(
                "[MVP+] Player: RARE DROP! (1x Scythe Blade)"));
        assertNull(DropMessageParser.detectSlayer(
                "[MVP+] Player: VERY RARE DROP! Tarantula Talisman"));
    }

    @Test
    public void detectsSpawnMessagesForAllFiveSlayerBossesAndRejectsPlayerLines() {
        assertEquals(SlayerType.SPIDER,
                DropMessageParser.detectSlayerBossSpawnMessage(
                        "[BOSS] Tarantula Broodfather: Welcome to my den."));
        assertEquals(SlayerType.SPIDER,
                DropMessageParser.detectSlayerBossName("[Lv 750] Primordial Broodfather"));
        assertEquals(SlayerType.REVENANT,
                DropMessageParser.detectSlayerBossSpawnMessage("[BOSS] Atoned Horror: Rise."));
        assertEquals(SlayerType.BLAZE,
                DropMessageParser.detectSlayerBossSpawnMessage(
                        "\u00A7c[BOSS] Inferno Demonlord: Burn."));
        assertEquals(SlayerType.WOLF,
                DropMessageParser.detectSlayerBossSpawnMessage("[BOSS] Sven Packmaster: Howl."));
        assertEquals(SlayerType.ENDERMAN,
                DropMessageParser.detectSlayerBossSpawnMessage("[BOSS] Voidgloom Seraph: ..."));
        assertNull(DropMessageParser.detectSlayerBossSpawnMessage(
                "[MVP+] Player: [BOSS] Tarantula Broodfather: copied text"));
        assertNull(DropMessageParser.detectSlayerBossName("Tarantula Vermin"));
        assertTrue(DropMessageParser.isSlayerQuestCompleteMessage("SLAYER QUEST COMPLETE!"));
        assertTrue(DropMessageParser.isSlayerQuestCompleteMessage(
                "\u00A7aSLAYER QUEST COMPLETE! You have slain the boss."));
        assertFalse(DropMessageParser.isSlayerQuestCompleteMessage(
                "[MVP+] Player: SLAYER QUEST COMPLETE!"));
    }

    @Test
    public void fishingTimerTracksBobberCastUntilReelIn() {
        SpiderDropAlert mod = new SpiderDropAlert();
        assertFalse(mod.hasFishingTimer());

        mod.updateFishingTimerState(true, 1000L);
        assertTrue(mod.hasFishingTimer());
        assertTrue(mod.isFishingTimerActive());
        assertEquals(5000L, mod.getFishingTimerElapsedMillis(6000L));

        // A bobber that remains out must not restart the stopwatch on later ticks.
        mod.updateFishingTimerState(true, 6000L);
        assertEquals(7500L, mod.getFishingTimerElapsedMillis(8500L));

        mod.updateFishingTimerState(false, 8500L);
        assertFalse(mod.isFishingTimerActive());
        assertEquals(7500L, mod.getFishingTimerElapsedMillis(20000L));

        mod.updateFishingTimerState(true, 21000L);
        assertTrue(mod.isFishingTimerActive());
        assertEquals("00:05", SpiderDropAlert.formatTimerDuration(5000L));
        assertEquals("01:00", SpiderDropAlert.formatTimerDuration(60000L));
        assertEquals("1:00:00", SpiderDropAlert.formatTimerDuration(3600000L));
    }

    @Test
    public void splashToPullTimerRunsFromBobberSplashUntilTheDetectedDip() {
        SpiderDropAlert mod = new SpiderDropAlert();
        mod.updateSplashToPullTimerState(true, 55, 10.0D, 1000L);
        assertFalse(mod.hasSplashToPullTimer());
        assertFalse(mod.startSplashToPullTimer(55, 2199L));

        mod.updateSplashToPullTimerState(true, 55, 10.0D, 2200L);
        assertTrue(mod.startSplashToPullTimer(55, 2200L));
        assertTrue(mod.isSplashToPullTimerActive());

        mod.updateSplashToPullTimerState(true, 55, 9.94D, 2300L);
        assertTrue(mod.isSplashToPullTimerActive());
        assertEquals(100L, mod.getSplashToPullTimerElapsedMillis(2300L));

        mod.updateSplashToPullTimerState(true, 55, 9.88D, 2400L);
        assertFalse(mod.isSplashToPullTimerActive());
        assertTrue(mod.hasSplashToPullTimer());
        assertEquals(200L, mod.getSplashToPullTimerElapsedMillis(3000L));
        assertEquals("1.25s", SpiderDropAlert.formatSplashToPullDuration(1250L));
    }

    @Test
    public void splashTimerAcceptsOnlyNearbySplashSoundsAndResetsForANewBobber() {
        assertTrue(SpiderDropAlert.isFishingSplashSound("random.splash"));
        assertTrue(SpiderDropAlert.isFishingSplashSound("minecraft:entity.generic.SPLASH"));
        assertFalse(SpiderDropAlert.isFishingSplashSound("random.pop"));
        assertTrue(SpiderDropAlert.isFishingSplashNearBobber(
                "random.splash", 3.0D, 64.0D, 0.0D, 0.0D, 64.0D, 0.0D));
        assertFalse(SpiderDropAlert.isFishingSplashNearBobber(
                "random.splash", 4.0D, 64.0D, 0.0D, 0.0D, 64.0D, 0.0D));

        SpiderDropAlert mod = new SpiderDropAlert();
        mod.updateSplashToPullTimerState(true, 55, 10.0D, 1000L);
        mod.updateSplashToPullTimerState(true, 55, 10.0D, 2200L);
        assertTrue(mod.startSplashToPullTimer(55, 2200L));
        mod.updateSplashToPullTimerState(true, 56, 10.0D, 2400L);
        assertFalse(mod.hasSplashToPullTimer());
        assertFalse(mod.startSplashToPullTimer(55, 2400L));
    }

    @Test
    public void biteAlertRequiresVisibleDownwardDisplacementAfterTheArmingDelay() {
        assertFalse(SpiderDropAlert.isFishingBitePullDown(-0.20D, 1199L));
        assertFalse(SpiderDropAlert.isFishingBitePullDown(-0.119D, 1200L));
        assertFalse(SpiderDropAlert.isFishingBitePullDown(-0.035D, 1200L));
        assertFalse(SpiderDropAlert.isFishingBitePullDown(0.0D, 1200L));
        assertTrue(SpiderDropAlert.isFishingBitePullDown(-0.12D, 1200L));
    }

    @Test
    public void biteAlertAccumulatesOnlyUntilAClearBobberDipAcrossSeveralTicks() {
        SpiderDropAlert mod = new SpiderDropAlert();
        mod.updateBiteAlertState(true, true, 84, 10.0D, 1000L);
        mod.updateBiteAlertState(true, true, 84, 10.0D, 2200L);
        assertFalse(mod.isBiteAlertShowing());

        mod.updateBiteAlertState(true, true, 84, 9.94D, 2300L);
        assertFalse(mod.isBiteAlertShowing());
        mod.updateBiteAlertState(true, true, 84, 9.88D, 2400L);
        assertTrue(mod.isBiteAlertShowing());
    }

    @Test
    public void biteAlertFadesAfterOneDipAndDoesNotRetriggerUntilANewBobber() {
        SpiderDropAlert mod = new SpiderDropAlert();
        mod.updateBiteAlertState(true, true, 42, 10.0D, 1000L);
        assertFalse(mod.isBiteAlertShowing());

        mod.updateBiteAlertState(true, true, 42, 9.95D, 2099L);
        assertFalse(mod.isBiteAlertShowing());
        mod.updateBiteAlertState(true, true, 42, 9.80D, 2200L);
        assertTrue(mod.isBiteAlertShowing());

        for (int tick = 1; tick <= 28; tick++) {
            mod.updateBiteAlertState(true, true, 42,
                    9.80D - tick * 0.13D, 2200L + tick * 50L);
        }
        assertFalse(mod.isBiteAlertShowing());

        mod.updateBiteAlertState(true, true, 43, 10.0D, 3700L);
        mod.updateBiteAlertState(true, true, 43, 10.0D, 4900L);
        mod.updateBiteAlertState(true, true, 43, 9.80D, 4950L);
        assertTrue(mod.isBiteAlertShowing());

        mod.updateBiteAlertState(true, false, -1, 0.0D, 5000L);
        assertFalse(mod.isBiteAlertShowing());
    }

    @Test
    public void biteAlertPositionSizeAndEnableStatePersistIndependently() throws Exception {
        File settingsFile = File.createTempFile("spider-drop-bite-alert-", ".properties");
        try {
            SpiderDropAlert mod = new SpiderDropAlert(settingsFile);
            int screenWidth = 854;
            int screenHeight = 480;
            mod.clampBiteAlertPosition(screenWidth, screenHeight);
            assertEquals((screenWidth - mod.getRenderedBiteAlertWidth()) / 2,
                    mod.getBiteAlertX());
            assertEquals((screenHeight - mod.getRenderedBiteAlertHeight()) / 2,
                    mod.getBiteAlertY());

            mod.moveBiteAlertTo(123, 45, screenWidth, screenHeight);
            mod.adjustBiteAlertSize(50, screenWidth, screenHeight);
            assertEquals(150, mod.getBiteAlertSizePercent());
            assertTrue(mod.isBiteAlertEnabled());
            assertTrue(mod.isTrackerEnabled());
            assertFalse(mod.isFishingMobCounterEnabled());

            mod.toggleBiteAlert();
            assertFalse(mod.isBiteAlertEnabled());
            assertTrue(mod.isTrackerEnabled());
            SpiderDropAlert loaded = new SpiderDropAlert(settingsFile);
            assertFalse(loaded.isBiteAlertEnabled());
            assertEquals(150, loaded.getBiteAlertSizePercent());
            assertEquals(123, loaded.getBiteAlertX());
            assertEquals(45, loaded.getBiteAlertY());

            loaded.adjustBiteAlertSize(500, screenWidth, screenHeight);
            assertEquals(200, loaded.getBiteAlertSizePercent());
            loaded.adjustBiteAlertSize(-500, screenWidth, screenHeight);
            assertEquals(70, loaded.getBiteAlertSizePercent());
            loaded.moveBiteAlertTo(screenWidth, screenHeight, screenWidth, screenHeight);
            assertEquals(screenWidth - loaded.getRenderedBiteAlertWidth(), loaded.getBiteAlertX());
            assertEquals(screenHeight - loaded.getRenderedBiteAlertHeight(), loaded.getBiteAlertY());
        } finally {
            settingsFile.delete();
        }
    }

    @Test
    public void parsesTotemRemainingTimeAndFormatsDeployableCountdowns() {
        assertEquals(299, SpiderDropAlert.parseDeployableTimerSeconds("Remaining: 4m 59s"));
        assertEquals(59, SpiderDropAlert.parseDeployableTimerSeconds("Remaining: 59s"));
        assertEquals(-1, SpiderDropAlert.parseDeployableTimerSeconds("Remaining: unknown"));
        assertEquals("3m 00s", SpiderDropAlert.formatDeployableTimer(180));
        assertEquals("09s", SpiderDropAlert.formatDeployableTimer(9));
    }

    @Test
    public void totemItemUseStartsFallbackCountdownEvenWithoutVisibleArmorStands() {
        assertTrue(SpiderDropAlert.isTotemOfCorruptionItemName("Totem of Corruption"));
        assertTrue(SpiderDropAlert.isTotemOfCorruptionItemName("\u00A7dTOTEM OF CORRUPTION"));
        assertFalse(SpiderDropAlert.isTotemOfCorruptionItemName("SOS Flare"));
        assertTrue(SpiderDropAlert.isSosFlareItemName("SOS Flare"));
        assertTrue(SpiderDropAlert.isSosFlareItemName("\u00A7cSOS FLARE"));
        assertFalse(SpiderDropAlert.isSosFlareItemName("Totem of Corruption"));

        SpiderDropAlert mod = new SpiderDropAlert();
        mod.startTotemFallbackTimer(1000L);
        assertEquals(120, mod.getTotemRemainingSeconds(1000L));
        assertEquals(119, mod.getTotemRemainingSeconds(2000L));
        assertTrue(mod.isDeployablesTimerPanelVisible(1000L));

        mod.updateTotemTimerState("Remaining: 1m 58s", 2500L);
        assertEquals(118, mod.getTotemRemainingSeconds(2500L));
    }

    @Test
    public void totemAndSosTimersCountDownFromServerTextAndPlacement() {
        SpiderDropAlert mod = new SpiderDropAlert();
        mod.updateTotemTimerState("Remaining: 1m 59s", 1000L);
        assertEquals(119, mod.getTotemRemainingSeconds(1000L));
        assertEquals(117, mod.getTotemRemainingSeconds(3000L));

        mod.startSosFlareTimer(10000L);
        assertEquals(180, mod.getSosFlareRemainingSeconds(10000L));
        assertEquals(179, mod.getSosFlareRemainingSeconds(11000L));
        assertEquals(1, mod.getSosFlareRemainingSeconds(189001L));
        assertEquals(0, mod.getSosFlareRemainingSeconds(190000L));
        assertTrue(mod.isDeployablesTimerPanelVisible(189999L));
    }

    @Test
    public void plasmafluxPowerOrbStartsSixtySecondDeployableCountdown() {
        assertTrue(SpiderDropAlert.isPlasmafluxPowerOrbItemName("Plasmaflux Power Orb"));
        assertTrue(SpiderDropAlert.isPlasmafluxPowerOrbItemName("\u00A7dPLASMAFLUX POWER ORB"));
        assertFalse(SpiderDropAlert.isPlasmafluxPowerOrbItemName("Overflux Power Orb"));
        assertFalse(SpiderDropAlert.isPlasmafluxPowerOrbItemName("Plasma Nucleus"));

        SpiderDropAlert mod = new SpiderDropAlert();
        mod.startPlasmafluxTimer(10000L);
        assertEquals(60, mod.getPlasmafluxRemainingSeconds(10000L));
        assertEquals(59, mod.getPlasmafluxRemainingSeconds(11000L));
        assertEquals(1, mod.getPlasmafluxRemainingSeconds(69999L));
        assertTrue(mod.isDeployablesTimerPanelVisible(69999L));
        assertEquals(0, mod.getPlasmafluxRemainingSeconds(70000L));
        assertFalse(mod.isDeployablesTimerPanelVisible(70000L));
    }

    @Test
    public void allCustomHudPanelsHideWhilePlayerListKeyIsDown() {
        assertTrue(SpiderDropAlert.shouldRenderCustomHudPanels(false));
        assertFalse(SpiderDropAlert.shouldRenderCustomHudPanels(true));
    }

    @Test
    public void jawbusTitleTriggersOnlyOnTheLocalLordJawbusChatLine() {
        assertTrue(SpiderDropAlert.isLordJawbusAlertMessage(
                "You have angered a legendary creature... Lord Jawbus has arrived."));
        assertTrue(SpiderDropAlert.isLordJawbusAlertMessage(
                "\u00A7c\u00A7lYou have angered a legendary creature... Lord Jawbus has arrived."));
        assertFalse(SpiderDropAlert.isLordJawbusAlertMessage(
                "[MVP+] Fisher: You have angered a legendary creature... Lord Jawbus has arrived."));
        assertFalse(SpiderDropAlert.isLordJawbusAlertMessage(
                "Party > [MVP+] Fisher: --> A Lord Jawbus has spawned <--"));
        assertFalse(SpiderDropAlert.isLordJawbusAlertMessage(
                "Party > [MVP+] Fisher: DOUBLE HOOK: I caught a Lord Jawbus!"));
        assertFalse(SpiderDropAlert.isLordJawbusAlertMessage(
                "Party > [MVP+] Fisher: Lord Jawbus is a rare sea creature."));
    }

    @Test
    public void nearbyCreatureHpParsesLegendaryAndMythicNameplates() {
        SpiderDropAlert.NearbyCreatureHpEntry jawbus = SpiderDropAlert.parseNearbyCreatureHpLabel(
                "\u00A7eSea Creatures HP\n\u00A77[Lvl 600] \u00A7cLord Jawbus \u00A7a76M/100M\u00A7c\u2764 >");
        assertEquals("Lord Jawbus", jawbus.creatureName);
        assertEquals(600, jawbus.level);
        assertEquals("76M", jawbus.currentHealth);
        assertEquals("100M", jawbus.maxHealth);
        assertEquals("[Lvl 600] Lord Jawbus 76M/100M\u2764",
                SpiderDropAlert.stripFormattingCodes(jawbus.toHudLabel()));

        SpiderDropAlert.NearbyCreatureHpEntry thunder = SpiderDropAlert.parseNearbyCreatureHpLabel(
                "[Lvl 400] Thunder 34M/35M\u2764 >");
        assertEquals("Thunder", thunder.creatureName);
        assertEquals("34M", thunder.currentHealth);
        assertEquals("35M", thunder.maxHealth);

        SpiderDropAlert.NearbyCreatureHpEntry reindrake = SpiderDropAlert.parseNearbyCreatureHpLabel(
                "[Lvl 100] Reindrake 543/2,500\u2764");
        assertEquals("Reindrake", reindrake.creatureName);
        assertEquals(100, reindrake.level);
        assertEquals("543", reindrake.currentHealth);
        assertEquals("2,500", reindrake.maxHealth);
        assertEquals("Titanoboa", SpiderDropAlert.parseNearbyCreatureHpLabel(
                "[Lvl 240] Titanoboa 45M/45M\u2764").creatureName);
        assertEquals("Frog Prince", SpiderDropAlert.parseNearbyCreatureHpLabel(
                "[Lvl 132] Frog Prince 10M/10M\u2764").creatureName);
        SpiderDropAlert.NearbyCreatureHpEntry seaEmperor =
                SpiderDropAlert.parseNearbyCreatureHpLabel(
                        "[Lvl 200] Sea Emperor 4.8M/5M\u2764");
        assertEquals("Sea Emperor", seaEmperor.creatureName);
        assertEquals("4.8M", seaEmperor.currentHealth);
        assertEquals("The Sea Emperor", SpiderDropAlert.parseNearbyCreatureHpLabel(
                "[Lvl 200] The Sea Emperor 4.8M/5M\u2764").creatureName);

        assertNull(SpiderDropAlert.parseNearbyCreatureHpLabel(
                "[Lvl 100] Sea Walker 1,000/1,500\u2764"));
        assertEquals("1.5M", SpiderDropAlert.formatNearbyCreatureHpValue(1500000.0D));
        assertEquals("2,500", SpiderDropAlert.formatNearbyCreatureHpValue(2500.0D));
    }

    @Test
    public void nearbyCreatureHpRecognizesEveryLegendaryNameplateWithRarityPrefix() {
        String[] legendaryCreatures = {
                "Water Hydra", "The Loch Emperor", "Alligator", "Abyssal Miner",
                "Blue Ringed Octopus", "Fiery Scuttler", "Great White Shark",
                "Phantom Fisher", "Puddle Jumper", "Silkbreeze", "Thunder", "Yeti"
        };
        for (String creatureName : legendaryCreatures) {
            SpiderDropAlert.NearbyCreatureHpEntry entry =
                    SpiderDropAlert.parseNearbyCreatureHpLabel(
                            "[LEGENDARY] [Lvl 150] " + creatureName + " 1M/1M\u2764");
            assertTrue("Should accept " + creatureName, entry != null);
        }
    }

    @Test
    public void nearbyCreatureHpTogglePositionAndScalePersistIndependently() throws Exception {
        File settingsFile = File.createTempFile("spider-drop-creature-hp-", ".properties");
        try {
            SpiderDropAlert mod = new SpiderDropAlert(settingsFile);
            assertTrue(mod.isNearbyCreatureHpEnabled());
            mod.moveNearbyCreatureHpPanelTo(120, 90, 854, 480);
            mod.adjustNearbyCreatureHpSize(20, 854, 480);
            mod.toggleNearbyCreatureHp();
            assertFalse(mod.isNearbyCreatureHpEnabled());
            assertTrue(mod.isTrackerEnabled());
            assertFalse(mod.isFishingMobCounterEnabled());

            SpiderDropAlert loaded = new SpiderDropAlert(settingsFile);
            assertFalse(loaded.isNearbyCreatureHpEnabled());
            assertEquals(120, loaded.getNearbyCreatureHpX());
            assertEquals(90, loaded.getNearbyCreatureHpY());
            assertEquals(120, loaded.getNearbyCreatureHpSizePercent());
            assertTrue(loaded.isTrackerEnabled());

            loaded.adjustNearbyCreatureHpSize(500, 854, 480);
            assertEquals(150, loaded.getNearbyCreatureHpSizePercent());
            loaded.adjustNearbyCreatureHpSize(-500, 854, 480);
            assertEquals(70, loaded.getNearbyCreatureHpSizePercent());
            loaded.moveNearbyCreatureHpPanelTo(854, 480, 854, 480);
            assertEquals(854 - loaded.getRenderedNearbyCreatureHpPanelWidth(854),
                    loaded.getNearbyCreatureHpX());
            assertEquals(480 - loaded.getRenderedNearbyCreatureHpPanelHeight(),
                    loaded.getNearbyCreatureHpY());
        } finally {
            settingsFile.delete();
        }
    }

    @Test
    public void deployablesPanelSettingsPersistIndependently() throws Exception {
        File settingsFile = File.createTempFile("spider-drop-deployables-", ".properties");
        try {
            SpiderDropAlert mod = new SpiderDropAlert(settingsFile);
            mod.moveDeployablesTimerPanelTo(120, 90, 854, 480);
            mod.adjustDeployablesTimerPanelSize(20, 854, 480);
            mod.toggleJawbusAlert();
            assertFalse(mod.isJawbusAlertEnabled());
            assertTrue(mod.isTrackerEnabled());
            assertFalse(mod.isFishingMobCounterEnabled());

            SpiderDropAlert loaded = new SpiderDropAlert(settingsFile);
            assertEquals(120, loaded.getDeployablesTimerPanelX());
            assertEquals(90, loaded.getDeployablesTimerPanelY());
            assertEquals(120, loaded.getDeployablesTimerPanelSizePercent());
            assertFalse(loaded.isJawbusAlertEnabled());
            assertTrue(loaded.isDeployablesTimerPanelEnabled());

            loaded.toggleDeployablesTimerPanel();
            assertFalse(loaded.isDeployablesTimerPanelEnabled());
            assertTrue(loaded.isTrackerEnabled());
        } finally {
            settingsFile.delete();
        }
    }

    @Test
    public void slayerBossTimerRunsFromSpawnUntilQuestCompletion() {
        SpiderDropAlert mod = new SpiderDropAlert();
        mod.startSlayerBossTimer(SlayerType.SPIDER, 1000L);
        assertTrue(mod.hasSlayerBossTimer());
        assertTrue(mod.isSlayerBossTimerActive());
        assertEquals(4000L, mod.getSlayerBossTimerElapsedMillis(5000L));

        // Duplicate boss-dialogue lines for the same boss must not reset the start time.
        mod.startSlayerBossTimer(SlayerType.SPIDER, 5000L);
        assertEquals(7000L, mod.getSlayerBossTimerElapsedMillis(8000L));

        mod.completeSlayerBossTimer(8200L);
        assertFalse(mod.isSlayerBossTimerActive());
        assertEquals(7200L, mod.getSlayerBossTimerElapsedMillis(30000L));

        mod.startSlayerBossTimer(SlayerType.ENDERMAN, 40000L);
        assertEquals(SlayerType.SPIDER, mod.getActiveSlayer());
        assertEquals(5000L, mod.getSlayerBossTimerElapsedMillis(45000L));
    }

    @Test
    public void fishingBoxAppearsWhenEnabledAndCanShowOnlyTimerBeforeCatch() throws Exception {
        File settingsFile = File.createTempFile("spider-drop-timer-", ".properties");
        try {
            SpiderDropAlert mod = new SpiderDropAlert(settingsFile);
            mod.toggleFishingMobCounter();
            assertTrue(mod.isFishingSectionVisible());
            assertEquals(0L, mod.getTotalLegendaryCreatureCount());
            mod.updateFishingTimerState(true, 1000L);
            assertTrue(mod.isFishingSectionVisible());
            mod.clearFishingHistory();
            assertTrue(mod.isFishingSectionVisible());
            mod.toggleFishingMobCounter();
            assertFalse(mod.isFishingSectionVisible());
        } finally {
            settingsFile.delete();
        }
    }

    @Test
    public void slayerAndFishingHudTogglesOperateIndependently() throws Exception {
        File settingsFile = File.createTempFile("spider-drop-toggle-", ".properties");
        try {
            SpiderDropAlert mod = new SpiderDropAlert(settingsFile);
            assertTrue(mod.isTrackerEnabled());
            assertFalse(mod.isFishingMobCounterEnabled());

            mod.toggleFishingMobCounter();
            assertTrue(mod.isFishingMobCounterEnabled());
            assertTrue(mod.isFishingSectionVisible());
            assertTrue(mod.isTrackerEnabled());

            mod.toggleTracker();
            assertFalse(mod.isTrackerEnabled());
            assertTrue(mod.isFishingSectionVisible());

            mod.updateFishingTimerState(true, 1000L);
            mod.toggleTracker();
            assertTrue(mod.isTrackerEnabled());
            assertTrue(mod.isFishingTimerActive());

            mod.toggleFishingMobCounter();
            assertTrue(mod.isTrackerEnabled());
            assertFalse(mod.isFishingSectionVisible());
            assertFalse(mod.isFishingTimerActive());
        } finally {
            settingsFile.delete();
        }
    }

    @Test
    public void clearsOnlyTheSelectedSlayerHistory() {
        SpiderDropAlert mod = new SpiderDropAlert();
        mod.recordDrop(SlayerType.SPIDER, "Tarantula Silk", 64L);
        mod.recordDrop(SlayerType.ENDERMAN, "Judgement Core", 1L);

        assertEquals(SlayerType.ENDERMAN, mod.getActiveSlayer());
        assertEquals(1, mod.getDropHistorySize(SlayerType.SPIDER));
        assertEquals(1, mod.getDropHistorySize(SlayerType.ENDERMAN));

        mod.clearHistory(SlayerType.ENDERMAN);

        assertEquals(0, mod.getDropHistorySize(SlayerType.ENDERMAN));
        assertEquals(1, mod.getDropHistorySize(SlayerType.SPIDER));
        assertEquals(SlayerType.ENDERMAN, mod.getActiveSlayer());
    }

    @Test
    public void recognizesAllLegendaryCreatureAnnouncementMarkersOnlyAtLineStart() {
        assertEquals(13, LegendaryCreature.values().length);
        for (LegendaryCreature creature : LegendaryCreature.values()) {
            assertEquals(creature, DropMessageParser.detectLegendaryCreature(creature.chatPrefix + "."));
        }
        assertEquals(LegendaryCreature.THE_LOCH_EMPEROR,
                DropMessageParser.detectLegendaryCreature(
                        "The Sea Emperor arises from the depths."));
        assertEquals(LegendaryCreature.THE_LOCH_EMPEROR,
                DropMessageParser.detectLegendaryCreature(
                        "\u00A7eThe Sea Emperor arises from the depths."));
        assertEquals(LegendaryCreature.THE_LOCH_EMPEROR,
                DropMessageParser.detectLegendaryCreature(
                        "Sea Emperor arises from the depths!"));
        assertEquals(LegendaryCreature.THE_LOCH_EMPEROR,
                DropMessageParser.detectLegendaryCreature(
                        "A Sea Emperor has appeared!"));
        assertNull(DropMessageParser.detectLegendaryCreature(
                "[MVP+] Player: The Sea Emperor arises from the depths."));
        assertEquals(LegendaryCreature.WATER_HYDRA,
                DropMessageParser.detectLegendaryCreature(
                        "\u00A7eThe Water Hydra has come to test your strength."));
        assertEquals(LegendaryCreature.LORD_JAWBUS,
                DropMessageParser.detectLegendaryCreature(
                        "You have angered a legendary creature... Lord Jawbus has arrived."));
        assertNull(DropMessageParser.detectLegendaryCreature(
                "You have angered a legendary creature... another creature has arrived."));
        assertEquals("Water Hydra-1", SpiderDropAlert.formatLegendaryCreatureLabel(
                LegendaryCreature.WATER_HYDRA, 1L));
        assertNull(DropMessageParser.detectLegendaryCreature(
                "[MVP+] Player: The Water Hydra has come to test your strength."));
        assertNull(DropMessageParser.detectLegendaryCreature("You caught a Sea Walker!"));
    }

    @Test
    public void totalsOnlyLegendaryCatchesAndFishingClearIsIndependent() throws Exception {
        File settingsFile = File.createTempFile("spider-drop-alert-test-", ".properties");
        try {
            SpiderDropAlert mod = new SpiderDropAlert(settingsFile);
            assertEquals(0, mod.getCaughtLegendaryCreatureCount());
            assertFalse(mod.isFishingSectionVisible());
            mod.toggleFishingMobCounter();
            assertTrue(mod.isFishingMobCounterEnabled());
            assertTrue(mod.isFishingSectionVisible());
            mod.recordDrop(SlayerType.SPIDER, "Tarantula Silk", 64L);
            mod.recordLegendaryCreature(LegendaryCreature.THE_LOCH_EMPEROR);
            mod.recordLegendaryCreature(LegendaryCreature.THE_LOCH_EMPEROR);
            mod.recordLegendaryCreature(LegendaryCreature.THE_LOCH_EMPEROR);
            for (int i = 0; i < 4; i++) {
                mod.recordLegendaryCreature(LegendaryCreature.WATER_HYDRA);
            }
            for (int i = 0; i < 47; i++) {
                mod.recordLegendaryCreature(LegendaryCreature.YETI);
            }

            assertEquals(3L, mod.getLegendaryCreatureCount(
                    LegendaryCreature.THE_LOCH_EMPEROR));
            assertEquals(4L, mod.getLegendaryCreatureCount(
                    LegendaryCreature.WATER_HYDRA));
            assertEquals(54L, mod.getTotalLegendaryCreatureCount());
            assertEquals(3, mod.getCaughtLegendaryCreatureCount());
            assertTrue(mod.isFishingSectionVisible());

            mod.recordLegendaryCreature(LegendaryCreature.LORD_JAWBUS);
            assertEquals(1L, mod.getLegendaryCreatureCount(
                    LegendaryCreature.LORD_JAWBUS));
            assertEquals(55L, mod.getTotalLegendaryCreatureCount());
            assertEquals(4, mod.getCaughtLegendaryCreatureCount());

            mod.clearHistory(SlayerType.SPIDER);
            assertEquals(0, mod.getDropHistorySize(SlayerType.SPIDER));
            assertEquals(55L, mod.getTotalLegendaryCreatureCount());

            mod.recordDrop(SlayerType.SPIDER, "Tarantula Silk", 1L);
            mod.clearFishingHistory();
            assertEquals(0L, mod.getTotalLegendaryCreatureCount());
            assertEquals(0, mod.getCaughtLegendaryCreatureCount());
            assertTrue(mod.isFishingSectionVisible());
            mod.toggleFishingMobCounter();
            assertFalse(mod.isFishingSectionVisible());
            assertEquals(1, mod.getDropHistorySize(SlayerType.SPIDER));
        } finally {
            settingsFile.delete();
        }
    }

    @Test
    public void fishingBoxHasIndependentPositionAndUsesSpaceBesideOrBelowTracker() throws Exception {
        File wideSettings = File.createTempFile("spider-drop-wide-", ".properties");
        File narrowSettings = File.createTempFile("spider-drop-narrow-", ".properties");
        try {
            SpiderDropAlert wide = new SpiderDropAlert(wideSettings);
            wide.clampFishingTrackerPosition(854, 480);
            assertEquals(262, wide.getFishingX());
            assertEquals(60, wide.getFishingY());

            wide.moveFishingTrackerTo(500, 120, 854, 480);
            assertEquals(500, wide.getFishingX());
            assertEquals(120, wide.getFishingY());
            assertEquals(10, wide.getTrackerX());
            assertEquals(60, wide.getTrackerY());

            SpiderDropAlert narrow = new SpiderDropAlert(narrowSettings);
            narrow.clampFishingTrackerPosition(420, 300);
            assertEquals(10, narrow.getFishingX());
            assertEquals(136, narrow.getFishingY());
        } finally {
            wideSettings.delete();
            narrowSettings.delete();
        }
    }

    @Test
    public void normalizesNamesForManualPrices() {
        assertEquals("tarantula talisman", DropMessageParser.normalizeItemName("  Tarantula   Talisman  "));
        assertEquals("tarantula talisman", DropMessageParser.normalizeItemName("\u00A76Tarantula Talisman"));
        assertEquals("tarantula silk", DropMessageParser.normalizeItemName("64x Tarantula Silk"));
        assertEquals("tarantula silk", DropMessageParser.normalizeItemName("Tarantula Silk (x64)"));
        assertEquals("1,000,000", SpiderDropAlert.formatPrice(1000000L));
    }


    @Test
    public void extractsStackQuantityAndCleansItemName() {
        assertEquals(64L, DropMessageParser.extractDropQuantity("RARE DROP! Tarantula Silk (64x)"));
        assertEquals("Tarantula Silk", DropMessageParser.extractDropItem("RARE DROP! Tarantula Silk (64x)"));
        assertEquals(20L, DropMessageParser.extractDropQuantity(
                "VERY RARE DROP! 20x Tarantula Silk (+25% Magic Find)"));
        assertEquals("Tarantula Silk", DropMessageParser.extractDropItem(
                "VERY RARE DROP! 20x Tarantula Silk (+25% Magic Find)"));
    }

    @Test
    public void extractsParenthesizedToxicArrowPoisonStacks() {
        String message = "RARE DROP! 1x (64x Toxic Arrow Poison)";
        assertEquals("Toxic Arrow Poison", DropMessageParser.extractDropItem(message));
        assertEquals(64L, DropMessageParser.extractDropQuantity(message));
        assertEquals("64x Toxic Arrow Poison(7.04k)",
                SpiderDropAlert.formatDropLabel("Toxic Arrow Poison", 64L,
                        PriceSetCommand.parsePrice("110")));
        assertEquals("64x Toxic Arrow Poison(7.04m)",
                SpiderDropAlert.formatDropLabel("Toxic Arrow Poison", 64L,
                        PriceSetCommand.parsePrice("110k")));
    }

    @Test
    public void normalizesParenthesizedCountAndItemFormatting() {
        String message = "RARE DROP! (322) x(Toxic Arrow Poison)";
        assertEquals(322L, DropMessageParser.extractDropQuantity(message));
        assertEquals("Toxic Arrow Poison", DropMessageParser.extractDropItem(message));
        assertEquals("434x Toxic Arrow Poison(83m)",
                SpiderDropAlert.formatDropLabel("Toxic Arrow Poison", 434L, 191244L));
    }

    @Test
    public void computesAndFormatsStackTotals() {
        long unitPrice = PriceSetCommand.parsePrice("1,9k");
        assertEquals(1900L, unitPrice);
        assertEquals(38000L, SpiderDropAlert.calculateTotalPrice(unitPrice, 20L));
        assertEquals(128L, SpiderDropAlert.addDropQuantities(64L, 64L));
        assertEquals("38k", SpiderDropAlert.formatCompactPrice(
                SpiderDropAlert.calculateTotalPrice(unitPrice, 20L)));
        assertEquals("1x Tarantula Silk(1.9k)",
                SpiderDropAlert.formatDropLabel("Tarantula Silk", 1L, unitPrice));
        assertEquals("2x Tarantula Silk(2 coins)",
                SpiderDropAlert.formatDropLabel("Tarantula Silk", 2L, 1L));
        assertEquals("20x Tarantula Silk(38k)",
                SpiderDropAlert.formatDropLabel("Tarantula Silk", 20L, unitPrice));
        assertEquals("64x Tarantula Silk(121.6k)",
                SpiderDropAlert.formatDropLabel("Tarantula Silk", 64L, unitPrice));
        assertEquals("64x Tarantula Silk(price not set)",
                SpiderDropAlert.formatDropLabel("Tarantula Silk", 64L, null));
    }

    @Test
    public void totalsVisiblePricedDropValuesAndIgnoresUnpricedRows() {
        long total = 0L;
        total = SpiderDropAlert.addPricedDropValue(total, 1900L, 20L);
        total = SpiderDropAlert.addPricedDropValue(total, null, 8L);
        total = SpiderDropAlert.addPricedDropValue(total, 110000L, 64L);
        assertEquals(7078000L, total);
        assertEquals("7.08m", SpiderDropAlert.formatCompactPrice(total));
    }

    @Test
    public void totalProfitMatchesSumOfExampleRowValues() {
        long total = 0L;
        total = SpiderDropAlert.addPricedDropValue(total, 320000L, 1L);
        total = SpiderDropAlert.addPricedDropValue(total, 499000L, 1L);
        assertEquals(819000L, total);
        assertEquals("819k", SpiderDropAlert.formatCompactPrice(total));
    }

    @Test
    public void supportsSetPriceAsAlias() {
        SpiderDropAlert mod = new SpiderDropAlert();
        PriceSetCommand primary = new PriceSetCommand(mod);
        PriceSetCommand alias = new PriceSetCommand(mod, "setprice");
        assertEquals("priceset", primary.getCommandName());
        assertEquals("setprice", alias.getCommandName());
        assertTrue(alias.getCommandUsage(null).startsWith("/setprice "));
    }

    @Test
    public void parsesCompactManualPrices() {
        assertEquals(110000L, PriceSetCommand.parsePrice("110k"));
        assertEquals(1500000L, PriceSetCommand.parsePrice("1.5m"));
        assertEquals(1900L, PriceSetCommand.parsePrice("1,9k"));
        assertEquals(1000000000L, PriceSetCommand.parsePrice("1b"));
        assertEquals(1234567L, PriceSetCommand.parsePrice("1,234,567"));
    }
}
